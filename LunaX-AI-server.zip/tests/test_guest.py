"""
Guest access tests (LunaX_AI_TZ.txt раздел 32, 58).

NOT VERIFIED в этом окружении — см. tests/conftest.py.
"""
import pytest


@pytest.mark.parametrize(
    "method,path",
    [
        ("GET", "/api/v1/auth/me"),
        ("GET", "/api/v1/developer/me"),
        ("GET", "/api/v1/developer/developers"),
        ("GET", "/api/v1/biometry/liveness-challenge"),
    ],
)
@pytest.mark.asyncio
async def test_protected_endpoints_require_jwt(client, method, path):
    resp = await client.request(method, path)
    assert resp.status_code == 401
