"""
Developer / Primary Developer RBAC tests (LunaX_AI_TZ.txt раздел 33, 57).

NOT VERIFIED в этом окружении — см. tests/conftest.py.
"""
import pytest

from app.database.models import User, UserRole
from app.modules.auth.services import hash_password


async def _create_user(db_session, email, username, password, role, email_verified=True):
    user = User(
        email=email,
        username=username,
        hashed_password=hash_password(password),
        role=role,
        is_active=True,
        email_verified=email_verified,
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


async def _login(client, email, password):
    resp = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert resp.status_code == 200, resp.text
    return {"Authorization": f"Bearer {resp.json()['access_token']}"}


@pytest.mark.asyncio
async def test_user_cannot_access_developer_console(client, db_session):
    await _create_user(db_session, "plainuser@example.com", "plainuser", "password123", UserRole.USER)
    headers = await _login(client, "plainuser@example.com", "password123")

    resp = await client.get("/api/v1/developer/developers", headers=headers)
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_developer_cannot_manage_other_developers(client, db_session):
    await _create_user(db_session, "primary@example.com", "primaryowner", "password123", UserRole.PRIMARY_DEVELOPER)
    dev = await _create_user(db_session, "dev1@example.com", "dev1", "password123", UserRole.DEVELOPER)
    headers = await _login(client, "dev1@example.com", "password123")

    resp = await client.get("/api/v1/developer/developers", headers=headers)
    assert resp.status_code == 403

    resp2 = await client.delete(f"/api/v1/developer/developers/{dev.id}", headers=headers)
    assert resp2.status_code == 403


@pytest.mark.asyncio
async def test_primary_can_create_list_and_revoke_developer(client, db_session):
    await _create_user(db_session, "primary2@example.com", "primaryowner2", "password123", UserRole.PRIMARY_DEVELOPER)
    headers = await _login(client, "primary2@example.com", "password123")

    create_resp = await client.post(
        "/api/v1/developer/developers",
        json={
            "email": "newdev@example.com",
            "username": "newdev",
            "password": "password123",
            "date_of_birth": "2000-01-01",
            "accept_terms": True,
        },
        headers=headers,
    )
    assert create_resp.status_code == 201
    new_dev_id = create_resp.json()["id"]
    assert create_resp.json()["role"] == "developer"

    list_resp = await client.get("/api/v1/developer/developers", headers=headers)
    assert list_resp.status_code == 200
    assert any(d["id"] == new_dev_id for d in list_resp.json())

    revoke_resp = await client.delete(f"/api/v1/developer/developers/{new_dev_id}", headers=headers)
    assert revoke_resp.status_code == 200
    assert revoke_resp.json()["is_active"] is False


@pytest.mark.asyncio
async def test_primary_developer_cannot_be_modified_via_management_api(client, db_session):
    primary = await _create_user(
        db_session, "immutable@example.com", "immutableprimary", "password123", UserRole.PRIMARY_DEVELOPER
    )
    headers = await _login(client, "immutable@example.com", "password123")

    patch_resp = await client.patch(
        f"/api/v1/developer/developers/{primary.id}",
        json={"is_active": False},
        headers=headers,
    )
    assert patch_resp.status_code == 403
    assert patch_resp.json()["detail"] == "Cannot modify primary developer"

    delete_resp = await client.delete(f"/api/v1/developer/developers/{primary.id}", headers=headers)
    assert delete_resp.status_code == 403


@pytest.mark.asyncio
async def test_developer_gets_own_status_but_not_console(client, db_session):
    await _create_user(db_session, "devself@example.com", "devself", "password123", UserRole.DEVELOPER)
    headers = await _login(client, "devself@example.com", "password123")

    me = await client.get("/api/v1/developer/me", headers=headers)
    assert me.status_code == 200
    assert me.json()["role"] == "developer"


@pytest.mark.asyncio
async def test_login_failure_burst_creates_security_event(client, db_session):
    await _create_user(db_session, "primary3@example.com", "primaryowner3", "password123", UserRole.PRIMARY_DEVELOPER)
    await _create_user(db_session, "victim@example.com", "victimuser", "password123", UserRole.USER)

    for _ in range(6):
        await client.post(
            "/api/v1/auth/login", json={"email": "victim@example.com", "password": "wrongpass"}
        )

    headers = await _login(client, "primary3@example.com", "password123")
    resp = await client.get("/api/v1/developer/security-events", headers=headers)
    assert resp.status_code == 200
    events = resp.json()
    assert any(e["event_type"] == "login_failure_burst" and e["email"] == "victim@example.com" for e in events)


@pytest.mark.asyncio
async def test_console_command_grants_privilege_and_tokens(client, db_session):
    await _create_user(db_session, "primary4@example.com", "primaryowner4", "password123", UserRole.PRIMARY_DEVELOPER)
    await _create_user(db_session, "plain2@example.com", "plainuser2", "password123", UserRole.USER)
    headers = await _login(client, "primary4@example.com", "password123")

    resp = await client.post(
        "/api/v1/developer/console/command",
        json={"command": "/priv plain2@example.com developer"},
        headers=headers,
    )
    assert resp.status_code == 200, resp.text
    assert resp.json()["result"]["new_role"] == "developer"

    resp2 = await client.post(
        "/api/v1/developer/console/command",
        json={"command": "/tokens plain2@example.com 1000"},
        headers=headers,
    )
    assert resp2.status_code == 200
    assert resp2.json()["result"]["new_balance"] >= 1000


@pytest.mark.asyncio
async def test_console_command_denied_for_non_primary(client, db_session):
    await _create_user(db_session, "dev2@example.com", "dev2", "password123", UserRole.DEVELOPER)
    headers = await _login(client, "dev2@example.com", "password123")

    resp = await client.post(
        "/api/v1/developer/console/command",
        json={"command": "/priv someone@example.com admin"},
        headers=headers,
    )
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_console_ban_unban_and_find(client, db_session):
    await _create_user(db_session, "primary5@example.com", "primaryowner5", "password123", UserRole.PRIMARY_DEVELOPER)
    await _create_user(db_session, "plain3@example.com", "plainuser3", "password123", UserRole.USER)
    headers = await _login(client, "primary5@example.com", "password123")

    resp = await client.post(
        "/api/v1/developer/console/command", json={"command": "/ban plain3@example.com"}, headers=headers
    )
    assert resp.status_code == 200
    assert resp.json()["result"]["is_active"] is False

    resp2 = await client.post(
        "/api/v1/developer/console/command", json={"command": "/unban plain3@example.com"}, headers=headers
    )
    assert resp2.status_code == 200
    assert resp2.json()["result"]["is_active"] is True

    resp3 = await client.post(
        "/api/v1/developer/console/command", json={"command": "/find plain3@example.com"}, headers=headers
    )
    assert resp3.status_code == 200
    assert resp3.json()["result"]["username"] == "plainuser3"


@pytest.mark.asyncio
async def test_console_history_records_commands(client, db_session):
    await _create_user(db_session, "primary6@example.com", "primaryowner6", "password123", UserRole.PRIMARY_DEVELOPER)
    await _create_user(db_session, "plain4@example.com", "plainuser4", "password123", UserRole.USER)
    headers = await _login(client, "primary6@example.com", "password123")

    await client.post(
        "/api/v1/developer/console/command", json={"command": "/tokens plain4@example.com 500"}, headers=headers
    )
    resp = await client.get("/api/v1/developer/console/history", headers=headers)
    assert resp.status_code == 200
    assert any(entry["details"]["command"] == "/tokens plain4@example.com 500" for entry in resp.json())


@pytest.mark.asyncio
async def test_username_availability(client, db_session):
    await _create_user(db_session, "taken@example.com", "takenname", "password123", UserRole.USER)

    resp_taken = await client.get("/api/v1/auth/username-available", params={"username": "takenname"})
    assert resp_taken.status_code == 200
    assert resp_taken.json()["available"] is False

    resp_free = await client.get("/api/v1/auth/username-available", params={"username": "freshname"})
    assert resp_free.status_code == 200
    assert resp_free.json()["available"] is True
