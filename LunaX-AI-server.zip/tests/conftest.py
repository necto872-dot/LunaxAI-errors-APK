"""
Общие фикстуры тестов LunaX AI.

Использует изолированную in-memory SQLite базу на каждый тестовый запуск
и mock SMTP (никогда не отправляет реальные письма при `pytest -v` —
ТЗ раздел 31/62). Реальный Gmail SMTP тестируется отдельно, вручную.

NOT VERIFIED: эти тесты не были фактически запущены в текущей sandbox-среде
(нет сети/пакетов fastapi, sqlalchemy, pytest и т.д.). Установите зависимости
из requirements.txt и выполните `pytest -v` самостоятельно.
"""
from collections.abc import AsyncGenerator

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.database import Base, get_db
from app.main import app

TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"


@pytest.fixture(autouse=True)
def _reset_rate_limiter():
    """Rate limiter в app/core/rate_limit.py хранит попадания в
    module-level словаре, общем для всего процесса pytest. Без сброса
    между тестами лимиты, накопленные в одном тесте (включая
    test_rate_limit.py), просачиваются в следующие и валят login/register
    в них 429-ми. Сбрасываем перед каждым тестом.

    Заодно чистим in-memory окна детекторов в app/core/security_events.py
    (_token_spend_window, _rate_limit_hits) — тот же класс проблемы:
    module-level dict, общий для всего процесса pytest."""
    from app.core.rate_limit import _hits
    from app.core.security_events import _rate_limit_hits, _token_spend_window

    _hits.clear()
    _token_spend_window.clear()
    _rate_limit_hits.clear()
    yield
    _hits.clear()
    _token_spend_window.clear()
    _rate_limit_hits.clear()


@pytest_asyncio.fixture
async def test_engine():
    engine = create_async_engine(TEST_DATABASE_URL, poolclass=None)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(test_engine) -> AsyncGenerator[AsyncSession, None]:
    session_maker = async_sessionmaker(test_engine, expire_on_commit=False)
    async with session_maker() as session:
        yield session


@pytest_asyncio.fixture
async def client(test_engine, monkeypatch) -> AsyncGenerator[AsyncClient, None]:
    session_maker = async_sessionmaker(test_engine, expire_on_commit=False)

    async def override_get_db():
        async with session_maker() as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db

    # Mock SMTP: тесты не должны отправлять реальные письма (ТЗ п.31, п.62).
    # Токен перехватывается в captured_tokens, чтобы тесты могли пройти
    # verify-email / reset-password / confirm-email-change end-to-end
    # без реальной отправки почты.
    captured_tokens: list[tuple[str, str, str]] = []

    def _capture(kind):
        def _fn(to_email, token):
            captured_tokens.append((kind, to_email, token))
            return True
        return _fn

    monkeypatch.setattr("app.modules.auth.services.send_verification_email", _capture("verify"))
    monkeypatch.setattr("app.modules.auth.services.send_password_reset_email", _capture("reset"))
    monkeypatch.setattr("app.modules.auth.services.send_email_change_confirmation", _capture("change"))

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        ac.captured_tokens = captured_tokens
        yield ac

    app.dependency_overrides.clear()
