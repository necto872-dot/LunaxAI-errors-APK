"""
Тесты генерации изображений (app/core/media/image_client.py,
app/modules/media/routers.py): честный 503 без конфигурации, списание
C2 + возврат токенов при неудаче, реальный вызов self-hosted сервера
мокается (httpx.AsyncClient.post).

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
import base64
from unittest.mock import MagicMock, patch

import httpx
import pytest

from app.database.models import User, UserRole
from app.modules.auth.services import hash_password

_real_async_client_post = httpx.AsyncClient.post


async def _fake_external_post(fake_json: dict):
    """
    Возвращает патч для httpx.AsyncClient.post, который подделывает ответ
    ТОЛЬКО для внешнего self-hosted сервера (localhost:7860/7861/8188 и
    т.п.), а любой другой запрос (в т.ч. внутренний тестовый вызов через
    ASGITransport к своему же /api/v1/...) пропускает в реальный метод —
    иначе патч глобально перехватывает httpx.AsyncClient.post и ломает
    сам вызов эндпоинта, который тоже идёт через httpx.AsyncClient.
    """

    async def _fake(self, url, headers=None, json=None):
        if str(self.base_url).rstrip("/") == "http://test":
            return await _real_async_client_post(self, url, headers=headers, json=json)
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = fake_json
        return resp

    return _fake


async def _create_verified_user(db_session, email="imguser@example.com", username="imguser"):
    user = User(
        email=email,
        username=username,
        hashed_password=hash_password("password123"),
        role=UserRole.USER,
        is_active=True,
        email_verified=True,
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


async def _login(client, email, password="password123"):
    resp = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert resp.status_code == 200, resp.text
    return {"Authorization": f"Bearer {resp.json()['access_token']}"}


@pytest.mark.asyncio
async def test_image_generate_returns_503_without_config(client, db_session):
    user = await _create_verified_user(db_session)
    headers = await _login(client, "imguser@example.com")
    balance_before = user.token_balance

    resp = await client.post("/api/v1/media/image/generate", json={"prompt": "кот в шляпе"}, headers=headers)
    assert resp.status_code == 503

    await db_session.refresh(user)
    assert user.token_balance == balance_before  # токены возвращены


@pytest.mark.asyncio
async def test_image_generate_success_deducts_c2_and_returns_image(client, db_session, monkeypatch):
    monkeypatch.setattr("app.core.media.image_client.settings.image_generation_enabled", True)
    monkeypatch.setattr("app.core.media.image_client.settings.self_hosted_image_base_url", "http://localhost:7860/v1")

    user = await _create_verified_user(db_session, "imgok@example.com", "imgok")
    headers = await _login(client, "imgok@example.com")
    balance_before = user.token_balance

    fake_png = b"\x89PNG\r\n\x1a\nfakepngdata"
    b64 = base64.b64encode(fake_png).decode("ascii")

    fake_post = await _fake_external_post({"data": [{"b64_json": b64}]})

    with patch("httpx.AsyncClient.post", new=fake_post):
        resp = await client.post("/api/v1/media/image/generate", json={"prompt": "кот в шляпе"}, headers=headers)

    assert resp.status_code == 200
    assert base64.b64decode(resp.json()["image_base64"]) == fake_png

    await db_session.refresh(user)
    assert user.token_balance == balance_before - 2  # C2=1.6, округление вверх до 2


@pytest.mark.asyncio
async def test_video_generate_gated_by_tariff(client, db_session):
    await _create_verified_user(db_session, "freetier@example.com", "freetier")
    headers = await _login(client, "freetier@example.com")

    resp = await client.post(
        "/api/v1/media/video/generate",
        json={"prompt": "закат", "duration_seconds": 3},
        headers=headers,
    )
    assert resp.status_code == 403  # FREE не имеет доступа к видео


@pytest.mark.asyncio
async def test_video_generate_success_deducts_c3(client, db_session, monkeypatch):
    from app.database.models import SubscriptionTier

    monkeypatch.setattr("app.core.media.video_client.settings.video_generation_enabled", True)
    monkeypatch.setattr("app.core.media.video_client.settings.self_hosted_video_base_url", "http://localhost:7861/v1")

    user = await _create_verified_user(db_session, "ultrauser@example.com", "ultrauser")
    user.subscription_tier = SubscriptionTier.ULTRA
    await db_session.commit()
    headers = await _login(client, "ultrauser@example.com")
    await db_session.refresh(user)  # логин может пополнить баланс под новый тариф
    balance_before = user.token_balance

    fake_mp4 = b"\x00\x00\x00\x18ftypmp42fakevideodata"
    b64 = base64.b64encode(fake_mp4).decode("ascii")

    fake_post = await _fake_external_post({"data": [{"b64_json": b64}]})

    with patch("httpx.AsyncClient.post", new=fake_post):
        resp = await client.post(
            "/api/v1/media/video/generate", json={"prompt": "закат", "duration_seconds": 5}, headers=headers
        )

    assert resp.status_code == 200
    assert base64.b64decode(resp.json()["video_base64"]) == fake_mp4

    await db_session.refresh(user)
    assert user.token_balance == balance_before - 80  # C3=16/сек * 5 сек = 80


@pytest.mark.asyncio
async def test_video_generate_returns_503_without_config(client, db_session):
    user = await _create_verified_user(db_session, "videouser@example.com", "videouser")
    user.subscription_tier = __import__("app.database.models", fromlist=["SubscriptionTier"]).SubscriptionTier.ULTRA
    await db_session.commit()
    headers = await _login(client, "videouser@example.com")

    resp = await client.post(
        "/api/v1/media/video/generate",
        json={"prompt": "закат", "duration_seconds": 3},
        headers=headers,
    )
    assert resp.status_code == 503


@pytest.mark.asyncio
async def test_video_generate_forbidden_for_free_tier(client, db_session):
    await _create_verified_user(db_session, "videofree@example.com", "videofree")
    headers = await _login(client, "videofree@example.com")

    resp = await client.post("/api/v1/media/video/generate", json={"prompt": "закат"}, headers=headers)
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_video_generate_success_deducts_c3_alt_url(client, db_session, monkeypatch):
    from app.database.models import SubscriptionTier

    monkeypatch.setattr("app.core.media.video_client.settings.video_generation_enabled", True)
    monkeypatch.setattr("app.core.media.video_client.settings.self_hosted_video_base_url", "http://localhost:8188/v1")

    user = await _create_verified_user(db_session, "videook@example.com", "videook")
    user.subscription_tier = SubscriptionTier.ULTRA
    await db_session.commit()
    headers = await _login(client, "videook@example.com")
    await db_session.refresh(user)  # логин может пополнить баланс под новый тариф
    balance_before = user.token_balance

    fake_mp4 = b"fakevideobytes"
    b64 = base64.b64encode(fake_mp4).decode("ascii")

    fake_post = await _fake_external_post({"data": [{"b64_json": b64}]})

    with patch("httpx.AsyncClient.post", new=fake_post):
        resp = await client.post(
            "/api/v1/media/video/generate",
            json={"prompt": "закат", "duration_seconds": 2},
            headers=headers,
        )

    assert resp.status_code == 200
    assert base64.b64decode(resp.json()["video_base64"]) == fake_mp4

    await db_session.refresh(user)
    assert user.token_balance == balance_before - 32  # C3=16/сек * 2 сек
