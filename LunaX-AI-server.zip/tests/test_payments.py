"""
Тесты платёжного модуля (финальное ТЗ раздел 10-12): checkout без
сконфигурированного provider, идемпотентность webhook, активация тарифа.

Т.к. реальные Kaspi/FreedomPay credentials не заданы, checkout честно
возвращает 503 (provider не сконфигурирован) — это ОЖИДАЕМОЕ поведение,
не баг. Полный happy-path (webhook -> активация тарифа) тестируется
напрямую через process_webhook с моком provider, минуя настоящий Kaspi/
FreedomPay HTTP-вызов.

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
from unittest.mock import MagicMock, patch

import pytest

from app.core.payments.base import WebhookEvent
from app.database.models import Payment, PaymentStatus, SubscriptionTier, User, UserRole
from app.modules.auth.services import hash_password
from app.modules.payments.services import process_webhook


async def _create_verified_user(db_session, email="payer@example.com", username="payer"):
    user = User(
        email=email,
        username=username,
        hashed_password=hash_password("password123"),
        role=UserRole.USER,
        is_active=True,
        email_verified=True,
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


async def _login(client, email, password="password123"):
    resp = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert resp.status_code == 200, resp.text
    return {"Authorization": f"Bearer {resp.json()['access_token']}"}


@pytest.mark.asyncio
async def test_checkout_returns_503_without_provider_credentials(client, db_session):
    await _create_verified_user(db_session)
    headers = await _login(client, "payer@example.com")

    resp = await client.post("/api/v1/payments/checkout", json={"tariff": "pro"}, headers=headers)
    # Provider не сконфигурирован (нет KASPI_MERCHANT_ID/KASPI_API_KEY) -> честный 503.
    assert resp.status_code == 503


@pytest.mark.asyncio
async def test_checkout_rejects_free_tariff(client, db_session):
    await _create_verified_user(db_session, "freepayer@example.com", "freepayer")
    headers = await _login(client, "freepayer@example.com")

    resp = await client.post("/api/v1/payments/checkout", json={"tariff": "free"}, headers=headers)
    assert resp.status_code == 400


@pytest.mark.asyncio
async def test_webhook_activates_tariff_and_updates_balance(db_session):
    user = await _create_verified_user(db_session, "activate@example.com", "activateuser")
    payment = Payment(
        user_id=user.id, provider="kaspi", tariff=SubscriptionTier.PRO,
        amount_kzt=10_000, status=PaymentStatus.PENDING, external_payment_id="ext-123",
    )
    db_session.add(payment)
    await db_session.commit()
    await db_session.refresh(payment)

    fake_event = WebhookEvent(
        external_payment_id="ext-123", status="succeeded", amount_kzt=10_000, raw_payload={"ok": True}
    )
    with patch("app.modules.payments.services.get_provider") as mock_get_provider:
        mock_provider = MagicMock()
        mock_provider.name = "kaspi"
        mock_provider.verify_and_parse_webhook.return_value = fake_event
        mock_get_provider.return_value = mock_provider

        result = await process_webhook(db_session, "kaspi", {}, b"{}")

    assert result["status"] == "succeeded"
    await db_session.refresh(user)
    assert user.subscription_tier == SubscriptionTier.PRO
    assert user.token_balance == 10_000_000
    assert user.token_limit == 10_000_000


@pytest.mark.asyncio
async def test_webhook_idempotent_on_repeat(db_session):
    user = await _create_verified_user(db_session, "idem@example.com", "idemuser")
    payment = Payment(
        user_id=user.id, provider="kaspi", tariff=SubscriptionTier.ULTRA,
        amount_kzt=20_000, status=PaymentStatus.PENDING, external_payment_id="ext-456",
    )
    db_session.add(payment)
    await db_session.commit()
    await db_session.refresh(payment)

    fake_event = WebhookEvent(
        external_payment_id="ext-456", status="succeeded", amount_kzt=20_000, raw_payload={"ok": True}
    )
    with patch("app.modules.payments.services.get_provider") as mock_get_provider:
        mock_provider = MagicMock()
        mock_provider.name = "kaspi"
        mock_provider.verify_and_parse_webhook.return_value = fake_event
        mock_get_provider.return_value = mock_provider

        first = await process_webhook(db_session, "kaspi", {}, b"{}")
        second = await process_webhook(db_session, "kaspi", {}, b"{}")

    assert first["status"] == "succeeded"
    assert second["status"] == "already_processed"

    await db_session.refresh(user)
    # Баланс равен ровно лимиту тарифа один раз, а не удвоен повторной активацией.
    assert user.token_balance == 20_000_000
