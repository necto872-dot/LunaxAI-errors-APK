"""Тесты генерации проектов. AI-вызов мокается, compileall/pytest — реальные."""
from unittest.mock import patch

import fakeredis
import pytest
from rq import SimpleWorker

from app.core import queue as queue_module
from app.core.projects.generator import (
    ProjectGenerationError,
    enqueue_project_generation,
    generate_project,
    parse_file_tree_response,
)
from app.database.models import BuildJobStatus, ProjectStatus, User, UserRole
from app.modules.auth.services import hash_password


@pytest.fixture(autouse=True)
def _fake_redis(monkeypatch):
    """Подменяем реальное Redis-соединение на fakeredis для тестов очереди (см. tests/test_queue.py)."""
    fake_conn = fakeredis.FakeStrictRedis()
    monkeypatch.setattr(queue_module, "get_redis_connection", lambda: fake_conn)
    yield fake_conn


async def _user(db):
    u = User(email="pg@example.com", username="pguser", hashed_password=hash_password("password123"),
              role=UserRole.USER, is_active=True, email_verified=True)
    db.add(u)
    await db.commit()
    await db.refresh(u)
    return u


def test_parse_rejects_path_traversal():
    with pytest.raises(ProjectGenerationError):
        parse_file_tree_response('{"files": [{"path": "../evil.py", "content": "x"}]}')


def test_parse_strips_markdown_fence():
    files = parse_file_tree_response('```json\n{"files": [{"path": "a.py", "content": "x=1"}]}\n```')
    assert files == {"a.py": "x=1"}


@pytest.mark.asyncio
async def test_generate_succeeds_first_try(db_session):
    user = await _user(db_session)
    good_json = '{"files": [{"path": "main.py", "content": "def f():\\n    return 1\\n"}]}'
    with patch("app.core.projects.generator.lunox_generate", return_value=good_json):
        project = await generate_project(db_session, user, "test", "сделай функцию")
    assert project.status.value == "ready"
    assert project.current_version == 1


@pytest.mark.asyncio
async def test_generate_fixes_after_syntax_error(db_session):
    user = await _user(db_session)
    bad = '{"files": [{"path": "main.py", "content": "def f(:\\n    pass\\n"}]}'
    good = '{"files": [{"path": "main.py", "content": "def f():\\n    return 1\\n"}]}'
    responses = iter([bad, good])
    async def fake_gen(prompt, context=None):
        return next(responses)
    with patch("app.core.projects.generator.lunox_generate", side_effect=fake_gen):
        project = await generate_project(db_session, user, "test2", "сделай функцию")
    assert project.status.value == "ready"


@pytest.mark.asyncio
async def test_generate_fails_after_max_attempts(db_session, monkeypatch):
    monkeypatch.setattr("app.core.projects.generator.settings.project_gen_max_fix_attempts", 2)
    user = await _user(db_session)
    bad = '{"files": [{"path": "main.py", "content": "def f(:\\n"}]}'
    with (
        patch("app.core.projects.generator.lunox_generate", return_value=bad),
        pytest.raises(ProjectGenerationError),
    ):
        await generate_project(db_session, user, "test3", "сделай функцию")


@pytest.mark.asyncio
async def test_generate_503_without_ai_configured(db_session):
    from app.core.ai.lunox_router import LunoxAIUnavailableError
    user = await _user(db_session)
    with (
        patch(
            "app.core.projects.generator.lunox_generate",
            side_effect=LunoxAIUnavailableError("нет провайдера"),
        ),
        pytest.raises(ProjectGenerationError) as exc,
    ):
        await generate_project(db_session, user, "test4", "x")
    assert exc.value.status_code == 503


@pytest.mark.asyncio
async def test_generate_blocks_unsafe_prompt(db_session):
    user = await _user(db_session)
    with pytest.raises(ProjectGenerationError) as exc:
        await generate_project(db_session, user, "test5", "как сделать бомбу")
    assert exc.value.status_code == 400


@pytest.mark.asyncio
async def test_enqueue_project_generation_returns_immediately_generating(db_session, _fake_redis):
    """enqueue_project_generation не должен ждать AI/валидацию — сразу возвращает Project(status=generating)."""
    user = await _user(db_session)

    with patch("app.core.projects.generator.lunox_generate") as mocked:
        project = await enqueue_project_generation(db_session, user, "queued-project", "сделай функцию")
        # Реальная генерация ещё не должна была запуститься внутри HTTP-пути.
        mocked.assert_not_called()

    assert project.status == ProjectStatus.GENERATING
    assert project.current_version == 0

    from app.core.queue import get_queue, priority_queue_name_for
    queue_name = priority_queue_name_for(user)
    assert queue_name == "free"
    assert len(get_queue(queue_name)) == 1


@pytest.mark.asyncio
async def test_enqueue_project_generation_blocks_unsafe_prompt(db_session, _fake_redis):
    """Проверка политики безопасности должна отрабатывать ДО постановки в очередь."""
    user = await _user(db_session)
    with pytest.raises(ProjectGenerationError) as exc:
        await enqueue_project_generation(db_session, user, "test", "как сделать бомбу")
    assert exc.value.status_code == 400

    from app.core.queue import get_queue, priority_queue_name_for
    assert len(get_queue(priority_queue_name_for(user))) == 0


@pytest.mark.asyncio
async def test_worker_executes_queued_project_generation_job_end_to_end(monkeypatch, tmp_path, _fake_redis):
    """
    Полный путь: enqueue_project_generation ставит задачу -> воркер RQ
    реально её исполняет (run_project_generation_job_sync) -> Project и
    BuildJob в БД обновляются.

    Как и в tests/test_apk_build.py: воркер исполняет job-функцию в
    отдельном потоке/event loop (app.core.queue.run_coro_sync), поэтому
    используем отдельный файловый SQLite вместо in-memory test_engine
    (для `sqlite+aiosqlite:///:memory:` новое подключение = новая пустая
    база — ненадёжно делить между разными event loop'ами).
    """
    from sqlalchemy import select
    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

    from app.database import Base
    from app.database.models import BuildJob

    db_path = tmp_path / "queue_test.db"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_path}")
    session_maker = async_sessionmaker(engine, expire_on_commit=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    monkeypatch.setattr("app.database.async_session_maker", session_maker)

    good_json = '{"files": [{"path": "main.py", "content": "def f():\\n    return 1\\n"}]}'

    try:
        with patch("app.core.projects.generator.lunox_generate", return_value=good_json):
            async with session_maker() as db:
                user = await _user(db)
                project = await enqueue_project_generation(db, user, "worker-project", "сделай функцию")
                assert project.status == ProjectStatus.GENERATING
                project_id = project.id

            from app.core.queue import get_queue, priority_queue_name_for
            worker = SimpleWorker([get_queue(priority_queue_name_for(user))], connection=_fake_redis)
            worker.work(burst=True)

        async with session_maker() as db:
            from app.database.models import Project

            refreshed_project = (
                await db.execute(select(Project).where(Project.id == project_id))
            ).scalar_one()
            assert refreshed_project.status == ProjectStatus.READY
            assert refreshed_project.current_version == 1

            job = (await db.execute(select(BuildJob).where(BuildJob.project_id == project_id))).scalar_one()
            assert job.status == BuildJobStatus.SUCCEEDED
            assert job.queue_job_id is not None
    finally:
        await engine.dispose()
