"""
Тесты голоса (app/core/voice/client.py, app/modules/voice/routers.py):
честный 503 без конфигурации, реальный вызов self-hosted сервера
мокается.

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
import io
from unittest.mock import MagicMock, patch

import pytest

from app.database.models import User, UserRole
from app.modules.auth.services import hash_password


async def _create_verified_user(db_session, email="voiceuser@example.com", username="voiceuser"):
    user = User(
        email=email,
        username=username,
        hashed_password=hash_password("password123"),
        role=UserRole.USER,
        is_active=True,
        email_verified=True,
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


async def _login(client, email, password="password123"):
    resp = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert resp.status_code == 200, resp.text
    return {"Authorization": f"Bearer {resp.json()['access_token']}"}


@pytest.mark.asyncio
async def test_stt_returns_503_without_config(client, db_session):
    await _create_verified_user(db_session)
    headers = await _login(client, "voiceuser@example.com")

    resp = await client.post(
        "/api/v1/voice/stt",
        files={"audio": ("test.wav", io.BytesIO(b"fakewavdata"), "audio/wav")},
        headers=headers,
    )
    assert resp.status_code == 503


@pytest.mark.asyncio
async def test_tts_returns_503_without_config(client, db_session):
    await _create_verified_user(db_session, "ttsuser@example.com", "ttsuser")
    headers = await _login(client, "ttsuser@example.com")

    resp = await client.post("/api/v1/voice/tts", json={"text": "привет"}, headers=headers)
    assert resp.status_code == 503


@pytest.mark.asyncio
async def test_stt_success_returns_transcribed_text(client, db_session, monkeypatch):
    monkeypatch.setattr("app.core.voice.client.settings.voice_enabled", True)
    monkeypatch.setattr("app.core.voice.client.settings.self_hosted_stt_base_url", "http://localhost:9000/v1")

    await _create_verified_user(db_session, "sttok@example.com", "sttok")
    headers = await _login(client, "sttok@example.com")

    async def fake_post(self, url, headers=None, files=None, data=None):
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = {"text": "привет мир"}
        return resp

    with patch("httpx.AsyncClient.post", new=fake_post):
        resp = await client.post(
            "/api/v1/voice/stt",
            files={"audio": ("test.wav", io.BytesIO(b"fakewavdata"), "audio/wav")},
            headers=headers,
        )

    assert resp.status_code == 200
    assert resp.json()["text"] == "привет мир"


@pytest.mark.asyncio
async def test_tts_success_returns_audio_bytes(client, db_session, monkeypatch):
    monkeypatch.setattr("app.core.voice.client.settings.voice_enabled", True)
    monkeypatch.setattr("app.core.voice.client.settings.self_hosted_tts_base_url", "http://localhost:9001/v1")

    await _create_verified_user(db_session, "ttsok@example.com", "ttsok")
    headers = await _login(client, "ttsok@example.com")

    fake_audio = b"RIFF_fake_wav_bytes"

    async def fake_post(self, url, headers=None, json=None):
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.content = fake_audio
        return resp

    with patch("httpx.AsyncClient.post", new=fake_post):
        resp = await client.post("/api/v1/voice/tts", json={"text": "привет"}, headers=headers)

    assert resp.status_code == 200
    assert resp.content == fake_audio
