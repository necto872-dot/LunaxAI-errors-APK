"""
Тест rate limiting на login (ТЗ раздел 41/20).

Значения лимитов — технические дефолты (settings.rate_limit_*), не
согласованное бизнес-решение. Тест проверяет сам МЕХАНИЗМ (после N
неудачных попыток -> 429), а не конкретную цифру как «истину».

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
import pytest

from app.core.rate_limit import _hits


@pytest.fixture(autouse=True)
def _reset_rate_limit_state():
    _hits.clear()
    yield
    _hits.clear()


@pytest.mark.asyncio
async def test_login_rate_limited_after_threshold(client, monkeypatch):
    monkeypatch.setattr("app.core.rate_limit.settings.rate_limit_login_per_minute", 3)

    for _ in range(3):
        resp = await client.post(
            "/api/v1/auth/login", json={"email": "nobody@example.com", "password": "wrong"}
        )
        assert resp.status_code == 401  # обычная ошибка, лимит ещё не исчерпан

    limited = await client.post(
        "/api/v1/auth/login", json={"email": "nobody@example.com", "password": "wrong"}
    )
    assert limited.status_code == 429


@pytest.mark.asyncio
async def test_rate_limit_disabled_flag_bypasses(client, monkeypatch):
    monkeypatch.setattr("app.core.rate_limit.settings.rate_limit_enabled", False)
    monkeypatch.setattr("app.core.rate_limit.settings.rate_limit_login_per_minute", 1)

    for _ in range(5):
        resp = await client.post(
            "/api/v1/auth/login", json={"email": "nobody@example.com", "password": "wrong"}
        )
        assert resp.status_code == 401  # НЕ 429, лимитер выключен флагом
