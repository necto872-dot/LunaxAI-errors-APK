"""
Auth flow tests (LunaX_AI_TZ.txt раздел 56).

NOT VERIFIED в этом окружении — см. tests/conftest.py.
"""
import pytest


def _token_for(client, kind: str) -> str:
    for k, _email, token in client.captured_tokens:
        if k == kind:
            return token
    raise AssertionError(f"no captured token of kind={kind}")


@pytest.mark.asyncio
async def test_register_success(client):
    resp = await client.post(
        "/api/v1/auth/register",
        json={
            "email": "user1@example.com",
            "username": "user1",
            "password": "password123",
            "date_of_birth": "2000-01-01",
            "accept_terms": True,
        },
    )
    assert resp.status_code == 201
    body = resp.json()
    assert body["email"] == "user1@example.com"
    assert body["email_verified"] is False


@pytest.mark.asyncio
async def test_register_duplicate_email(client):
    payload = {
        "email": "dup@example.com",
        "username": "dupuser",
        "password": "password123",
        "date_of_birth": "2000-01-01",
        "accept_terms": True,
    }
    r1 = await client.post("/api/v1/auth/register", json=payload)
    assert r1.status_code == 201
    r2 = await client.post(
        "/api/v1/auth/register",
        json={**payload, "username": "otheruser"},
    )
    assert r2.status_code == 409


@pytest.mark.asyncio
async def test_login_unverified_returns_403(client):
    await client.post(
        "/api/v1/auth/register",
        json={
            "email": "unverified@example.com",
            "username": "unverified",
            "password": "password123",
            "date_of_birth": "2000-01-01",
            "accept_terms": True,
        },
    )
    resp = await client.post(
        "/api/v1/auth/login", json={"email": "unverified@example.com", "password": "password123"}
    )
    assert resp.status_code == 403


@pytest.mark.asyncio
async def test_verify_email_then_login(client):
    await client.post(
        "/api/v1/auth/register",
        json={
            "email": "verify@example.com",
            "username": "verifyuser",
            "password": "password123",
            "date_of_birth": "2000-01-01",
            "accept_terms": True,
        },
    )
    token = _token_for(client, "verify")

    resp = await client.post("/api/v1/auth/verify-email", json={"token": token})
    assert resp.status_code == 200
    assert resp.json()["email_verified"] is True

    login = await client.post(
        "/api/v1/auth/login", json={"email": "verify@example.com", "password": "password123"}
    )
    assert login.status_code == 200
    assert "access_token" in login.json()


@pytest.mark.asyncio
async def test_verify_email_invalid_token(client):
    resp = await client.post("/api/v1/auth/verify-email", json={"token": "not-a-real-token"})
    assert resp.status_code == 400


@pytest.mark.asyncio
async def test_verify_email_token_reuse_rejected(client):
    await client.post(
        "/api/v1/auth/register",
        json={
            "email": "reuse@example.com",
            "username": "reuseuser",
            "password": "password123",
            "date_of_birth": "2000-01-01",
            "accept_terms": True,
        },
    )
    token = _token_for(client, "verify")
    r1 = await client.post("/api/v1/auth/verify-email", json={"token": token})
    assert r1.status_code == 200
    r2 = await client.post("/api/v1/auth/verify-email", json={"token": token})
    assert r2.status_code == 400


@pytest.mark.asyncio
async def test_login_wrong_password(client):
    await client.post(
        "/api/v1/auth/register",
        json={
            "email": "wrongpass@example.com",
            "username": "wrongpassuser",
            "password": "password123",
            "date_of_birth": "2000-01-01",
            "accept_terms": True,
        },
    )
    token = _token_for(client, "verify")
    await client.post("/api/v1/auth/verify-email", json={"token": token})

    resp = await client.post(
        "/api/v1/auth/login", json={"email": "wrongpass@example.com", "password": "incorrect"}
    )
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_login_nonexistent_user(client):
    resp = await client.post(
        "/api/v1/auth/login", json={"email": "nobody@example.com", "password": "password123"}
    )
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_forgot_password_unknown_email_same_response(client):
    resp = await client.post("/api/v1/auth/forgot-password", json={"email": "ghost@example.com"})
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


@pytest.mark.asyncio
async def test_forgot_and_reset_password_flow(client):
    await client.post(
        "/api/v1/auth/register",
        json={
            "email": "reset@example.com",
            "username": "resetuser",
            "password": "oldpassword1",
            "date_of_birth": "2000-01-01",
            "accept_terms": True,
        },
    )
    verify_token = _token_for(client, "verify")
    await client.post("/api/v1/auth/verify-email", json={"token": verify_token})

    await client.post("/api/v1/auth/forgot-password", json={"email": "reset@example.com"})
    reset_token = _token_for(client, "reset")

    resp = await client.post(
        "/api/v1/auth/reset-password", json={"token": reset_token, "new_password": "newpassword1"}
    )
    assert resp.status_code == 200

    old_login = await client.post(
        "/api/v1/auth/login", json={"email": "reset@example.com", "password": "oldpassword1"}
    )
    assert old_login.status_code == 401

    new_login = await client.post(
        "/api/v1/auth/login", json={"email": "reset@example.com", "password": "newpassword1"}
    )
    assert new_login.status_code == 200


@pytest.mark.asyncio
async def test_reset_token_reuse_rejected(client):
    await client.post(
        "/api/v1/auth/register",
        json={
            "email": "resetreuse@example.com",
            "username": "resetreuse",
            "password": "oldpassword1",
            "date_of_birth": "2000-01-01",
            "accept_terms": True,
        },
    )
    verify_token = _token_for(client, "verify")
    await client.post("/api/v1/auth/verify-email", json={"token": verify_token})
    await client.post("/api/v1/auth/forgot-password", json={"email": "resetreuse@example.com"})
    reset_token = _token_for(client, "reset")

    r1 = await client.post(
        "/api/v1/auth/reset-password", json={"token": reset_token, "new_password": "newpassword1"}
    )
    assert r1.status_code == 200
    r2 = await client.post(
        "/api/v1/auth/reset-password", json={"token": reset_token, "new_password": "anotherpassword"}
    )
    assert r2.status_code == 400


@pytest.mark.asyncio
async def test_change_email_flow(client):
    await client.post(
        "/api/v1/auth/register",
        json={
            "email": "old@example.com",
            "username": "changeemail",
            "password": "password123",
            "date_of_birth": "2000-01-01",
            "accept_terms": True,
        },
    )
    verify_token = _token_for(client, "verify")
    await client.post("/api/v1/auth/verify-email", json={"token": verify_token})
    login = await client.post(
        "/api/v1/auth/login", json={"email": "old@example.com", "password": "password123"}
    )
    access_token = login.json()["access_token"]
    headers = {"Authorization": f"Bearer {access_token}"}

    wrong_pw = await client.post(
        "/api/v1/auth/change-email",
        json={"new_email": "new@example.com", "current_password": "wrong"},
        headers=headers,
    )
    assert wrong_pw.status_code == 401

    ok = await client.post(
        "/api/v1/auth/change-email",
        json={"new_email": "new@example.com", "current_password": "password123"},
        headers=headers,
    )
    assert ok.status_code == 200

    change_token = _token_for(client, "change")
    confirm = await client.post("/api/v1/auth/confirm-email-change", json={"token": change_token})
    assert confirm.status_code == 200
    assert confirm.json()["email"] == "new@example.com"


@pytest.mark.asyncio
async def test_change_email_to_occupied_address(client):
    await client.post(
        "/api/v1/auth/register",
        json={
            "email": "userA@example.com",
            "username": "userA",
            "password": "password123",
            "date_of_birth": "2000-01-01",
            "accept_terms": True,
        },
    )
    await client.post(
        "/api/v1/auth/register",
        json={
            "email": "userB@example.com",
            "username": "userB",
            "password": "password123",
            "date_of_birth": "2000-01-01",
            "accept_terms": True,
        },
    )
    verify_a = _token_for(client, "verify")
    await client.post("/api/v1/auth/verify-email", json={"token": verify_a})
    login = await client.post(
        "/api/v1/auth/login", json={"email": "userA@example.com", "password": "password123"}
    )
    headers = {"Authorization": f"Bearer {login.json()['access_token']}"}

    resp = await client.post(
        "/api/v1/auth/change-email",
        json={"new_email": "userB@example.com", "current_password": "password123"},
        headers=headers,
    )
    assert resp.status_code == 409
