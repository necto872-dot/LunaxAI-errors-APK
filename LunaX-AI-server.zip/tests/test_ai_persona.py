"""
Тесты персоны Lunox AI (app/core/ai/persona.py) для self-hosted
архитектуры: системный промпт реально попадает в каждый исходящий
запрос к собственному инференс-серверу.

Реальные HTTP-запросы НЕ выполняются — httpx.AsyncClient.post мокается,
проверяется только собранный payload перед отправкой.

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
from unittest.mock import MagicMock, patch

import pytest

from app.core.ai.persona import LUNOX_SYSTEM_PROMPT
from app.core.ai.providers import SelfHostedProvider


def _mock_response(json_body: dict):
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = json_body
    resp.raise_for_status = MagicMock()
    return resp


@pytest.mark.asyncio
async def test_self_hosted_generate_includes_system_prompt():
    provider = SelfHostedProvider(base_url="http://localhost:8000/v1", model_name="lunox-finetuned")

    captured = {}

    async def fake_post(self, url, headers=None, json=None):
        captured["payload"] = json
        return _mock_response({"choices": [{"message": {"content": "привет"}}]})

    with patch("httpx.AsyncClient.post", new=fake_post):
        result = await provider.generate("привет")

    messages = captured["payload"]["messages"]
    assert messages[0] == {"role": "system", "content": LUNOX_SYSTEM_PROMPT}
    assert messages[-1] == {"role": "user", "content": "привет"}
    assert result.text == "привет"
    assert result.provider_used == "self_hosted"


@pytest.mark.asyncio
async def test_self_hosted_uses_configured_model_name():
    provider = SelfHostedProvider(base_url="http://localhost:8000/v1", model_name="my-custom-checkpoint-v3")

    captured = {}

    async def fake_post(self, url, headers=None, json=None):
        captured["payload"] = json
        captured["url"] = url
        return _mock_response({"choices": [{"message": {"content": "ok"}}]})

    with patch("httpx.AsyncClient.post", new=fake_post):
        await provider.generate("test")

    assert captured["payload"]["model"] == "my-custom-checkpoint-v3"
    assert captured["url"] == "http://localhost:8000/v1/chat/completions"


def test_persona_never_reveals_provider_identity_in_prompt_text():
    """Смысловая проверка: промпт явно запрещает называть себя чужим брендом."""
    lowered = LUNOX_SYSTEM_PROMPT.lower()
    assert "lunox ai" in lowered
    forbidden_admissions = ["ты — chatgpt", "ты — claude", "i am gpt", "i am claude"]
    assert not any(phrase in lowered for phrase in forbidden_admissions)


def test_provider_not_configured_without_base_url_or_model():
    empty = SelfHostedProvider(base_url="", model_name="")
    assert empty.is_configured() is False

    partial = SelfHostedProvider(base_url="http://localhost:8000/v1", model_name="")
    assert partial.is_configured() is False

    full = SelfHostedProvider(base_url="http://localhost:8000/v1", model_name="lunox-v1")
    assert full.is_configured() is True


def test_persona_forbids_competing_ai_product_creation():
    from app.core.ai.persona import LUNOX_SYSTEM_PROMPT
    lowered = LUNOX_SYSTEM_PROMPT.lower()
    assert "конкурирующ" in lowered
