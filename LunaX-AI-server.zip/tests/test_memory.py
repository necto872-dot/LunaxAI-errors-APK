"""
Тесты памяти Lunox AI (app/core/ai/memory.py) — закрывает главный пробел
из аудита: диалоги сохраняются, история подгружается как контекст,
долговременные факты работают через явный remember/forget, чужой
conversation_id/fact_id недоступен другому пользователю.

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
import pytest

from app.database.models import User, UserRole
from app.modules.auth.services import hash_password


async def _create_verified_user(db_session, email, username):
    user = User(
        email=email,
        username=username,
        hashed_password=hash_password("password123"),
        role=UserRole.USER,
        is_active=True,
        email_verified=True,
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


async def _login(client, email, password="password123"):
    resp = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert resp.status_code == 200, resp.text
    return {"Authorization": f"Bearer {resp.json()['access_token']}"}


@pytest.mark.asyncio
async def test_chat_without_ai_configured_returns_503_no_conversation_saved(client, db_session):
    await _create_verified_user(db_session, "chatter1@example.com", "chatter1")
    headers = await _login(client, "chatter1@example.com")

    resp = await client.post("/api/v1/search/query", json={"prompt": "привет"}, headers=headers)
    assert resp.status_code == 503

    convos = await client.get("/api/v1/search/conversations", headers=headers)
    assert convos.status_code == 200
    assert convos.json() == []  # AI не ответил -> диалог не создался/не сохранился


@pytest.mark.asyncio
async def test_remember_list_forget_facts(client, db_session):
    await _create_verified_user(db_session, "rememberer@example.com", "rememberer")
    headers = await _login(client, "rememberer@example.com")

    r1 = await client.post("/api/v1/memory/remember", json={"content": "Меня зовут Гайджи"}, headers=headers)
    assert r1.status_code == 201
    fact_id = r1.json()["id"]

    r2 = await client.post("/api/v1/memory/remember", json={"content": "Работаю над LunaX AI"}, headers=headers)
    assert r2.status_code == 201

    facts = await client.get("/api/v1/memory/facts", headers=headers)
    assert facts.status_code == 200
    assert len(facts.json()) == 2

    forget_resp = await client.delete(f"/api/v1/memory/forget/{fact_id}", headers=headers)
    assert forget_resp.status_code == 200

    facts_after = await client.get("/api/v1/memory/facts", headers=headers)
    assert len(facts_after.json()) == 1
    assert facts_after.json()[0]["content"] == "Работаю над LunaX AI"


@pytest.mark.asyncio
async def test_cannot_forget_other_users_fact(client, db_session):
    await _create_verified_user(db_session, "owner3@example.com", "owner3")
    await _create_verified_user(db_session, "intruder3@example.com", "intruder3")

    owner_headers = await _login(client, "owner3@example.com")
    intruder_headers = await _login(client, "intruder3@example.com")

    created = await client.post("/api/v1/memory/remember", json={"content": "секрет"}, headers=owner_headers)
    fact_id = created.json()["id"]

    resp = await client.delete(f"/api/v1/memory/forget/{fact_id}", headers=intruder_headers)
    assert resp.status_code == 404

    still_there = await client.get("/api/v1/memory/facts", headers=owner_headers)
    assert len(still_there.json()) == 1


@pytest.mark.asyncio
async def test_cannot_access_other_users_conversation(client, db_session):
    from app.core.ai.memory import append_message_pair, get_or_create_conversation

    owner = await _create_verified_user(db_session, "convowner@example.com", "convowner")
    await _create_verified_user(db_session, "convintruder@example.com", "convintruder")

    conversation = await get_or_create_conversation(db_session, owner, None)
    await append_message_pair(db_session, owner, conversation, "привет", "привет от Lunox")

    intruder_headers = await _login(client, "convintruder@example.com")

    resp = await client.get(f"/api/v1/search/conversations/{conversation.id}/messages", headers=intruder_headers)
    assert resp.status_code == 404

    delete_resp = await client.delete(f"/api/v1/search/conversations/{conversation.id}", headers=intruder_headers)
    assert delete_resp.status_code == 404


@pytest.mark.asyncio
async def test_recent_context_respects_short_term_limit(db_session, monkeypatch):
    from app.core.ai.memory import (
        append_message_pair,
        get_or_create_conversation,
        get_recent_context,
    )

    monkeypatch.setattr("app.core.ai.memory.settings.lunox_memory_short_term_messages", 4)

    user = await _create_verified_user(db_session, "longchat@example.com", "longchat")
    conversation = await get_or_create_conversation(db_session, user, None)

    for i in range(5):
        await append_message_pair(db_session, user, conversation, f"вопрос {i}", f"сообщение {i}")

    context = await get_recent_context(db_session, conversation)
    assert len(context) == 4
    # Последние 4 по времени из 10 (5 пар) сообщений, в хронологическом
    # порядке (не перевёрнутые): вопрос3, сообщение3, вопрос4, сообщение4.
    assert context[-1]["content"] == "сообщение 4"
    assert context[0]["content"] == "вопрос 3"
