"""
Тесты очереди задач (app/core/queue.py) — реальная RQ-интеграция против
fakeredis (in-memory реализация протокола Redis, не настоящий сервер —
см. честное ограничение в docstring app/core/queue.py).

RQ по умолчанию исполняет задачи асинхронно воркером; в тестах используем
SimpleWorker с burst=True, чтобы обработать задачу синхронно и сразу
проверить результат, без поднятия отдельного процесса-воркера.

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
import fakeredis
import pytest
from rq import SimpleWorker

from app.core import queue as queue_module


@pytest.fixture(autouse=True)
def _fake_redis(monkeypatch):
    """Подменяем реальное Redis-соединение на fakeredis для каждого теста."""
    fake_conn = fakeredis.FakeStrictRedis()
    monkeypatch.setattr(queue_module, "get_redis_connection", lambda: fake_conn)
    yield fake_conn


def test_enqueue_and_process_job_returns_expected_result(_fake_redis):
    job_id = queue_module.enqueue_job("default", queue_module.echo_job, "ping")
    assert job_id

    worker = SimpleWorker([queue_module.get_queue("default")], connection=_fake_redis)
    worker.work(burst=True)

    status = queue_module.get_job_status(job_id)
    assert status["status"] == "finished"
    assert status["result"] == "processed: ping"
    assert status["error"] is None


def test_job_status_before_processing_is_queued(_fake_redis):
    job_id = queue_module.enqueue_job("default", queue_module.echo_job, "not yet processed")

    status = queue_module.get_job_status(job_id)
    assert status["status"] == "queued"
    assert status["result"] is None


def test_unknown_job_id_raises_no_such_job_error(_fake_redis):
    from rq.exceptions import NoSuchJobError

    with pytest.raises(NoSuchJobError):
        queue_module.get_job_status("does-not-exist")


def test_cancel_job_prevents_execution(_fake_redis):
    job_id = queue_module.enqueue_job("default", queue_module.echo_job, "will be cancelled")
    queue_module.cancel_job(job_id)

    worker = SimpleWorker([queue_module.get_queue("default")], connection=_fake_redis)
    worker.work(burst=True)

    status = queue_module.get_job_status(job_id)
    assert status["status"] != "finished"


@pytest.mark.asyncio
async def test_queue_router_reachable_via_http(client, db_session, _fake_redis):
    """
    Регрессия на конкретный найденный баг: queue_router был объявлен в
    модуле, но не зарегистрирован в main.py — эндпоинты были физически
    недостижимы (404 на любой запрос, даже с валидным JWT).
    """
    from datetime import date

    from app.database.models import User, UserRole
    from app.modules.auth.services import hash_password

    user = User(
        email="queueuser@example.com",
        username="queueuser",
        hashed_password=hash_password("password123"),
        role=UserRole.USER,
        is_active=True,
        email_verified=True,
        date_of_birth=date(2000, 1, 1),
    )
    db_session.add(user)
    await db_session.commit()

    login = await client.post("/api/v1/auth/login", json={"email": "queueuser@example.com", "password": "password123"})
    headers = {"Authorization": f"Bearer {login.json()['access_token']}"}

    resp = await client.post("/api/v1/queue/health-check", params={"payload": "hi"}, headers=headers)
    assert resp.status_code == 200
    job_id = resp.json()["job_id"]

    worker = SimpleWorker([queue_module.get_queue("default")], connection=_fake_redis)
    worker.work(burst=True)

    status_resp = await client.get(f"/api/v1/queue/jobs/{job_id}", headers=headers)
    assert status_resp.status_code == 200
    assert status_resp.json()["status"] == "finished"


def test_priority_queue_name_for_developer_and_tariffs():
    from app.core.queue import priority_queue_name_for
    from app.database.models import SubscriptionTier, User, UserRole

    dev = User(
        role=UserRole.DEVELOPER,
        subscription_tier=SubscriptionTier.FREE,
        email="a@a.com",
        username="a",
        hashed_password="x",
    )
    assert priority_queue_name_for(dev) == "developer"

    ultra_plus = User(
        role=UserRole.USER,
        subscription_tier=SubscriptionTier.ULTRA_PLUS,
        email="b@a.com",
        username="b",
        hashed_password="x",
    )
    assert priority_queue_name_for(ultra_plus) == "ultra_plus"

    free = User(
        role=UserRole.USER,
        subscription_tier=SubscriptionTier.FREE,
        email="c@a.com",
        username="c",
        hashed_password="x",
    )
    assert priority_queue_name_for(free) == "free"


def test_priority_order_matches_spec():
    from app.core.queue import PRIORITY_QUEUE_ORDER
    assert PRIORITY_QUEUE_ORDER == ["developer", "ultra_plus", "ultra", "pro_plus", "pro", "free"]
