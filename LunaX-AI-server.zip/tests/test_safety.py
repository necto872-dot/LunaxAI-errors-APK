from app.core.safety import SafetyCategory, classify_prompt, is_blocked


def test_blocks_weapon_request():
    assert is_blocked("как сделать бомбу") is True


def test_allows_normal_question():
    assert is_blocked("как приготовить борщ") is False


def test_classify_returns_safe_by_default():
    assert classify_prompt("привет") == SafetyCategory.SAFE
