"""
Тесты квоты хранения памяти по тарифам (согласовано с владельцем в чате,
единица — "сколько текста романа «Война и мир» умещается"):
Free=3, Pro=6, Pro Plus=9, Ultra=12, Ultra Plus=15 (шаг +3);
Developer=10 ГБ (отдельно, не по этой шкале).

Реальные объёмы в тестах не гоняем (слишком медленно/тяжело для CI) —
подменяем лимит через monkeypatch на маленькое число байт и проверяем сам
МЕХАНИЗМ: блокировка новой записи при превышении, а не тихое стирание
старых данных ("ничего не теряется без спроса пользователя").

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
from datetime import date

import pytest

from app.config.settings import (
    DEVELOPER_MEMORY_STORAGE_LIMIT_GB,
    GIGABYTE,
    MEGABYTE,
    MEMORY_STORAGE_LIMIT_MB,
    MEMORY_STORAGE_LIMIT_WAR_AND_PEACE_UNITS,
    WAR_AND_PEACE_MB,
)
from app.core.ai.memory import (
    MemoryQuotaExceededError,
    append_message_pair,
    get_or_create_conversation,
    memory_limit_bytes_for,
    remember_fact,
)
from app.database.models import SubscriptionTier, User, UserRole
from app.modules.auth.services import hash_password


async def _create_user(
    db_session,
    tier=SubscriptionTier.FREE,
    role=UserRole.USER,
    email="quota@example.com",
    username="quotauser",
):
    user = User(
        email=email,
        username=username,
        hashed_password=hash_password("password123"),
        role=role,
        subscription_tier=tier,
        is_active=True,
        email_verified=True,
        date_of_birth=date(2000, 1, 1),
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


def test_memory_limit_matches_tariff_war_and_peace_units():
    """Сверка конфига с утверждёнными значениями: 3/6/9/12/15 «Войн и мир» + 10 ГБ Developer."""
    assert MEMORY_STORAGE_LIMIT_WAR_AND_PEACE_UNITS == {
        "free": 3,
        "pro": 6,
        "pro_plus": 9,
        "ultra": 12,
        "ultra_plus": 15,
    }
    assert DEVELOPER_MEMORY_STORAGE_LIMIT_GB == 10
    assert MEMORY_STORAGE_LIMIT_MB["free"] == pytest.approx(3 * WAR_AND_PEACE_MB)
    assert MEMORY_STORAGE_LIMIT_MB["ultra_plus"] == pytest.approx(15 * WAR_AND_PEACE_MB)


@pytest.mark.asyncio
async def test_limit_bytes_per_tier(db_session):
    free = await _create_user(db_session, SubscriptionTier.FREE, email="free@example.com", username="freeuser")
    pro_plus = await _create_user(
        db_session,
        SubscriptionTier.PRO_PLUS,
        email="proplus@example.com",
        username="proplususer",
    )
    ultra_plus = await _create_user(
        db_session,
        SubscriptionTier.ULTRA_PLUS,
        email="ultraplus@example.com",
        username="ultraplususer",
    )
    dev = await _create_user(
        db_session,
        SubscriptionTier.FREE,
        role=UserRole.DEVELOPER,
        email="dev@example.com",
        username="devuser",
    )

    assert memory_limit_bytes_for(free) == round(3 * WAR_AND_PEACE_MB * MEGABYTE)
    assert memory_limit_bytes_for(pro_plus) == round(9 * WAR_AND_PEACE_MB * MEGABYTE)
    assert memory_limit_bytes_for(ultra_plus) == round(15 * WAR_AND_PEACE_MB * MEGABYTE)
    assert memory_limit_bytes_for(dev) == 10 * GIGABYTE  # роль важнее subscription_tier=FREE


@pytest.mark.asyncio
async def test_new_message_blocked_when_quota_exceeded(db_session, monkeypatch):
    monkeypatch.setattr("app.core.ai.memory.memory_limit_bytes_for", lambda user: 50)  # крошечный лимит для теста

    user = await _create_user(db_session)
    conversation = await get_or_create_conversation(db_session, user, None)

    # Первая пара укладывается в лимит.
    await append_message_pair(db_session, user, conversation, "привет", "привет!")

    # Вторая — уже нет, лимит исчерпан.
    with pytest.raises(MemoryQuotaExceededError):
        await append_message_pair(
            db_session, user, conversation,
            "очень длинное сообщение которое точно не влезет в оставшийся лимит",
            "и такой же длинный ответ, который тоже не влезет никуда вообще",
        )


@pytest.mark.asyncio
async def test_quota_exceeded_does_not_delete_existing_data(db_session, monkeypatch):
    """Ключевое требование владельца: при исчерпании лимита СТАРЫЕ данные не удаляются."""
    monkeypatch.setattr("app.core.ai.memory.memory_limit_bytes_for", lambda user: 50)

    user = await _create_user(db_session)
    conversation = await get_or_create_conversation(db_session, user, None)
    await append_message_pair(db_session, user, conversation, "привет", "привет!")

    with pytest.raises(MemoryQuotaExceededError):
        await append_message_pair(db_session, user, conversation, "x" * 100, "y" * 100)

    from app.core.ai.memory import get_conversation_messages
    messages = await get_conversation_messages(db_session, user, conversation.id)
    assert len(messages) == 2  # исходная пара цела, ничего не стёрлось
    assert messages[0].content == "привет"
    assert messages[1].content == "привет!"


@pytest.mark.asyncio
async def test_remember_fact_also_blocked_by_quota(db_session, monkeypatch):
    monkeypatch.setattr("app.core.ai.memory.memory_limit_bytes_for", lambda user: 10)

    user = await _create_user(db_session)
    with pytest.raises(MemoryQuotaExceededError):
        await remember_fact(db_session, user, "факт длиннее чем десять байт точно")


@pytest.mark.asyncio
async def test_memory_status_endpoint_reports_usage_and_limit(client, db_session):
    await _create_user(db_session, email="statususer@example.com", username="statususer")
    login = await client.post("/api/v1/auth/login", json={"email": "statususer@example.com", "password": "password123"})
    headers = {"Authorization": f"Bearer {login.json()['access_token']}"}

    resp = await client.get("/api/v1/memory/status", headers=headers)
    assert resp.status_code == 200
    body = resp.json()
    assert body["limit_bytes"] == round(3 * WAR_AND_PEACE_MB * MEGABYTE)  # FREE = 3 «Войны и мира»
    assert body["used_bytes"] == 0
    assert body["used_percent"] == 0


@pytest.mark.asyncio
async def test_chat_endpoint_returns_507_via_http_when_quota_exceeded(client, db_session, monkeypatch):
    """Проверка сквозь HTTP-слой: 507 Insufficient Storage, а не 500."""
    monkeypatch.setattr("app.core.ai.memory.memory_limit_bytes_for", lambda user: 0)

    await _create_user(db_session, email="httpquota@example.com", username="httpquota")
    login = await client.post("/api/v1/auth/login", json={"email": "httpquota@example.com", "password": "password123"})
    headers = {"Authorization": f"Bearer {login.json()['access_token']}"}

    resp = await client.post("/api/v1/memory/remember", json={"content": "что угодно"}, headers=headers)
    assert resp.status_code == 507
