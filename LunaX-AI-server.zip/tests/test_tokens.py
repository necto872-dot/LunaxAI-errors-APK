"""
Тесты токен-квоты — окончательная схема (согласована с владельцем в чате):

- FREE=5_000_000 (0₸) / PRO=10_000_000 (10000₸) / PRO_PLUS=15_000_000 (15000₸) /
  ULTRA=20_000_000 (20000₸) / ULTRA_PLUS=25_000_000 (25000₸).
  DEVELOPER/PRIMARY_DEVELOPER = 50_000_000_000 (unlimited, без списания).
- Безусловный полный сброс в 00:00 КАЖДЫЙ день, независимо от остатка.
- Критический остаток (< 100_000, см. допущение в app/core/quota.py) —
  индивидуальный таймер восстановления с момента критического списания:
  4ч (FREE), 3ч (PRO/PRO_PLUS), 2ч (ULTRA/ULTRA_PLUS).

NOT VERIFIED в этом окружении — нет установленных зависимостей/сети
(см. tests/conftest.py).
"""
from datetime import UTC, date, datetime, timedelta

import pytest

from app.core.quota import (
    InsufficientTokensError,
    quota_status,
    spend_tokens,
    sync_quota_state,
    token_limit_for,
)
from app.database.models import SubscriptionTier, User, UserRole
from app.modules.auth.services import hash_password


async def _make_user(db_session, tier=SubscriptionTier.FREE, role=UserRole.USER, balance=5_000_000, limit=5_000_000):
    user = User(
        email=f"{tier.value}_{role.value}_{balance}@example.com",
        username=f"{tier.value}_{role.value}_{balance}",
        hashed_password=hash_password("password123"),
        role=role,
        subscription_tier=tier,
        is_active=True,
        email_verified=True,
        token_balance=balance,
        token_limit=limit,
        last_daily_reset_date=datetime.now(UTC).date(),  # считаем, что сегодняшний сброс уже применён
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


@pytest.mark.asyncio
async def test_token_limit_per_tier(db_session):
    free = await _make_user(db_session, SubscriptionTier.FREE)
    pro = await _make_user(db_session, SubscriptionTier.PRO, balance=10_000_000, limit=10_000_000)
    ultra_plus = await _make_user(db_session, SubscriptionTier.ULTRA_PLUS, balance=25_000_000, limit=25_000_000)

    assert token_limit_for(free) == 5_000_000
    assert token_limit_for(pro) == 10_000_000
    assert token_limit_for(ultra_plus) == 25_000_000


@pytest.mark.asyncio
async def test_developer_limit_is_50_billion(db_session):
    dev = await _make_user(
        db_session, SubscriptionTier.FREE, role=UserRole.DEVELOPER,
        balance=50_000_000_000, limit=50_000_000_000,
    )
    assert token_limit_for(dev) == 50_000_000_000


@pytest.mark.asyncio
async def test_spend_deducts_balance_normally(db_session):
    user = await _make_user(db_session, SubscriptionTier.FREE, balance=5_000_000, limit=5_000_000)
    result = await spend_tokens(db_session, user, 1_000_000)
    assert result["spent"] == 1_000_000
    assert result["token_balance"] == 4_000_000
    assert result["critical_recovery_active"] is False  # остаток выше порога 100_000


@pytest.mark.asyncio
async def test_spend_insufficient_balance_raises(db_session):
    user = await _make_user(db_session, SubscriptionTier.FREE, balance=100, limit=5_000_000)
    with pytest.raises(InsufficientTokensError):
        await spend_tokens(db_session, user, 1_000)


@pytest.mark.asyncio
async def test_critical_spend_starts_recovery_timer(db_session):
    user = await _make_user(db_session, SubscriptionTier.FREE, balance=150_000, limit=5_000_000)
    result = await spend_tokens(db_session, user, 100_000)  # остаток станет 50_000 < 100_000
    assert result["token_balance"] == 50_000
    assert result["critical_recovery_active"] is True
    assert result["recovery_available_at"] is not None


@pytest.mark.asyncio
async def test_critical_recovery_completes_before_midnight(db_session):
    """Критический таймер восстанавливает лимит РАНЬШЕ полуночи, если истёк."""
    user = await _make_user(db_session, SubscriptionTier.FREE, balance=50_000, limit=5_000_000)
    user.critical_recovery_started_at = datetime.now(UTC) - timedelta(hours=4, minutes=1)  # уже истёк (FREE=4ч)
    await db_session.commit()

    refreshed = await sync_quota_state(db_session, user)
    assert refreshed.token_balance == 5_000_000
    assert refreshed.critical_recovery_started_at is None


@pytest.mark.asyncio
async def test_critical_recovery_not_yet_due(db_session):
    user = await _make_user(db_session, SubscriptionTier.FREE, balance=50_000, limit=5_000_000)
    user.critical_recovery_started_at = datetime.now(UTC) - timedelta(minutes=10)  # ещё рано (нужно 4ч)
    await db_session.commit()

    refreshed = await sync_quota_state(db_session, user)
    assert refreshed.token_balance == 50_000  # не восстановлен
    assert refreshed.critical_recovery_started_at is not None


@pytest.mark.asyncio
async def test_daily_reset_is_unconditional_regardless_of_balance(db_session):
    """00:00 сбрасывает лимит ВСЕГДА, даже если остаток был некритичным (2.5М из 5М)."""
    user = await _make_user(db_session, SubscriptionTier.FREE, balance=2_500_000, limit=5_000_000)
    user.last_daily_reset_date = date(2020, 1, 1)  # "вчера" -> наступил новый день
    await db_session.commit()

    refreshed = await sync_quota_state(db_session, user)
    assert refreshed.token_balance == 5_000_000
    assert refreshed.critical_recovery_started_at is None


@pytest.mark.asyncio
async def test_daily_reset_clears_active_critical_timer(db_session):
    user = await _make_user(db_session, SubscriptionTier.FREE, balance=10_000, limit=5_000_000)
    user.last_daily_reset_date = date(2020, 1, 1)
    user.critical_recovery_started_at = datetime.now(UTC) - timedelta(minutes=5)  # таймер ещё не истёк бы сам
    await db_session.commit()

    refreshed = await sync_quota_state(db_session, user)
    assert refreshed.token_balance == 5_000_000  # 00:00 сбрасывает раньше, чем истёк бы критический таймер
    assert refreshed.critical_recovery_started_at is None


@pytest.mark.asyncio
async def test_recovery_duration_by_tier():
    from app.core.quota import recovery_minutes_for

    free = User(role=UserRole.USER, subscription_tier=SubscriptionTier.FREE)
    pro = User(role=UserRole.USER, subscription_tier=SubscriptionTier.PRO)
    pro_plus = User(role=UserRole.USER, subscription_tier=SubscriptionTier.PRO_PLUS)
    ultra = User(role=UserRole.USER, subscription_tier=SubscriptionTier.ULTRA)
    ultra_plus = User(role=UserRole.USER, subscription_tier=SubscriptionTier.ULTRA_PLUS)

    assert recovery_minutes_for(free) == 4 * 60
    assert recovery_minutes_for(pro) == 3 * 60
    assert recovery_minutes_for(pro_plus) == 3 * 60
    assert recovery_minutes_for(ultra) == 2 * 60
    assert recovery_minutes_for(ultra_plus) == 2 * 60


@pytest.mark.asyncio
async def test_low_balance_warning_at_5_percent(db_session):
    user = await _make_user(db_session, SubscriptionTier.FREE, balance=200_000, limit=5_000_000)
    status = quota_status(user)
    assert status["low_balance_warning"] is not None
    assert status["low_balance_warning"]["percent_left"] == pytest.approx(4.0)


@pytest.mark.asyncio
async def test_developer_role_is_unlimited_and_not_deducted(db_session):
    dev = await _make_user(
        db_session, SubscriptionTier.FREE, role=UserRole.DEVELOPER,
        balance=50_000_000_000, limit=50_000_000_000,
    )
    result = await spend_tokens(db_session, dev, 999_999_999)
    assert result["unlimited"] is True
    assert result["token_balance"] is None
    assert result["critical_recovery_active"] is False
    await db_session.refresh(dev)
    assert dev.token_balance == 50_000_000_000  # не списывается у unlimited-ролей


@pytest.mark.asyncio
async def test_cannot_go_negative_balance(db_session):
    user = await _make_user(db_session, SubscriptionTier.FREE, balance=500, limit=5_000_000)
    with pytest.raises(InsufficientTokensError):
        await spend_tokens(db_session, user, 501)
    await db_session.refresh(user)
    assert user.token_balance == 500  # баланс не изменился при отказе
