"""
Тесты файлового модуля (ТЗ раздел 25, 34-35): ownership, размер,
расширение, отсутствие доступа по чужому id.

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
import io

import pytest

from app.database.models import User, UserRole
from app.modules.auth.services import hash_password


async def _create_verified_user(db_session, email, username):
    user = User(
        email=email,
        username=username,
        hashed_password=hash_password("password123"),
        role=UserRole.USER,
        is_active=True,
        email_verified=True,
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


async def _login(client, email, password="password123"):
    resp = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert resp.status_code == 200, resp.text
    return {"Authorization": f"Bearer {resp.json()['access_token']}"}


@pytest.mark.asyncio
async def test_upload_and_download_own_file(client, db_session):
    await _create_verified_user(db_session, "fileowner@example.com", "fileowner")
    headers = await _login(client, "fileowner@example.com")

    resp = await client.post(
        "/api/v1/files/upload",
        files={"file": ("notes.txt", io.BytesIO(b"hello world"), "text/plain")},
        headers=headers,
    )
    assert resp.status_code == 201
    file_id = resp.json()["id"]
    assert resp.json()["original_filename"] == "notes.txt"

    download = await client.get(f"/api/v1/files/{file_id}", headers=headers)
    assert download.status_code == 200
    assert download.content == b"hello world"


@pytest.mark.asyncio
async def test_reject_disallowed_extension(client, db_session):
    await _create_verified_user(db_session, "extuser@example.com", "extuser")
    headers = await _login(client, "extuser@example.com")

    resp = await client.post(
        "/api/v1/files/upload",
        files={"file": ("payload.exe", io.BytesIO(b"MZ"), "application/octet-stream")},
        headers=headers,
    )
    assert resp.status_code == 415


@pytest.mark.asyncio
async def test_reject_oversized_file(client, db_session, monkeypatch):
    monkeypatch.setattr("app.modules.files.services.settings.max_file_size_mb", 0)  # 0 МБ -> всё "слишком большое"
    await _create_verified_user(db_session, "bigfile@example.com", "bigfile")
    headers = await _login(client, "bigfile@example.com")

    resp = await client.post(
        "/api/v1/files/upload",
        files={"file": ("small.txt", io.BytesIO(b"x" * 100), "text/plain")},
        headers=headers,
    )
    assert resp.status_code == 413


@pytest.mark.asyncio
async def test_cannot_access_other_users_file(client, db_session):
    await _create_verified_user(db_session, "owner2@example.com", "owner2")
    await _create_verified_user(db_session, "intruder@example.com", "intruder")

    owner_headers = await _login(client, "owner2@example.com")
    intruder_headers = await _login(client, "intruder@example.com")

    upload = await client.post(
        "/api/v1/files/upload",
        files={"file": ("private.txt", io.BytesIO(b"secret"), "text/plain")},
        headers=owner_headers,
    )
    file_id = upload.json()["id"]

    resp = await client.get(f"/api/v1/files/{file_id}", headers=intruder_headers)
    assert resp.status_code == 404  # не 403 -> не подтверждаем даже факт существования файла

    delete_resp = await client.delete(f"/api/v1/files/{file_id}", headers=intruder_headers)
    assert delete_resp.status_code == 404


@pytest.mark.asyncio
async def test_list_only_own_files(client, db_session):
    await _create_verified_user(db_session, "lister@example.com", "lister")
    headers = await _login(client, "lister@example.com")

    await client.post(
        "/api/v1/files/upload",
        files={"file": ("a.txt", io.BytesIO(b"a"), "text/plain")},
        headers=headers,
    )
    await client.post(
        "/api/v1/files/upload",
        files={"file": ("b.md", io.BytesIO(b"b"), "text/markdown")},
        headers=headers,
    )

    resp = await client.get("/api/v1/files", headers=headers)
    assert resp.status_code == 200
    assert len(resp.json()) == 2


@pytest.mark.asyncio
async def test_delete_removes_file(client, db_session):
    await _create_verified_user(db_session, "deleter@example.com", "deleter")
    headers = await _login(client, "deleter@example.com")

    upload = await client.post(
        "/api/v1/files/upload",
        files={"file": ("temp.txt", io.BytesIO(b"temp"), "text/plain")},
        headers=headers,
    )
    file_id = upload.json()["id"]

    delete_resp = await client.delete(f"/api/v1/files/{file_id}", headers=headers)
    assert delete_resp.status_code == 200

    get_after_delete = await client.get(f"/api/v1/files/{file_id}", headers=headers)
    assert get_after_delete.status_code == 404
