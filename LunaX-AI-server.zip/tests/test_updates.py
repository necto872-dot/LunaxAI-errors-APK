"""
Тесты системы обновлений (app/core/updates.py, app/modules/updates/routers.py):
- нет обновления, если latest_version == app_version;
- есть обновление -> создаётся confirmation_token;
- apply с верным токеном -> confirmed, токен становится недействителен;
- повторное использование токена отклоняется;
- чужой токен недоступен другому пользователю (404);
- обычный USER не имеет доступа (только Developer/Primary/Admin).

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
import pytest

from app.database.models import User, UserRole
from app.modules.auth.services import hash_password


async def _create_user(db_session, role=UserRole.DEVELOPER, email="devupdater@example.com", username="devupdater"):
    user = User(
        email=email,
        username=username,
        hashed_password=hash_password("password123"),
        role=role,
        is_active=True,
        email_verified=True,
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


async def _login(client, email, password="password123"):
    resp = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert resp.status_code == 200, resp.text
    return {"Authorization": f"Bearer {resp.json()['access_token']}"}


@pytest.mark.asyncio
async def test_no_update_when_versions_match(client, db_session):
    await _create_user(db_session)
    headers = await _login(client, "devupdater@example.com")

    resp = await client.post("/api/v1/updates/check", headers=headers)
    assert resp.status_code == 200
    body = resp.json()
    assert body["update_available"] is False
    assert body["confirmation_token"] is None


@pytest.mark.asyncio
async def test_update_available_creates_token(client, db_session, monkeypatch):
    monkeypatch.setattr("app.core.updates.settings.latest_available_version", "0.2.0")

    await _create_user(db_session, email="devupdater2@example.com", username="devupdater2")
    headers = await _login(client, "devupdater2@example.com")

    resp = await client.post("/api/v1/updates/check", headers=headers)
    body = resp.json()
    assert body["update_available"] is True
    assert body["latest_version"] == "0.2.0"
    assert body["confirmation_token"] is not None


@pytest.mark.asyncio
async def test_apply_with_valid_token_succeeds_and_is_single_use(client, db_session, monkeypatch):
    monkeypatch.setattr("app.core.updates.settings.latest_available_version", "0.2.0")

    await _create_user(db_session, email="devupdater3@example.com", username="devupdater3")
    headers = await _login(client, "devupdater3@example.com")

    check_resp = await client.post("/api/v1/updates/check", headers=headers)
    token = check_resp.json()["confirmation_token"]

    apply_resp = await client.post("/api/v1/updates/apply", json={"confirmation_token": token}, headers=headers)
    assert apply_resp.status_code == 200
    assert apply_resp.json()["status"] == "confirmed"
    assert apply_resp.json()["target_version"] == "0.2.0"

    reuse_resp = await client.post("/api/v1/updates/apply", json={"confirmation_token": token}, headers=headers)
    assert reuse_resp.status_code == 400


@pytest.mark.asyncio
async def test_other_users_token_returns_404(client, db_session, monkeypatch):
    monkeypatch.setattr("app.core.updates.settings.latest_available_version", "0.2.0")

    await _create_user(db_session, email="ownerdev@example.com", username="ownerdev")
    await _create_user(db_session, email="intruderdev@example.com", username="intruderdev")

    owner_headers = await _login(client, "ownerdev@example.com")
    intruder_headers = await _login(client, "intruderdev@example.com")

    check_resp = await client.post("/api/v1/updates/check", headers=owner_headers)
    token = check_resp.json()["confirmation_token"]

    resp = await client.post("/api/v1/updates/apply", json={"confirmation_token": token}, headers=intruder_headers)
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_regular_user_forbidden(client, db_session):
    await _create_user(db_session, role=UserRole.USER, email="plainuser2@example.com", username="plainuser2")
    headers = await _login(client, "plainuser2@example.com")

    resp = await client.post("/api/v1/updates/check", headers=headers)
    assert resp.status_code == 403
