"""Тест определения высоты голоса — реальный DSP, проверено на синтетике."""
import math
import struct
import wave
from io import BytesIO

import pytest

from app.core.voice.pitch import PitchAnalysisError, analyze_pitch


def _sine_wav(freq, dur=0.4, rate=16000):
    n = int(rate * dur)
    samples = [int(10000 * math.sin(2*math.pi*freq*i/rate)) for i in range(n)]
    buf = BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(struct.pack("<" + "h"*n, *samples))
    return buf.getvalue()


@pytest.mark.parametrize("freq", [110.0, 220.0, 330.0])
def test_detects_known_frequency_within_5_percent(freq):
    detected = analyze_pitch(_sine_wav(freq))
    assert detected is not None
    assert abs(detected - freq) / freq < 0.05


def test_rejects_non_16bit_wav():
    buf = BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(1)
        wf.setframerate(8000)
        wf.writeframes(b"\x00" * 100)
    with pytest.raises(PitchAnalysisError):
        analyze_pitch(buf.getvalue())


def test_returns_none_for_too_short_sample():
    buf = BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(16000)
        wf.writeframes(struct.pack("<10h", *([0]*10)))
    assert analyze_pitch(buf.getvalue()) is None
