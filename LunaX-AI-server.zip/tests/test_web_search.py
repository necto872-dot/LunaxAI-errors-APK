"""Тесты веб-поиска (SearXNG)."""
from unittest.mock import MagicMock, patch

import pytest

from app.core.web_search import WebSearchNotConfiguredError, format_results_for_context, search_web


@pytest.mark.asyncio
async def test_search_raises_when_not_configured():
    with pytest.raises(WebSearchNotConfiguredError):
        await search_web("погода сегодня")


@pytest.mark.asyncio
async def test_search_returns_parsed_results(monkeypatch):
    monkeypatch.setattr("app.core.web_search.settings.web_search_enabled", True)
    monkeypatch.setattr("app.core.web_search.settings.searxng_base_url", "http://localhost:8888")

    async def fake_get(self, url, params=None):
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = {"results": [
            {"title": "Погода в Алматы", "url": "https://example.com/weather", "content": "+25 солнечно"}
        ]}
        return resp

    with patch("httpx.AsyncClient.get", new=fake_get):
        results = await search_web("погода в Алматы")

    assert len(results) == 1
    assert results[0]["title"] == "Погода в Алматы"


@pytest.mark.asyncio
async def test_results_limited_to_max_results(monkeypatch):
    monkeypatch.setattr("app.core.web_search.settings.web_search_enabled", True)
    monkeypatch.setattr("app.core.web_search.settings.searxng_base_url", "http://localhost:8888")
    monkeypatch.setattr("app.core.web_search.settings.web_search_max_results", 2)

    async def fake_get(self, url, params=None):
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = {"results": [{"title": f"r{i}", "url": "u", "content": "c"} for i in range(10)]}
        return resp

    with patch("httpx.AsyncClient.get", new=fake_get):
        results = await search_web("query")
    assert len(results) == 2


def test_format_results_for_context():
    text = format_results_for_context([{"title": "A", "url": "http://a", "content": "текст A"}])
    assert "A" in text and "http://a" in text


def test_format_empty_results():
    text = format_results_for_context([])
    assert "не дал результатов" in text


@pytest.mark.asyncio
async def test_chat_degrades_gracefully_when_search_unavailable(client, db_session):
    """use_web_search=true, но SearXNG не настроен -> чат всё равно отвечает 503 от AI (не от поиска)."""
    from datetime import date

    from app.database.models import User, UserRole
    from app.modules.auth.services import hash_password

    user = User(email="wsuser@example.com", username="wsuser", hashed_password=hash_password("password123"),
                role=UserRole.USER, is_active=True, email_verified=True, date_of_birth=date(2000, 1, 1))
    db_session.add(user)
    await db_session.commit()

    login = await client.post("/api/v1/auth/login", json={"email": "wsuser@example.com", "password": "password123"})
    headers = {"Authorization": f"Bearer {login.json()['access_token']}"}

    resp = await client.post("/api/v1/search/query", json={"prompt": "погода", "use_web_search": True}, headers=headers)
    # SearXNG не настроен -> тихо пропускается; AI тоже не настроен -> 503 от AI, не 500 от поиска.
    assert resp.status_code == 503


@pytest.mark.asyncio
async def test_fetch_page_strips_html(monkeypatch):
    monkeypatch.setattr("app.core.web_search.settings.web_search_enabled", True)

    async def fake_get(self, url, follow_redirects=True):
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.text = "<html><body><script>evil()</script><p>Привет мир</p></body></html>"
        return resp

    from app.core.web_search import fetch_page
    with patch("httpx.AsyncClient.get", new=fake_get):
        text = await fetch_page("https://example.com")

    assert "Привет мир" in text
    assert "evil" not in text


@pytest.mark.asyncio
async def test_fetch_page_rejects_bad_url():
    from app.core.web_search import WebSearchNotConfiguredError, WebSearchRequestError, fetch_page
    with pytest.raises((WebSearchRequestError, WebSearchNotConfiguredError)):
        await fetch_page("not-a-url")
