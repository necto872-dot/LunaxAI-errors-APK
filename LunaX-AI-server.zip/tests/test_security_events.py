"""
Тесты новых детекторов в app/core/security_events.py: token_burn_spike,
rate_limit_abuse, new_ip_after_credential_change, TTL auto-expire.

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
import pytest

from app.core.audit import record_audit_event
from app.core.security_events import (
    check_new_ip_after_credential_change,
    check_rate_limit_abuse,
    check_token_burn_spike,
    expire_stale_events,
    record_security_event,
)
from app.database.models import SecurityEventSeverity, User, UserRole
from app.modules.auth.services import hash_password


async def _create_user(db_session, email, username):
    user = User(
        email=email, username=username, hashed_password=hash_password("password123"),
        role=UserRole.USER, is_active=True, email_verified=True,
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


@pytest.mark.asyncio
async def test_token_burn_spike_triggers_after_threshold(db_session, monkeypatch):
    monkeypatch.setattr("app.core.security_events.settings.security_token_burn_threshold_percent", 50)
    user = await _create_user(db_session, "burn@example.com", "burnuser")
    user.token_limit = 1000

    event = await check_token_burn_spike(db_session, user, 600)
    assert event is not None
    assert event.event_type == "token_burn_spike"
    assert event.severity == SecurityEventSeverity.MEDIUM


@pytest.mark.asyncio
async def test_token_burn_spike_not_triggered_below_threshold(db_session, monkeypatch):
    monkeypatch.setattr("app.core.security_events.settings.security_token_burn_threshold_percent", 50)
    user = await _create_user(db_session, "normal@example.com", "normaluser")
    user.token_limit = 1000

    event = await check_token_burn_spike(db_session, user, 100)
    assert event is None


@pytest.mark.asyncio
async def test_rate_limit_abuse_triggers_after_repeated_hits(db_session, monkeypatch):
    monkeypatch.setattr("app.core.security_events.settings.security_rate_limit_abuse_threshold", 3)

    event = None
    for _ in range(3):
        event = await check_rate_limit_abuse(db_session, "login", "1.2.3.4")
    assert event is not None
    assert event.event_type == "rate_limit_abuse"
    assert event.ip_address == "1.2.3.4"


@pytest.mark.asyncio
async def test_new_ip_after_credential_change_flags_event(db_session):
    user = await _create_user(db_session, "changed@example.com", "changeduser")
    user.last_login_ip = "10.0.0.1"
    await db_session.commit()
    await record_audit_event(db_session, "password_reset_completed", actor_id=user.id, target_id=user.id)

    event = await check_new_ip_after_credential_change(db_session, user, "10.0.0.9")
    assert event is not None
    assert event.event_type == "new_ip_after_credential_change"


@pytest.mark.asyncio
async def test_new_ip_without_recent_credential_change_does_not_flag(db_session):
    user = await _create_user(db_session, "stable@example.com", "stableuser")
    user.last_login_ip = "10.0.0.1"
    await db_session.commit()

    event = await check_new_ip_after_credential_change(db_session, user, "10.0.0.9")
    assert event is None


@pytest.mark.asyncio
async def test_stale_events_auto_expire(db_session, monkeypatch):
    monkeypatch.setattr("app.core.security_events.settings.security_event_ttl_days", 0)
    event = await record_security_event(db_session, "test_event", severity=SecurityEventSeverity.LOW)
    assert event.resolved is False

    expired_count = await expire_stale_events(db_session)
    assert expired_count == 1
    await db_session.refresh(event)
    assert event.resolved is True
