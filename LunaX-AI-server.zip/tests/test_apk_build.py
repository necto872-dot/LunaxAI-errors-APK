"""APK-сборка: интерфейс без Android SDK/Gradle отвечает честным 503."""
import fakeredis
import pytest
from rq import SimpleWorker

from app.core import queue as queue_module
from app.core.build.apk import ApkBuildError, enqueue_apk_build, start_apk_build
from app.database.models import ApkBuildJobStatus, Project, ProjectStatus, User, UserRole
from app.modules.auth.services import hash_password


@pytest.fixture(autouse=True)
def _fake_redis(monkeypatch):
    """Подменяем реальное Redis-соединение на fakeredis для тестов очереди (см. tests/test_queue.py)."""
    fake_conn = fakeredis.FakeStrictRedis()
    monkeypatch.setattr(queue_module, "get_redis_connection", lambda: fake_conn)
    yield fake_conn


async def _user(db):
    u = User(email="apk@example.com", username="apkuser", hashed_password=hash_password("password123"),
              role=UserRole.USER, is_active=True, email_verified=True)
    db.add(u)
    await db.commit()
    await db.refresh(u)
    return u


async def _project(db, user):
    p = Project(owner_id=user.id, name="test", prompt="x", status=ProjectStatus.READY)
    db.add(p)
    await db.commit()
    await db.refresh(p)
    return p


@pytest.mark.asyncio
async def test_apk_build_returns_503_when_disabled(db_session):
    user = await _user(db_session)
    project = await _project(db_session, user)
    with pytest.raises(ApkBuildError) as exc:
        await start_apk_build(db_session, user, project.id)
    assert exc.value.status_code == 503


@pytest.mark.asyncio
async def test_apk_build_404_for_other_users_project(db_session):
    user1 = await _user(db_session)
    project = await _project(db_session, user1)
    from app.database.models import User as U
    user2 = U(email="apk2@example.com", username="apkuser2", hashed_password=hash_password("password123"),
              role=UserRole.USER, is_active=True, email_verified=True)
    db_session.add(user2)
    await db_session.commit()
    await db_session.refresh(user2)

    with pytest.raises(ApkBuildError) as exc:
        await start_apk_build(db_session, user2, project.id)
    assert exc.value.status_code == 404


@pytest.mark.asyncio
async def test_apk_build_missing_gradlew_when_enabled(db_session, monkeypatch, tmp_path):
    monkeypatch.setattr("app.core.build.apk.settings.apk_build_enabled", True)
    monkeypatch.setattr("app.core.build.apk.settings.project_gen_workspace_dir", str(tmp_path))

    user = await _user(db_session)
    project = await _project(db_session, user)
    with pytest.raises(ApkBuildError) as exc:
        await start_apk_build(db_session, user, project.id)
    assert exc.value.status_code == 422
    assert "gradlew" in exc.value.message


@pytest.mark.asyncio
async def test_env_preserves_path_when_sdk_root_set(db_session, monkeypatch, tmp_path):
    """Регрессия: раньше env={'ANDROID_SDK_ROOT':...} стирал PATH целиком."""
    from unittest.mock import MagicMock, patch

    monkeypatch.setattr("app.core.build.apk.settings.apk_build_enabled", True)
    monkeypatch.setattr("app.core.build.apk.settings.project_gen_workspace_dir", str(tmp_path))
    monkeypatch.setattr("app.core.build.apk.settings.android_sdk_root", "/opt/android-sdk")

    user = await _user(db_session)
    project = await _project(db_session, user)

    # gradlew должен существовать, чтобы дойти до subprocess.run
    captured = {}

    def fake_run(
        cmd, cwd=None, env=None, capture_output=None, text=None, timeout=None,
        preexec_fn=None, check=None,
    ):
        captured["env"] = env
        result = MagicMock()
        result.returncode = 0
        result.stdout, result.stderr = "", ""
        return result

    with (
        patch("app.core.build.apk.subprocess.run", side_effect=fake_run),
        patch("pathlib.Path.exists", return_value=True),
        patch("pathlib.Path.glob", return_value=[]),
        pytest.raises(ApkBuildError),  # упадёт на "apk не найден", но env уже проверим
    ):
        await start_apk_build(db_session, user, project.id)

    assert "PATH" in captured["env"]
    assert captured["env"]["ANDROID_SDK_ROOT"] == "/opt/android-sdk"
    # ВАЖНО (security fix после аудита): окружение сборки больше НЕ
    # наследует os.environ родительского процесса — иначе вредоносный
    # build.gradle мог бы прочитать секреты backend'а (JWT_SECRET_KEY,
    # DATABASE_URL и т.д.) через System.getenv(). PATH теперь фиксированный
    # минимальный, а не унаследованный — это ожидаемое поведение, не баг.
    assert captured["env"]["PATH"] == "/usr/bin:/bin:/usr/local/bin"
    assert "JWT_SECRET_KEY" not in captured["env"]


@pytest.mark.asyncio
async def test_enqueue_apk_build_fails_fast_when_disabled(db_session, _fake_redis):
    """Когда apk_build_enabled=False, enqueue_apk_build не должен класть задачу в очередь — сразу честный 503."""
    user = await _user(db_session)
    project = await _project(db_session, user)

    with pytest.raises(ApkBuildError) as exc:
        await enqueue_apk_build(db_session, user, project.id)
    assert exc.value.status_code == 503

    # Очередь пустая — задача не попадала в RQ, т.к. заведомо провалилась бы.
    from app.core.queue import get_queue
    assert len(get_queue("developer")) == 0


@pytest.mark.asyncio
async def test_enqueue_apk_build_queues_job_when_enabled(db_session, monkeypatch, _fake_redis):
    """При apk_build_enabled=True enqueue_apk_build должен вернуть задачу QUEUED и реально поставить её в RQ."""
    monkeypatch.setattr("app.core.build.apk.settings.apk_build_enabled", True)

    user = await _user(db_session)
    project = await _project(db_session, user)

    job = await enqueue_apk_build(db_session, user, project.id)

    assert job.status == ApkBuildJobStatus.QUEUED
    assert job.queue_job_id is not None

    from app.core.queue import get_queue, priority_queue_name_for
    queue_name = priority_queue_name_for(user)
    assert queue_name == "free"
    assert get_queue(queue_name).fetch_job(job.queue_job_id) is not None


@pytest.mark.asyncio
async def test_worker_executes_queued_apk_build_job_end_to_end(monkeypatch, tmp_path, _fake_redis):
    """
    Полный путь: enqueue_apk_build ставит задачу -> воркер RQ реально её
    исполняет (через run_apk_build_job_sync) -> статус в БД обновляется.

    Воркер открывает СВОЮ сессию через app.database.async_session_maker,
    а RQ SimpleWorker.work(burst=True) исполняет job-функцию синхронно
    в отдельном потоке со своим event loop (app.core.queue.run_coro_sync).
    Намеренно НЕ переиспользуем db_session/test_engine (in-memory SQLite,
    `sqlite+aiosqlite:///:memory:`) — для `:memory:` каждое новое
    подключение открывает НОВУЮ пустую базу, а с разных event loop'ов
    подряд использовать один и тот же pooled-коннекшен ненадёжно.
    Вместо этого — отдельный файловый SQLite: обычные подключения к
    файлу из разных потоков последовательно (не конкурентно) безопасны.
    """
    from sqlalchemy import select
    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

    from app.database import Base
    from app.database.models import ApkBuildJob

    db_path = tmp_path / "queue_test.db"
    engine = create_async_engine(f"sqlite+aiosqlite:///{db_path}")
    session_maker = async_sessionmaker(engine, expire_on_commit=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    monkeypatch.setattr("app.database.async_session_maker", session_maker)
    monkeypatch.setattr("app.core.build.apk.settings.apk_build_enabled", True)
    monkeypatch.setattr("app.core.build.apk.settings.project_gen_workspace_dir", str(tmp_path))

    try:
        async with session_maker() as db:
            user = await _user(db)
            project = await _project(db, user)
            job = await enqueue_apk_build(db, user, project.id)
            assert job.status == ApkBuildJobStatus.QUEUED
            job_id = job.id

        from app.core.queue import get_queue, priority_queue_name_for
        worker = SimpleWorker([get_queue(priority_queue_name_for(user))], connection=_fake_redis)
        worker.work(burst=True)

        # gradlew отсутствует в tmp_path -> воркер должен пометить задачу FAILED, не бросить исключение наружу.
        async with session_maker() as db:
            refreshed = (await db.execute(select(ApkBuildJob).where(ApkBuildJob.id == job_id))).scalar_one()
            assert refreshed.status == ApkBuildJobStatus.FAILED
            assert "gradlew" in refreshed.log
    finally:
        await engine.dispose()
