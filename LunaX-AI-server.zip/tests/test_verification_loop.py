"""
Тесты цикла само-проверки Lunox AI (app/core/ai/verification.py) для
self-hosted архитектуры (два независимых инстанса инференс-сервера):
- если верификация выключена — просто ответ основного, verified=False;
- если второй endpoint не сконфигурирован — верификация пропускается;
- если рецензент сразу подтвердил CORRECT — 1 попытка, verified=True;
- если рецензент нашёл проблемы — основной переделывает, до лимита попыток;
- лимит попыток соблюдается, бесконечного цикла нет.

Реальные HTTP-вызовы к серверам не выполняются — get_primary_provider/
get_verification_provider подменяются моками напрямую.

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
from unittest.mock import AsyncMock, patch

import pytest

from app.core.ai.provider import AIResponse
from app.core.ai.verification import generate_with_verification


@pytest.mark.asyncio
async def test_verification_disabled_returns_unverified(monkeypatch):
    monkeypatch.setattr("app.core.ai.verification.settings.lunox_verification_enabled", False)

    primary = AsyncMock()
    primary.generate.return_value = AIResponse(text="ответ", provider_used="self_hosted")

    with patch("app.core.ai.verification.get_primary_provider", return_value=primary):
        result = await generate_with_verification("вопрос")

    assert result.text == "ответ"
    assert result.verified is False
    assert result.attempts_used == 1


@pytest.mark.asyncio
async def test_no_verification_endpoint_configured_skips_verification(monkeypatch):
    monkeypatch.setattr("app.core.ai.verification.settings.lunox_verification_enabled", True)

    primary = AsyncMock()
    primary.generate.return_value = AIResponse(text="ответ", provider_used="self_hosted")

    with patch("app.core.ai.verification.get_primary_provider", return_value=primary), \
         patch("app.core.ai.verification.get_verification_provider", return_value=None):
        result = await generate_with_verification("вопрос")

    assert result.verified is False
    assert result.attempts_used == 1


@pytest.mark.asyncio
async def test_critic_confirms_correct_on_first_try(monkeypatch):
    monkeypatch.setattr("app.core.ai.verification.settings.lunox_verification_enabled", True)
    monkeypatch.setattr("app.core.ai.verification.settings.lunox_max_revision_attempts", 2)

    primary = AsyncMock()
    primary.generate.return_value = AIResponse(text="исходный ответ", provider_used="self_hosted")

    critic = AsyncMock()
    critic.generate.return_value = AIResponse(text="STATUS: CORRECT", provider_used="self_hosted")

    with patch("app.core.ai.verification.get_primary_provider", return_value=primary), \
         patch("app.core.ai.verification.get_verification_provider", return_value=critic):
        result = await generate_with_verification("вопрос")

    assert result.text == "исходный ответ"
    assert result.verified is True
    assert result.attempts_used == 1


@pytest.mark.asyncio
async def test_critic_requests_revision_then_confirms(monkeypatch):
    monkeypatch.setattr("app.core.ai.verification.settings.lunox_verification_enabled", True)
    monkeypatch.setattr("app.core.ai.verification.settings.lunox_max_revision_attempts", 3)

    primary_responses = iter(["исходный ответ", "исправленный ответ"])
    primary_call_count = 0

    async def _primary_gen(prompt, context=None):
        nonlocal primary_call_count
        primary_call_count += 1
        return AIResponse(text=next(primary_responses), provider_used="self_hosted")

    primary = AsyncMock()
    primary.generate.side_effect = _primary_gen

    critic_responses = iter(["STATUS: ISSUES_FOUND\n- факт неверен", "STATUS: CORRECT"])

    async def _critic_gen(prompt, context=None):
        return AIResponse(text=next(critic_responses), provider_used="self_hosted")

    critic = AsyncMock()
    critic.generate.side_effect = _critic_gen

    with patch("app.core.ai.verification.get_primary_provider", return_value=primary), \
         patch("app.core.ai.verification.get_verification_provider", return_value=critic):
        result = await generate_with_verification("вопрос")

    assert result.text == "исправленный ответ"
    assert result.verified is True
    assert result.attempts_used == 2
    assert primary_call_count == 2  # исходная генерация + одна переделка


@pytest.mark.asyncio
async def test_revision_limit_respected_no_infinite_loop(monkeypatch):
    monkeypatch.setattr("app.core.ai.verification.settings.lunox_verification_enabled", True)
    monkeypatch.setattr("app.core.ai.verification.settings.lunox_max_revision_attempts", 2)

    primary = AsyncMock()
    primary.generate.return_value = AIResponse(text="ответ", provider_used="self_hosted")

    critic = AsyncMock()
    # Рецензент никогда не подтверждает -> должен остановиться по лимиту, а не зациклиться.
    critic.generate.return_value = AIResponse(
        text="STATUS: ISSUES_FOUND\n- всё ещё не так",
        provider_used="self_hosted",
    )

    with patch("app.core.ai.verification.get_primary_provider", return_value=primary), \
         patch("app.core.ai.verification.get_verification_provider", return_value=critic):
        result = await generate_with_verification("вопрос")

    assert result.verified is False
    assert result.attempts_used == 2  # ровно лимит, не больше
