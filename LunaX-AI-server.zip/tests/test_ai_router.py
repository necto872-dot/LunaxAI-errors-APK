"""
Тесты Lunox AI router (финальное ТЗ раздел 1, 15): честная недоступность
без сконфигурированного provider, возврат токенов при неудаче.

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
from datetime import date

import pytest

from app.database.models import User, UserRole
from app.modules.auth.services import hash_password


async def _create_verified_user(db_session):
    user = User(
        email="chatter@example.com",
        username="chatter",
        hashed_password=hash_password("password123"),
        role=UserRole.USER,
        is_active=True,
        email_verified=True,
        date_of_birth=date(2000, 1, 1),
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


async def _login(client):
    resp = await client.post("/api/v1/auth/login", json={"email": "chatter@example.com", "password": "password123"})
    assert resp.status_code == 200, resp.text
    return {"Authorization": f"Bearer {resp.json()['access_token']}"}


@pytest.mark.asyncio
async def test_chat_returns_503_and_refunds_tokens_without_provider(client, db_session):
    user = await _create_verified_user(db_session)
    headers = await _login(client)
    balance_before = user.token_balance

    resp = await client.post("/api/v1/search/query", json={"prompt": "hello"}, headers=headers)
    # settings.lunox_ai_enabled=False по умолчанию (self-hosted сервер не поднят) -> честный 503.
    assert resp.status_code == 503

    await db_session.refresh(user)
    # Токены списанные под операцию, которая не состоялась, должны вернуться.
    assert user.token_balance == balance_before


@pytest.mark.asyncio
async def test_chat_web_search_on_by_default_calls_search(client, db_session, monkeypatch):
    """По решению владельца (см. settings.lunox_web_search_enabled) чат ходит
    в веб по умолчанию, без явного флага в запросе — use_web_search=True
    в схеме запроса по умолчанию (см. search/schemas.py)."""
    from unittest.mock import AsyncMock, patch
    await _create_verified_user(db_session)
    headers = await _login(client)

    with patch("app.modules.search.routers.search_web", new=AsyncMock(return_value=[])) as mock_search:
        await client.post("/api/v1/search/query", json={"prompt": "привет"}, headers=headers)
    mock_search.assert_called_once()


@pytest.mark.asyncio
async def test_chat_web_search_flag_off_explicit_no_search_call(client, db_session, monkeypatch):
    from unittest.mock import AsyncMock, patch
    await _create_verified_user(db_session)
    headers = await _login(client)

    with patch("app.modules.search.routers.search_web", new=AsyncMock()) as mock_search:
        await client.post(
            "/api/v1/search/query", json={"prompt": "привет", "use_web_search": False}, headers=headers
        )
    mock_search.assert_not_called()


@pytest.mark.asyncio
async def test_chat_web_search_flag_on_calls_search(client, db_session, monkeypatch):
    from unittest.mock import AsyncMock, patch
    await _create_verified_user(db_session)
    headers = await _login(client)

    with patch("app.modules.search.routers.search_web", new=AsyncMock(return_value=[])) as mock_search:
        await client.post(
            "/api/v1/search/query", json={"prompt": "погода", "use_web_search": True}, headers=headers
        )
    mock_search.assert_called_once()
