"""
Тесты биометрии (app/core/biometry.py): одноразовый challenge, replay-
защита, счётчик неудачных попыток, блокировка после лимита, audit log.

ЧЕСТНО (как и в самом коде): здесь проверяется только ПРОТОКОЛ вокруг
liveness-проверки — реального визуального анализа (действительно ли
пользователь моргнул перед камерой) в проекте нет, это отдельная ML-
задача. `passed`/`suspected_replay` в тестах передаются напрямую, как
если бы их прислал клиент после (гипотетического) локального CV-анализа.

NOT VERIFIED в этом окружении — нет сети/пакетов (см. tests/conftest.py).
"""
from datetime import timedelta

import pytest

from app.core.biometry import BiometryError, create_challenge, verify_liveness
from app.database.models import User, UserRole
from app.modules.auth.services import hash_password


async def _create_user(db_session, email="biometry@example.com", username="biometryuser"):
    user = User(
        email=email,
        username=username,
        hashed_password=hash_password("password123"),
        role=UserRole.USER,
        is_active=True,
        email_verified=True,
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


@pytest.mark.asyncio
async def test_successful_verification_sets_flag_and_resets_counters(db_session):
    user = await _create_user(db_session)
    challenge = await create_challenge(db_session, user)

    result = await verify_liveness(db_session, user, challenge.id, passed=True)

    assert result["status"] == "verified"
    await db_session.refresh(user)
    assert user.is_biometric_verified is True
    assert user.biometry_failed_attempts == 0


@pytest.mark.asyncio
async def test_failed_attempt_increments_counter_without_lockout(db_session, monkeypatch):
    monkeypatch.setattr("app.core.biometry.settings.biometry_max_failed_attempts", 5)

    user = await _create_user(db_session)
    challenge = await create_challenge(db_session, user)

    result = await verify_liveness(db_session, user, challenge.id, passed=False)

    assert result["status"] == "failed"
    await db_session.refresh(user)
    assert user.biometry_failed_attempts == 1
    assert user.biometry_locked_until is None


@pytest.mark.asyncio
async def test_lockout_after_max_failed_attempts(db_session, monkeypatch):
    monkeypatch.setattr("app.core.biometry.settings.biometry_max_failed_attempts", 3)
    monkeypatch.setattr("app.core.biometry.settings.biometry_lockout_minutes", 15)

    user = await _create_user(db_session)

    for _ in range(2):
        challenge = await create_challenge(db_session, user)
        result = await verify_liveness(db_session, user, challenge.id, passed=False)
        assert result["status"] == "failed"

    challenge = await create_challenge(db_session, user)
    result = await verify_liveness(db_session, user, challenge.id, passed=False)

    assert result["status"] == "locked"
    await db_session.refresh(user)
    assert user.biometry_failed_attempts == 0  # сброшен при блокировке
    assert user.biometry_locked_until is not None


@pytest.mark.asyncio
async def test_new_challenge_rejected_while_locked(db_session, monkeypatch):
    monkeypatch.setattr("app.core.biometry.settings.biometry_max_failed_attempts", 1)

    user = await _create_user(db_session)
    challenge = await create_challenge(db_session, user)
    result = await verify_liveness(db_session, user, challenge.id, passed=False)
    assert result["status"] == "locked"

    with pytest.raises(BiometryError) as exc_info:
        await create_challenge(db_session, user)
    assert exc_info.value.status_code == 423


@pytest.mark.asyncio
async def test_challenge_reuse_rejected_as_replay(db_session):
    user = await _create_user(db_session)
    challenge = await create_challenge(db_session, user)

    first = await verify_liveness(db_session, user, challenge.id, passed=True)
    assert first["status"] == "verified"

    with pytest.raises(BiometryError) as exc_info:
        await verify_liveness(db_session, user, challenge.id, passed=True)
    assert exc_info.value.status_code == 409


@pytest.mark.asyncio
async def test_suspected_replay_rejected_even_if_passed_true(db_session):
    user = await _create_user(db_session)
    challenge = await create_challenge(db_session, user)

    with pytest.raises(BiometryError) as exc_info:
        await verify_liveness(db_session, user, challenge.id, passed=True, suspected_replay=True)
    assert exc_info.value.status_code == 403

    await db_session.refresh(user)
    assert user.is_biometric_verified is False  # не засчиталось, несмотря на passed=True


@pytest.mark.asyncio
async def test_expired_challenge_rejected(db_session):
    user = await _create_user(db_session)
    challenge = await create_challenge(db_session, user)

    from app.core.biometry import _now
    challenge.expires_at = _now() - timedelta(minutes=1)
    await db_session.commit()

    with pytest.raises(BiometryError) as exc_info:
        await verify_liveness(db_session, user, challenge.id, passed=True)
    assert exc_info.value.status_code == 410


@pytest.mark.asyncio
async def test_cannot_use_other_users_challenge(db_session):
    owner = await _create_user(db_session, "bioowner@example.com", "bioowner")
    intruder = await _create_user(db_session, "biointruder@example.com", "biointruder")

    challenge = await create_challenge(db_session, owner)

    with pytest.raises(BiometryError) as exc_info:
        await verify_liveness(db_session, intruder, challenge.id, passed=True)
    assert exc_info.value.status_code == 404
