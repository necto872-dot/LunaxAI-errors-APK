"""Тесты flow создания песни: state machine, нельзя обойти согласие/шаги."""
import math
import struct
import wave
from io import BytesIO
from unittest.mock import AsyncMock, patch

import pytest

from app.core.voice.song_flow import (
    SongFlowError,
    choose_voice,
    finalize_song,
    give_consent,
    set_lyrics,
    start_song_session,
    submit_voice_sample,
)
from app.database.models import User, UserRole
from app.modules.auth.services import hash_password


async def _user(db):
    u = User(email="song@example.com", username="songuser", hashed_password=hash_password("password123"),
              role=UserRole.USER, is_active=True, email_verified=True)
    db.add(u)
    await db.commit()
    await db.refresh(u)
    return u


def _wav(freq=220.0, dur=0.3, rate=16000):
    n = int(rate * dur)
    samples = [int(10000 * math.sin(2*math.pi*freq*i/rate)) for i in range(n)]
    buf = BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(struct.pack("<" + "h"*n, *samples))
    return buf.getvalue()


@pytest.mark.asyncio
async def test_cannot_skip_stages(db_session):
    user = await _user(db_session)
    session = await start_song_session(db_session, user)
    with pytest.raises(SongFlowError):
        await choose_voice(db_session, user, session.id, True)  # пропустили lyrics


@pytest.mark.asyncio
async def test_own_voice_requires_consent_before_samples(db_session):
    user = await _user(db_session)
    session = await start_song_session(db_session, user)
    session = await set_lyrics(db_session, user, session.id, "текст песни")
    session = await choose_voice(db_session, user, session.id, True)
    assert session.stage.value == "awaiting_consent"

    with pytest.raises(SongFlowError):
        await submit_voice_sample(db_session, user, session.id, _wav())  # пропустили consent


@pytest.mark.asyncio
async def test_denying_consent_blocks_flow(db_session):
    user = await _user(db_session)
    session = await start_song_session(db_session, user)
    session = await set_lyrics(db_session, user, session.id, "текст")
    session = await choose_voice(db_session, user, session.id, True)
    with pytest.raises(SongFlowError) as exc:
        await give_consent(db_session, user, session.id, False)
    assert exc.value.status_code == 403


@pytest.mark.asyncio
async def test_generated_voice_skips_consent(db_session):
    user = await _user(db_session)
    session = await start_song_session(db_session, user)
    session = await set_lyrics(db_session, user, session.id, "текст")
    session = await choose_voice(db_session, user, session.id, False)  # сгенерированный голос
    assert session.stage.value == "ready"


@pytest.mark.asyncio
async def test_full_own_voice_flow_creates_profile(db_session):
    user = await _user(db_session)
    session = await start_song_session(db_session, user)
    session = await set_lyrics(db_session, user, session.id, "текст")
    session = await choose_voice(db_session, user, session.id, True)
    session = await give_consent(db_session, user, session.id, True)
    session = await submit_voice_sample(db_session, user, session.id, _wav())
    assert session.stage.value == "ready"
    assert session.voice_profile_id is not None


@pytest.mark.asyncio
async def test_other_user_cannot_access_session(db_session):
    user1 = await _user(db_session)
    from app.database.models import User as U
    from app.modules.auth.services import hash_password as hp
    user2 = U(email="other@example.com", username="otheruser", hashed_password=hp("password123"),
              role=UserRole.USER, is_active=True, email_verified=True)
    db_session.add(user2)
    await db_session.commit()
    await db_session.refresh(user2)

    session = await start_song_session(db_session, user1)
    with pytest.raises(SongFlowError) as exc:
        await set_lyrics(db_session, user2, session.id, "чужой текст")
    assert exc.value.status_code == 404


@pytest.mark.asyncio
async def test_finalize_without_lyrics_fails(db_session):
    user = await _user(db_session)
    session = await start_song_session(db_session, user)
    with pytest.raises(SongFlowError):
        await finalize_song(db_session, user, session.id, "pop", "happy")


@pytest.mark.asyncio
async def test_finalize_calls_music_client_with_pitch_hint(db_session):
    user = await _user(db_session)
    session = await start_song_session(db_session, user)
    session = await set_lyrics(db_session, user, session.id, "текст")
    session = await choose_voice(db_session, user, session.id, False)

    with patch("app.core.voice.song_flow.generate_song", new=AsyncMock(return_value=b"fakemp3")) as mock_gen:
        result = await finalize_song(db_session, user, session.id, "pop", "happy")
    assert result == b"fakemp3"
    mock_gen.assert_called_once()


@pytest.mark.asyncio
async def test_lyrics_blocked_by_safety(db_session):
    user = await _user(db_session)
    session = await start_song_session(db_session, user)
    with pytest.raises(SongFlowError) as exc:
        await set_lyrics(db_session, user, session.id, "как сделать бомбу текст песни")
    assert exc.value.status_code == 400
