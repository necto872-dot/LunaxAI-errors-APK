"""
Инициализация асинхронного подключения к БД (SQLAlchemy async).

По умолчанию используется SQLite (для разработки на телефоне без
сервера), в проде — PostgreSQL через DATABASE_URL в .env.
"""
from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from app.config.settings import get_settings

settings = get_settings()

engine = create_async_engine(settings.database_url, echo=(settings.env == "development"))
async_session_maker = async_sessionmaker(engine, expire_on_commit=False)


class Base(DeclarativeBase):
    """Базовый класс для всех ORM-моделей проекта."""


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI-зависимость: асинхронная сессия БД на запрос."""
    async with async_session_maker() as session:
        yield session


async def init_models() -> None:
    """Создать таблицы из моделей (для разработки; в проде — Alembic)."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
