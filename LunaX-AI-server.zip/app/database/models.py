"""
ORM-модели проекта LunaX AI.

Реализует модель пользователя и системы Developer / Primary Developer
согласно LunaX_AI_TZ.txt (master spec): роли USER/PREMIUM/DEVELOPER/
PRIMARY_DEVELOPER/ADMIN, email-верификация, reset/verification/email-change
токены, audit log критических операций.
"""
import uuid
from datetime import UTC, date, datetime
from enum import StrEnum

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    Date,
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    String,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.now(UTC)


class UserRole(StrEnum):
    USER = "user"
    PREMIUM = "premium"
    DEVELOPER = "developer"
    PRIMARY_DEVELOPER = "primary_developer"
    ADMIN = "admin"


class SubscriptionTier(StrEnum):
    FREE = "free"
    PRO = "pro"
    PRO_PLUS = "pro_plus"
    ULTRA = "ultra"
    ULTRA_PLUS = "ultra_plus"


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)

    role: Mapped[UserRole] = mapped_column(SAEnum(UserRole), default=UserRole.USER, nullable=False)
    subscription_tier: Mapped[SubscriptionTier] = mapped_column(
        SAEnum(SubscriptionTier), default=SubscriptionTier.FREE, nullable=False
    )

    # Токен-квота — источник истины только сервер, клиенту не доверяем
    # (ТЗ п.5, п.39, п.72). token_limit — максимум для текущего тарифа/роли;
    # token_balance — текущий доступный остаток. unlimited_usage обходит
    # проверку остатка (Developer/Primary), но НЕ равнозначно серверным
    # правам.
    #
    # Механизм восстановления (см. app/core/quota.py):
    # - last_daily_reset_date: последний день, когда применялся безусловный
    #   полный сброс в 00:00 (срабатывает независимо от остатка);
    # - critical_recovery_started_at: момент, когда остаток впервые упал
    #   ниже критического порога — с этого момента считается индивидуальный
    #   таймер восстановления (не с момента последнего обычного запроса).
    token_balance: Mapped[int] = mapped_column(BigInteger, default=5_000_000, nullable=False)
    token_limit: Mapped[int] = mapped_column(BigInteger, default=5_000_000, nullable=False)
    unlimited_usage: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    last_daily_reset_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    critical_recovery_started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    email_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # Возрастное ограничение платформы (16+, ТЗ владельца) + принятие
    # пользовательского соглашения. Оба обязательны при регистрации
    # (проверяются на сервере в register_user, не только на клиенте) —
    # date_of_birth хранится для аудита/повторной проверки, а не только
    # как разовая галочка "мне есть 16".
    # default только подстраховка для старых тестов/прямых ORM-вставок,
    # созданных до появления этого поля — регистрация через API по-прежнему
    # требует date_of_birth как обязательное поле схемы (см. auth/schemas.py),
    # это НЕ ослабляет реальную возрастную проверку.
    date_of_birth: Mapped[date] = mapped_column(Date, nullable=False, default=date(2000, 1, 1))
    terms_accepted_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=_now)
    terms_version: Mapped[str] = mapped_column(String(16), nullable=False, default="1.0")

    # Биометрия (ТЗ: liveness-проверка с лимитом попыток, эскалация на
    # пароль после провала). is_biometric_verified — итог последней
    # успешной проверки; failed_attempts/locked_until — защита от подбора.
    is_biometric_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    biometry_failed_attempts: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    biometry_locked_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_now, onupdate=_now)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_login_ip: Mapped[str | None] = mapped_column(String(64), nullable=True)

    # Временный бан (ручной /ban-duration или авто по N HIGH security-событиям
    # подряд, см. app/core/security_events.py:check_auto_actions). Отдельно
    # от is_active — бессрочная деактивация (/ban) им не трогается.
    banned_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    banned_reason: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Отзыв всех выданных JWT разом ("выйти everywhere"): токен с iat раньше
    # этой метки считается недействительным, даже если срок его действия
    # ещё не истёк (см. auth/dependencies.py:get_current_user). None = ничего
    # не отзывалось.
    session_revoked_before: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # Telegram-уведомления о HIGH security-событиях (альтернатива email,
    # быстрее долетает на мобильный). Разработчик сам привязывает chat_id
    # через /telegram <email> <chat_id> в консоли (app/core/console_commands.py).
    telegram_chat_id: Mapped[str | None] = mapped_column(String(64), nullable=True)

    # TOTP-2FA для входа в саму Developer Console (app/core/totp.py).
    # totp_secret хранится как есть (не токен доступа, а seed генератора
    # кодов) — сравнимо по чувствительности с паролем; secret ротируется
    # через /2fa/setup заново, если скомпрометирован.
    totp_secret: Mapped[str | None] = mapped_column(String(64), nullable=True)
    totp_enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # Согласие на использование переписки пользователя в датасете для
    # дообучения (LoRA) Lunox AI. Opt-in, по умолчанию False: реальные
    # диалоги (Conversation/Message) НЕ попадают в обучающую выборку, пока
    # пользователь явно не включит это в настройках (см.
    # PATCH /auth/me/training-consent). training/collect_from_db.py
    # фильтрует по этому полю перед экспортом — это не UI-галочка "для
    # вида", а единственное условие включения диалога в raw_conversations.
    allow_training_data_use: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


class EmailVerificationToken(Base):
    __tablename__ = "email_verification_tokens"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    token_hash: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    used_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    token_hash: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    used_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class EmailChangeToken(Base):
    __tablename__ = "email_change_tokens"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    new_email: Mapped[str] = mapped_column(String(255), nullable=False)
    token_hash: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    used_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class BiometryChallenge(Base):
    """
    Одноразовый challenge для liveness-проверки — защита от replay-атаки
    на уровне ПРОТОКОЛА: без сохранённого server-side challenge клиент мог
    бы прислать "passed=true" для чего угодно, никак не привязываясь к
    конкретному запрошенному набору действий.

    ЧЕСТНОЕ ОГРАНИЧЕНИЕ: реальный визуальный анализ (проверка, что
    пользователь ДЕЙСТВИТЕЛЬНО моргнул/повернул голову и т.д. по видео) —
    отдельная ML-задача (детекция лица, anti-spoofing), которой в проекте
    нет. Этот механизм гарантирует только то, что можно гарантировать без
    неё: challenge одноразовый, с истечением, привязан к пользователю и
    конкретному набору запрошенных действий — а не факт, что действия были
    выполнены по-настоящему перед камерой.
    """

    __tablename__ = "biometry_challenges"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    actions: Mapped[str] = mapped_column(String(500), nullable=False)  # JSON-список действий
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    used_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class UploadedFile(Base):
    """
    Загруженный пользователем файл (ТЗ раздел 25-28: ownership, MIME,
    размер, отсутствие path traversal).

    Файл хранится на диске под случайным UUID-именем (не оригинальным
    именем пользователя) — оригинальное имя сохраняется только как
    метаданные. Доступ проверяется исключительно по owner_id, никогда
    по одному лишь знанию id/пути (ТЗ п.35).
    """

    __tablename__ = "uploaded_files"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    original_filename: Mapped[str] = mapped_column(String(255), nullable=False)
    stored_filename: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    content_type: Mapped[str] = mapped_column(String(128), nullable=False)
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class PaymentStatus(StrEnum):
    PENDING = "pending"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    REFUNDED = "refunded"


class Payment(Base):
    """
    Платёж за смену тарифа (финальное ТЗ раздел 10-12: PaymentProvider
    abstraction). provider — строка ("kaspi"/"freedompay"/...), не enum,
    чтобы новые провайдеры добавлялись без миграции схемы.

    external_payment_id уникален и используется для идемпотентности:
    повторный webhook с тем же external_payment_id не должен повторно
    активировать тариф/начислять баланс (финальное ТЗ раздел 11).
    """

    __tablename__ = "payments"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    provider: Mapped[str] = mapped_column(String(32), nullable=False)
    external_payment_id: Mapped[str | None] = mapped_column(String(128), unique=True, nullable=True, index=True)
    tariff: Mapped[SubscriptionTier] = mapped_column(SAEnum(SubscriptionTier), nullable=False)
    amount_kzt: Mapped[int] = mapped_column(BigInteger, nullable=False)
    status: Mapped[PaymentStatus] = mapped_column(SAEnum(PaymentStatus), default=PaymentStatus.PENDING, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_now, onupdate=_now)


class PaymentEvent(Base):
    """
    Сырое событие webhook от платёжного провайдера, для аудита/отладки.

    НЕ хранит данные карт (ТЗ раздел 11: "Данные банковских карт не
    хранить в системе Lunox") — только то, что реально прислал провайдер
    в теле webhook (обычно статус/сумма/id, без PAN/CVV).
    """

    __tablename__ = "payment_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    payment_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("payments.id"), nullable=True, index=True)
    provider: Mapped[str] = mapped_column(String(32), nullable=False)
    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    payload: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now, index=True)


class MessageRole(StrEnum):
    USER = "user"
    ASSISTANT = "assistant"


class Conversation(Base):
    """
    Диалог с Lunox AI (кратковременная память — ТЗ-аудит: "память между
    сообщениями/сессиями отсутствует"). Один Conversation = один тред
    переписки; сообщения внутри него дают модели контекст предыдущих
    реплик при каждом новом запросе.
    """

    __tablename__ = "conversations"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    title: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_now, onupdate=_now)


class Message(Base):
    """Одно сообщение внутри Conversation (роль user/assistant)."""

    __tablename__ = "messages"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    conversation_id: Mapped[str] = mapped_column(String(36), ForeignKey("conversations.id"), nullable=False, index=True)
    role: Mapped[MessageRole] = mapped_column(SAEnum(MessageRole), nullable=False)
    content: Mapped[str] = mapped_column(String, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now, index=True)


class UserMemoryFact(Base):
    """
    Долговременная память пользователя — явный механизм remember/forget
    (ТЗ-аудит: "❌ механизм remember/forget" отмечен как отсутствующий).

    НЕ семантический поиск/embeddings (это отдельная задача, требующая
    embedding-модели, которой в проекте нет) — простое хранилище фактов
    "запомни это", которые Lunox AI получает в каждом запросе как
    дополнительный контекст, пока пользователь явно не попросит забыть.
    """

    __tablename__ = "user_memory_facts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    content: Mapped[str] = mapped_column(String(2000), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class UpdateConfirmationToken(Base):
    """
    Подтверждение применения обновления (ТЗ раздел 9: доступно только
    через доверенную консоль Developer/Admin, не публичный HTTP-apply).

    Тот же принцип, что и у Primary Developer (ТЗ раздел 7): опасное
    действие (обновление кода) нельзя выполнить одним HTTP-запросом без
    подтверждения — сначала /updates/check создаёт токен, затем
    /updates/apply его проверяет и логирует намерение, а РЕАЛЬНЫЙ деплой
    (git pull, миграции, рестарт) выполняется локально через
    scripts/apply_update.py — той же схемой, что bootstrap/manage_primary.
    """

    __tablename__ = "update_confirmation_tokens"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    requested_by: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    target_version: Mapped[str] = mapped_column(String(64), nullable=False)
    token_hash: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    used_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class ProjectStatus(StrEnum):
    DRAFT = "draft"
    GENERATING = "generating"
    READY = "ready"
    FAILED = "failed"


class BuildJobStatus(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class Project(Base):
    """
    Проект, сгенерированный Lunox AI (ТЗ раздел 27: Prompt -> Specification
    -> Architecture -> File Tree -> Code -> Validation -> Tests -> Build ->
    Artifact). Владение — как у файлов/диалогов: только owner_id.
    """

    __tablename__ = "projects"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    prompt: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[ProjectStatus] = mapped_column(SAEnum(ProjectStatus), default=ProjectStatus.DRAFT, nullable=False)
    current_version: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_now, onupdate=_now)


class ProjectVersion(Base):
    """
    Снапшот сгенерированного проекта (ТЗ раздел 29: project_id, version,
    created_at, история). file_manifest — JSON {relative_path: content},
    не файлы на диске — маленькие текстовые проекты, а не бинарники
    (для бинарных артефактов — см. ProjectVersion.artifact_path ниже,
    которое указывает на файл в file_storage_dir, тем же паттерном, что
    UploadedFile).
    """

    __tablename__ = "project_versions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    project_id: Mapped[str] = mapped_column(String(36), ForeignKey("projects.id"), nullable=False, index=True)
    version_number: Mapped[int] = mapped_column(BigInteger, nullable=False)
    file_manifest: Mapped[dict] = mapped_column(JSON, nullable=False)
    validation_passed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    artifact_path: Mapped[str | None] = mapped_column(
        String(255), nullable=True
    )  # относительный путь в file_storage_dir, если запакован в zip
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class BuildJob(Base):
    """
    Запуск генерации/валидации/автоисправления для одной ProjectVersion.
    attempt_count ограничен settings.project_gen_max_fix_attempts — защита
    от бесконечного AI-repair-loop (ТЗ раздел 28).
    """

    __tablename__ = "build_jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    project_id: Mapped[str] = mapped_column(String(36), ForeignKey("projects.id"), nullable=False, index=True)
    project_version_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("project_versions.id"), nullable=True
    )
    status: Mapped[BuildJobStatus] = mapped_column(
        SAEnum(BuildJobStatus), default=BuildJobStatus.QUEUED, nullable=False
    )
    attempt_count: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    log: Mapped[str] = mapped_column(String, default="", nullable=False)
    # id задачи в приоритетной очереди RQ (app/core/queue.py) — заполняется
    # только для генераций, поставленных через enqueue_project_generation();
    # NULL для прямых синхронных вызовов generate_project() (тесты/воркер).
    queue_job_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class ApkBuildJobStatus(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class ApkBuildJob(Base):
    """
    APK-сборка Android-проекта через Gradle. НЕ выполняет реальную сборку
    без Android SDK/Gradle на сервере — см. app/core/build/apk.py, там
    честно объяснена граница между интерфейсом и реальным выполнением.
    """

    __tablename__ = "apk_build_jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    project_id: Mapped[str] = mapped_column(String(36), ForeignKey("projects.id"), nullable=False, index=True)
    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    status: Mapped[ApkBuildJobStatus] = mapped_column(
        SAEnum(ApkBuildJobStatus), default=ApkBuildJobStatus.QUEUED, nullable=False
    )
    log: Mapped[str] = mapped_column(String, default="", nullable=False)
    artifact_path: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # id задачи в приоритетной очереди RQ — см. комментарий у BuildJob.queue_job_id.
    queue_job_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class VoiceProfile(Base):
    """Временный голосовой профиль. Только с явного согласия, только для одной задачи."""

    __tablename__ = "voice_profiles"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    consent_given_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    pitch_low_hz: Mapped[float | None] = mapped_column(nullable=True)
    pitch_high_hz: Mapped[float | None] = mapped_column(nullable=True)
    sample_storage_path: Mapped[str | None] = mapped_column(String(255), nullable=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class SongSessionStage(StrEnum):
    AWAITING_LYRICS_OR_RECORDING_CHOICE = "awaiting_lyrics_or_recording_choice"
    AWAITING_VOICE_CHOICE = "awaiting_voice_choice"
    AWAITING_CONSENT = "awaiting_consent"
    AWAITING_SAMPLES = "awaiting_samples"
    READY = "ready"


class SongSession(Base):
    """Пошаговый диалог создания песни (ТЗ раздел 6-7). Состояние — сервер, не UI."""

    __tablename__ = "song_sessions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    stage: Mapped[SongSessionStage] = mapped_column(
        SAEnum(SongSessionStage),
        default=SongSessionStage.AWAITING_LYRICS_OR_RECORDING_CHOICE,
        nullable=False,
    )
    lyrics: Mapped[str | None] = mapped_column(String, nullable=True)
    genre: Mapped[str | None] = mapped_column(String(64), nullable=True)
    mood: Mapped[str | None] = mapped_column(String(64), nullable=True)
    use_own_voice: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    voice_profile_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("voice_profiles.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_now, onupdate=_now)


class AuditLog(Base):
    """Журнал критических административных операций (ТЗ п.52).

    Никогда не хранит пароли, App Password, JWT или приватные токены —
    только событие, актора, цель и неконфиденциальные детали.
    """

    __tablename__ = "audit_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    event: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    actor_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    target_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    details: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now, index=True)


class SecurityEventSeverity(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class SecurityEvent(Base):
    """
    Отчёты о подозрительной активности для Консоли разработчика (раздел
    "Отчёты"): серии неудачных логинов, срабатывания rate-limit и т.п.
    Отдельно от AuditLog — это не запись о том, что кто-то сделал, а
    сигнал "на это стоит посмотреть Primary Developer/Developer".
    """

    __tablename__ = "security_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    event_type: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    severity: Mapped[SecurityEventSeverity] = mapped_column(
        SAEnum(SecurityEventSeverity), default=SecurityEventSeverity.LOW, nullable=False
    )
    email: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    ip_address: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    details: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    resolved: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)
    resolved_by_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now, index=True)


class PushPlatform(StrEnum):
    ANDROID = "android"
    IOS = "ios"


class PushDevice(Base):
    """FCM device token мобильного LunaX-клиента (Android/iOS через APNs
    relay) — push для HIGH security-событий, когда PD не на почте/Telegram.
    Один пользователь может иметь несколько устройств; token уникален —
    при переустановке/новом токене строка просто перезаписывается."""

    __tablename__ = "push_devices"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    platform: Mapped[PushPlatform] = mapped_column(SAEnum(PushPlatform), nullable=False)
    fcm_token: Mapped[str] = mapped_column(String(512), unique=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime, default=_now, onupdate=_now)


class BlockedIP(Base):
    """Чёрный список IP (раздел 'Реакция на угрозы'). Проверяется в
    app/core/ip_blocklist.py middleware на каждый запрос. expires_at=None —
    блокировка бессрочная (до ручного /unblockip)."""

    __tablename__ = "blocked_ips"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    ip_address: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    reason: Mapped[str | None] = mapped_column(String(255), nullable=True)
    blocked_by_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class TrainingRunStatus(StrEnum):
    """
    Жизненный цикл одного прогона автопайплайна дообучения
    (training/auto_pipeline.py).

    Пайплайн НАМЕРЕННО останавливается на EVAL_* и никогда не переходит в
    DEPLOYED сам — это финальное состояние выставляет только человек через
    Developer Console (POST /developer/training-runs/{id}/approve), после
    того как САМ выкатил новый merged-адаптер на инференс-сервер (vLLM/
    Ollama) и указал его путь. Это не искусственное ограничение "для вида":
    self_hosted_base_url в settings — это внешний процесс инференса,
    который данное FastAPI-приложение физически не перезапускает и не
    подгружает в память само.
    """

    COLLECTING = "collecting"
    TRAINING = "training"
    EVAL_PASSED = "eval_passed"
    EVAL_NEEDS_REVIEW = "eval_needs_review"
    FAILED = "failed"
    APPROVED = "approved"
    REJECTED = "rejected"
    DEPLOYED = "deployed"
    QUEUED = "queued"


class TrainingRun(Base):
    """
    Один прогон автопайплайна дообучения Lunox AI (сбор диалогов ->
    подготовка датасета -> LoRA -> merge -> самопроверка). Хранится как
    аудируемая история: кто одобрил/отклонил выкладку конкретного адаптера
    и когда, а не только "какая версия сейчас в проде".
    """

    __tablename__ = "training_runs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    status: Mapped[TrainingRunStatus] = mapped_column(
        SAEnum(TrainingRunStatus), default=TrainingRunStatus.COLLECTING, nullable=False, index=True
    )
    dataset_size: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    adapter_path: Mapped[str | None] = mapped_column(String(512), nullable=True)
    eval_summary: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    failure_reason: Mapped[str | None] = mapped_column(String(2000), nullable=True)
    log: Mapped[str] = mapped_column(String, default="", nullable=False)

    # Параметры прогона, заданные при запуске из Консоли обновления (см.
    # TrainingRunCreate) — хранятся отдельно от eval_summary (тот
    # перезаписывается результатом eval_candidate.py по завершении).
    tier: Mapped[str] = mapped_column(String(32), default="pro", nullable=False)
    max_conversations: Mapped[int] = mapped_column(BigInteger, default=500, nullable=False)
    epochs: Mapped[int] = mapped_column(BigInteger, default=3, nullable=False)

    # Кто запустил прогон из Консоли обновления (Developer Console) и что
    # именно он прислал (код/примеры) — отдельно от диалогов реальных
    # пользователей (собираются отдельно, только с их opt-in, см.
    # User.allow_training_data_use и training/collect_from_db.py).
    triggered_by_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("users.id"), nullable=True)
    submitted_examples: Mapped[list | None] = mapped_column(JSON, nullable=True)

    # id задачи в приоритетной очереди RQ (app/core/queue.py) — см.
    # app/core/training/pipeline.py:enqueue_training_run(). NULL для
    # прямых прогонов через training/auto_pipeline.py CLI (без Redis).
    queue_job_id: Mapped[str | None] = mapped_column(String(64), nullable=True)

    reviewed_by_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("users.id"), nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_now, onupdate=_now)
