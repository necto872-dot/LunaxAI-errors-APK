"""
Центральная конфигурация LunaX AI.

Все секреты и параметры загружаются из окружения (.env), ничего не
хардкодится в коде (ТЗ п.9, п.28, п.61).
"""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- Общее ---
    env: str = "development"
    log_level: str = "INFO"
    # Хост/порт для локального запуска через `python -m app.main` (uvicorn).
    # По умолчанию 127.0.0.1 (безопасно, без bind на все интерфейсы).
    # В контейнере/проде переопределяется через .env -> run_host=0.0.0.0.
    run_host: str = "127.0.0.1"
    run_port: int = 8000
    frontend_url: str = "http://localhost:3000"
    # Список разрешённых origin через запятую, для PWA-клиента и т.п. Пусто -> CORS не разрешён никому.
    cors_allowed_origins: str = "http://localhost:3000,http://localhost:8080,https://localhost,capacitor://localhost"

    # --- База данных ---
    database_url: str = "sqlite+aiosqlite:///./lunax.db"

    # --- JWT ---
    jwt_secret_key: str = "change_me_to_a_random_secret"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 30

    # --- Email verification / password reset / email change tokens ---
    email_verification_token_expire_hours: int = 24
    password_reset_token_expire_minutes: int = 30
    email_change_token_expire_hours: int = 1

    # --- Primary Developer bootstrap ---
    primary_developer_email: str = ""

    # --- Возрастное ограничение + пользовательское соглашение ---
    # Минимальный возраст регистрации (владелец: 16+, не меньше). Меняется
    # только здесь — используется и в pydantic-валидации схемы регистрации,
    # и повторно на сервере в register_user (защита от обхода через прямой
    # вызов API мимо схемы).
    min_registration_age_years: int = 16
    # Версия текста пользовательского соглашения — если правила меняются,
    # увеличьте эту строку; terms_accepted_at/terms_version в User хранят,
    # какую именно версию принял пользователь (для будущей возможности
    # "правила изменились, примите заново" — сам механизм повторного
    # принятия не реализован в этом проходе, только хранение факта).
    terms_version: str = "1.0"

    # --- SMTP (ТЗ раздел 24-27) ---
    smtp_host: str = "smtp.gmail.com"
    smtp_port: int = 587
    smtp_use_tls: bool = True
    smtp_use_ssl: bool = False
    smtp_username: str = ""
    smtp_password: str = ""
    smtp_from_email: str = ""
    smtp_from_name: str = "LunaX AI"

    # --- Redis / очередь ---
    redis_url: str = "redis://localhost:6379/0"

    # --- Платежи (финальное ТЗ раздел 10-12: PaymentProvider abstraction,
    # НЕ жёстко привязано к одному эквайрингу). Провайдер выбирается через
    # payment_provider ("kaspi" | "freedompay"); конкретный provider для
    # Казахстана владельцем окончательно НЕ утверждён — TODO/CONFIG. ---
    payment_provider: str = "kaspi"

    kaspi_merchant_id: str = ""
    kaspi_api_key: str = ""
    kaspi_webhook_secret: str = ""

    freedompay_merchant_id: str = ""
    freedompay_secret_key: str = ""
    freedompay_webhook_secret: str = ""

    # Реквизиты для ручной оплаты (счёт самозанятого в Kaspi.kz — без ИП,
    # см. манёвр в чате с владельцем): пока kaspi/freedompay provider не
    # подключён боевыми ключами, пользователь платит по этим реквизитам
    # вручную, а Developer подтверждает платёж в Консоли разработчика
    # (POST /developer/payments/{id}/confirm), см. payments/services.py.
    manual_payment_phone: str = ""
    manual_payment_name: str = "LunaX AI"

    # Устаревшее поле, оставлено только для обратной совместимости с уже
    # написанным кодом/тестами старого прохода; новую логику строить на
    # payment_provider выше, не на Stripe.
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""

    # --- AI-цепочка Lunox AI (финальное ТЗ раздел 1, 15-16) — РЕШЕНИЕ
    # ВЛАДЕЛЬЦА: убраны все платные внешние API (OpenAI/Anthropic/DeepSeek/
    # Mistral). Единственный provider — собственный self-hosted сервер с
    # дообученной моделью (см. training/README.md как её получить). Формат
    # обращения — OpenAI-совместимый chat/completions, это протокол, а не
    # обращение к OpenAI: так работают vLLM/Ollama/text-generation-inference.
    lunox_ai_enabled: bool = False  # TODO/CONFIG: включить, когда self_hosted_* заполнены и сервер поднят

    self_hosted_base_url: str = "http://localhost:8000/v1"
    self_hosted_model_name: str = ""  # TODO/CONFIG: имя/путь модели, как она объявлена на инференс-сервере
    self_hosted_api_key: str = ""  # опционально, если сервер требует Bearer-токен

    # Второй, ОПЦИОНАЛЬНЫЙ инстанс — для роли рецензента в цикле
    # само-проверки (см. lunox_verification_enabled ниже). Может быть тем
    # же сервером с другим чекпоинтом/промптом или отдельной машиной.
    self_hosted_verification_base_url: str = ""
    self_hosted_verification_model_name: str = ""
    self_hosted_verification_api_key: str = ""

    ai_request_timeout_seconds: int = 60
    ai_max_tokens: int = 2048

    # --- Цикл само-проверки Lunox AI (ТЗ раздел 15: "исправление",
    # "дополнительный AI-вызов"). Схема: основной инстанс отвечает -> если
    # verification включена, второй инстанс ТОЛЬКО указывает на ошибки (не
    # переписывает ответ целиком) -> основной сам вносит правки. Цикл
    # ограничен lunox_max_revision_attempts, чтобы не уйти в бесконечный
    # AI-repair-loop (тот же принцип, что и для автоисправления кода, ТЗ
    # раздел 28). Без self_hosted_verification_* — просто отключена.
    lunox_verification_enabled: bool = False
    lunox_max_revision_attempts: int = 2

    # --- AI-модерация промпта (доп. слой поверх regex-фильтра safety.py) ---
    # Regex в app/core/safety.py — грубый и быстрый первый рубеж, ловит
    # только точные формулировки на русском. Обойти его перефразировкой,
    # опечаткой или другим языком легко. Этот слой — второй, более гибкий:
    # отдельный AI-вызов классифицирует промпт ДО основной генерации.
    # Использует тот же self-hosted primary provider, что и основной чат
    # (отдельный provider не обязателен, в отличие от verification.py,
    # т.к. здесь модель не проверяет сама себя, а классифицирует вход) —
    # но требует lunox_ai_enabled=true, иначе класс не может выполнить
    # AI-вызов вообще и модерация тихо пропускается (см. честное
    # ограничение в app/core/ai_moderation.py).
    ai_moderation_enabled: bool = False

    # --- Веб-доступ Lunox AI: НЕ реализован для self-hosted моделей в этом
    # проходе — это отдельная фича (нужна интеграция с поисковым API,
    # такая же по сути внешняя зависимость, которую владелец решил
    # убрать для LLM-провайдеров; решение по поисковому API — отдельно).
    lunox_web_search_enabled: bool = True  # чат теперь ходит в веб по умолчанию, без явного флага в запросе

    # --- Память Lunox AI (закрывает пробел из аудита: "модель не помнит
    # пользователя"). Без embeddings/векторного поиска — см. app/core/ai/memory.py.
    #
    # ВАЖНО: два РАЗНЫХ понятия, не путать:
    # - lunox_memory_short_term_messages — сколько последних сообщений
    #   ФАКТИЧЕСКИ подгружается в контекст модели на один запрос. Ограничено
    #   физическим лимитом контекстного окна LLM (обычно 8k-128k токенов
    #   в зависимости от модели) — весь объём хранения (см. ниже, гигабайты)
    #   ни при каких условиях не влезет в один запрос к модели целиком.
    # - MEMORY_STORAGE_LIMIT_MB (ниже, по тарифам, единица "Война и мир") — сколько истории вообще
    #   ХРАНИТСЯ на диске/в БД и никогда не удаляется без явного действия
    #   пользователя. Это гарантия "ничего не потеряется", а не гарантия
    #   "модель помнит всё одновременно" — технически это разные вещи. ---
    lunox_memory_short_term_messages: int = 20  # сколько последних сообщений диалога подгружать как контекст

    # --- Версия приложения / система обновлений (ТЗ раздел 9: доступно
    # только Developer/Admin через доверенную консоль, не публичный API) ---
    app_version: str = "0.1.0-demo"
    # TODO/CONFIG: нет источника фида обновлений (registry/CDN/git tags API)
    # — по умолчанию равно app_version, т.е. "апдейтов нет", пока владелец
    # не настроит реальный источник последней версии.
    latest_available_version: str = "0.1.0-demo"
    update_confirmation_token_expire_minutes: int = 30

    # --- Генерация проектов + автоисправление (ТЗ раздел 27-29) ---
    project_gen_max_fix_attempts: int = 3  # лимит цикла generate->validate->fix, защита от бесконечного repair-loop
    project_gen_workspace_dir: str = "./storage/project_workspaces"  # временная рабочая директория на время генерации
    project_gen_timeout_seconds: int = 120  # таймаут одной попытки validate (compileall/pytest подпроцесса)

    # --- APK-сборка (интерфейс — не работает без Android SDK/Gradle) ---
    apk_build_enabled: bool = False  # TODO/CONFIG: включить, когда Android SDK/Gradle установлены на сервере
    android_sdk_root: str = ""  # ANDROID_SDK_ROOT для gradlew
    java_home: str = ""  # JAVA_HOME для gradlew (нужен явно — минимальное env-окружение сборки его не наследует)
    apk_build_timeout_seconds: int = 600

    # --- Консоль обновления Lunox AI (Developer Console, только Primary
    # Developer) — сбор/обучение/деплой LoRA-адаптера через очередь, тот
    # же паттерн, что и APK-сборка выше: интерфейс есть всегда, реальное
    # исполнение — только когда на сервере физически стоит GPU/torch/peft
    # (training/requirements.txt) и training_pipeline_enabled=True. ---
    training_pipeline_enabled: bool = False  # TODO/CONFIG: включить, когда GPU-сервер с training/requirements.txt готов
    training_pipeline_timeout_seconds: int = 21600  # 6 часов — LoRA-обучение может идти долго на большом датасете
    training_workspace_dir: str = "./storage/training_runs"  # рабочая директория на время прогона (raw/dataset/adapter/merged)
    # Автоматический деплой (без ручного SSH-рестарта инференс-сервера)
    # РАБОТАЕТ ТОЛЬКО если self_hosted_base_url — это vLLM с включённым
    # рантайм-обновлением LoRA (сервер запущен с
    # VLLM_ALLOW_RUNTIME_LORA_UPDATING=True), которое даёт эндпоинты
    # /v1/load_lora_adapter и /v1/unload_lora_adapter без рестарта
    # процесса. Ollama/TGI и обычный vLLM без этого флага такого не умеют
    # — тогда деплой всегда ручной, и это не баг, а честное ограничение
    # конкретного инференс-сервера, не решаемое кодом бэкенда.
    self_hosted_supports_dynamic_lora: bool = False  # TODO/CONFIG: True только если реально настроено на сервере

    # --- Файлы ---
    max_file_size_mb: int = 50

    # --- Биометрия (TZ: liveness-challenge с лимитом попыток) ---
    biometry_challenge_expire_minutes: int = 5
    biometry_max_failed_attempts: int = 5
    biometry_lockout_minutes: int = 30  # эскалация на пароль на этот срок после 5 провалов

    # --- Голос: STT/TTS (self-hosted, тот же принцип, что и SelfHostedProvider
    # для текста — никаких платных внешних API). Формат endpoint'ов —
    # OpenAI-совместимый (/v1/audio/transcriptions, /v1/audio/speech) —
    # это распространённый target совместимости для self-hosted Whisper/TTS
    # серверов (например whisper-asr-webservice, faster-whisper-server),
    # но НЕ гарантия, что именно ваш конкретный сервер реализует его
    # 1-в-1 — сверьте с документацией вашего инференс-сервера. ---
    voice_enabled: bool = False
    self_hosted_stt_base_url: str = ""
    self_hosted_stt_model_name: str = "whisper-1"
    self_hosted_tts_base_url: str = ""
    self_hosted_tts_model_name: str = "tts-1"
    self_hosted_tts_voice: str = "default"
    self_hosted_voice_api_key: str = ""

    # --- Изображения: генерация (self-hosted, тот же принцип). Формат —
    # OpenAI-совместимый /v1/images/generations (Stable Diffusion WebUI с
    # OpenAI-compat расширением, ComfyUI за прокси-адаптером и т.п. — сверьте
    # с документацией конкретного вашего инференс-сервера). ---
    image_generation_enabled: bool = False
    self_hosted_image_base_url: str = ""
    self_hosted_image_model_name: str = ""
    self_hosted_image_api_key: str = ""

    video_generation_enabled: bool = False
    self_hosted_video_base_url: str = ""
    self_hosted_video_model_name: str = ""
    self_hosted_video_api_key: str = ""

    # TODO/CONFIG: включить, когда поднят SearXNG (searxng_base_url реально
    # отвечает) — по умолчанию False, как и остальные внешние интеграции,
    # иначе search_web() пытается достучаться до localhost:8080 "из коробки"
    # и падает ConnectError вместо честного "не настроено".
    web_search_enabled: bool = False
    searxng_base_url: str = "http://localhost:8080"
    web_search_max_results: int = 5
    web_search_timeout_seconds: int = 10

    music_generation_enabled: bool = False
    self_hosted_music_base_url: str = ""
    self_hosted_music_model_name: str = ""
    self_hosted_music_api_key: str = ""

    voice_profile_expire_minutes: int = 60

    file_storage_dir: str = "./storage/files"
    # Расширения без точки, в нижнем регистре. Не покрывает magic-byte
    # проверку содержимого (потребует python-magic — не подключен, честно
    # отмечаем как ограничение) — проверяется только расширение и
    # Content-Type, заявленный клиентом.
    allowed_file_extensions: str = "txt,md,pdf,png,jpg,jpeg,gif,webp,zip,json,csv,py,js,ts,html,css"

    # --- Rate limiting (ТЗ раздел 41: значения НЕ утверждены владельцем,
    # это ТЕХНИЧЕСКИЕ дефолты-заглушки, а не согласованное бизнес-решение —
    # поменяйте под реальную политику до продакшена) ---
    rate_limit_enabled: bool = True
    rate_limit_login_per_minute: int = 10
    rate_limit_register_per_minute: int = 5
    rate_limit_forgot_password_per_minute: int = 5
    rate_limit_verify_email_per_minute: int = 10
    rate_limit_reset_password_per_minute: int = 10

    # --- Security-репорты в Консоль разработчика (app/core/security_events.py)
    # тоже технические дефолты-заглушки, не согласованная политика ---
    security_login_failure_threshold: int = 5
    security_login_failure_window_minutes: int = 15
    security_event_ttl_days: int = 30
    security_rate_limit_abuse_threshold: int = 3
    security_rate_limit_abuse_window_minutes: int = 60
    security_token_burn_threshold_percent: int = 50
    security_token_burn_window_minutes: int = 10
    security_notify_email_enabled: bool = True

    # --- Реакция на угрозы: автодействия по HIGH-событиям (не только отчёт) ---
    # Технические дефолты-заглушки, требуют согласования как и остальные
    # security_*/rate_limit_* выше.
    security_auto_action_window_minutes: int = 15
    security_auto_ban_high_threshold: int = 3  # N HIGH-событий подряд по одному email -> временный бан
    security_auto_ban_duration_minutes: int = 60
    security_auto_block_ip_high_threshold: int = 3  # N HIGH-событий подряд по одному IP -> автоблок IP
    security_auto_block_ip_duration_minutes: int = 60

    # --- Чёрный список IP (app/core/ip_blocklist.py) ---
    ip_blocklist_enabled: bool = True
    ip_blocklist_cache_ttl_seconds: int = 30

    # --- Telegram-уведомления (app/core/telegram.py) ---
    telegram_bot_token: str | None = None
    security_notify_telegram_enabled: bool = True

    # --- Гео-IP в отчётах (app/core/geoip.py) ---
    geoip_enabled: bool = True

    # --- Доп. детекторы (app/core/security_events.py) ---
    security_mass_registration_threshold: int = 5  # N регистраций с одного IP
    security_mass_registration_window_minutes: int = 60
    security_payment_failure_threshold: int = 3  # N payment-failed подряд у одного юзера
    security_payment_failure_window_minutes: int = 60

    # --- 2FA/TOTP для Developer Console (app/core/totp.py) ---
    totp_issuer_name: str = "LunaX AI Console"
    totp_required_for_console: bool = False  # если True — /2fa/setup обязателен всем developer/admin

    # --- Push-уведомления (app/core/push.py, FCM HTTP v1 — Android + iOS/APNs relay) ---
    push_notify_enabled: bool = True
    fcm_project_id: str | None = None
    # Полный JSON service account (Firebase Console -> Project settings ->
    # Service accounts -> Generate new private key), как строка в .env.
    fcm_service_account_json: str | None = None

    # --- Marketplace ---
    # Marketplace убран (решение владельца). Задел на будущее — плата
    # за скачивание готовых проектов/аддонов, TODO/CONFIG, не активно.
    marketplace_commission_percent: int = 15
    marketplace_min_price_tenge: int = 500
    marketplace_max_price_tenge: int = 10_000


ROLE_RATE_LIMITS = {
    "user": 20,
    "premium": 60,
    "developer": 200,
    "primary_developer": 1000,
    "admin": 1000,
}

# --- Токен-квоты по тарифам (окончательная схема, согласована с владельцем) ---
# Правило цены: цена (тенге) = токены (млн) * 1000, КРОМЕ free (исключение — 0).
# ВСЕ функции (текст, изображения, видео, генерация файлов/проектов)
# расходуют этот ЕДИНЫЙ баланс. Отдельных лимитов на фото/видео/демонстрацию
# экрана/сайт больше НЕТ — они удалены по прямому указанию владельца.
TOKEN_LIMITS = {
    "free": 5_000_000,
    "pro": 10_000_000,
    "pro_plus": 15_000_000,
    "ultra": 20_000_000,
    "ultra_plus": 25_000_000,
}

TIER_PRICE_TENGE = {
    "free": 0,  # исключение из общего правила цена=токены
    "pro": 10_000,
    "pro_plus": 15_000,
    "ultra": 20_000,
    "ultra_plus": 25_000,
}

# Developer/Primary Developer — не тариф подписки, отдельный продуктовый лимит.
# 50 млрд токенов ≠ доступ к серверу (см. app/modules/auth/dependencies.py).
DEVELOPER_TOKEN_LIMIT = 50_000_000_000

# --- Квота хранения памяти по тарифам (согласовано с владельцем в чате) ---
# Единица бизнес-решения — количество полных текстов романа "Война и мир"
# (кириллица, UTF-8, ~3,1 млн символов ≈ WAR_AND_PEACE_MB на один экземпляр).
# Итоговые МБ вычисляются от этой единицы, а не хардкодятся — если решите
# скорректировать масштаб позже, меняется одно число WAR_AND_PEACE_MB.
#
# Раскладка: Free=3, Pro=6, Pro Plus=9, Ultra=12, Ultra Plus=15 (шаг +3).
#
# Это ХРАНЕНИЕ истории переписки + долговременных фактов — не путать с
# TOKEN_LIMITS выше (расход на генерацию) и не путать с "сколько сообщений
# видит модель за раз" (см. lunox_memory_short_term_messages в Settings).
WAR_AND_PEACE_MB = 6.4  # округлённая оценка объёма полного текста романа

MEMORY_STORAGE_LIMIT_WAR_AND_PEACE_UNITS = {
    "free": 3,
    "pro": 6,
    "pro_plus": 9,
    "ultra": 12,
    "ultra_plus": 15,
}
MEMORY_STORAGE_LIMIT_MB = {
    tier: units * WAR_AND_PEACE_MB for tier, units in MEMORY_STORAGE_LIMIT_WAR_AND_PEACE_UNITS.items()
}
MEGABYTE = 1024 * 1024
GIGABYTE = 1024 * 1024 * 1024

# Developer/Primary Developer — отдельный, больший лимит хранения (10 ГБ,
# не по шкале "Война и мир" — решено отдельно), тем же принципом, что и
# DEVELOPER_TOKEN_LIMIT: не тариф подписки, а роль.
DEVELOPER_MEMORY_STORAGE_LIMIT_GB = 10

# --- Механизм восстановления (окончательная схема) ---
#
# 1) Обычный случай (остатка достаточно для нормальной работы): пользователь
#    просто продолжает пользоваться остатком. Полный лимит возвращается
#    БЕЗУСЛОВНО в 00:00 каждый календарный день — независимо от того,
#    сколько токенов осталось.
#
# 2) Критический случай: если после списания остаток становится меньше
#    CRITICAL_BALANCE_THRESHOLD_TOKENS (т.е. недостаточно для одного
#    полноценного действия/генерации файла), запускается ИНДИВИДУАЛЬНЫЙ
#    таймер восстановления с момента этого критического списания (а не с
#    момента последнего обычного запроса). По истечении таймера лимит
#    возвращается к полному значению тарифа — раньше полуночи, если
#    критический момент наступил не в конце дня.
#
# ПРИМЕЧАНИЕ (честно, это допущение): в постановке не указано точное число
# токенов, ниже которого остаток считается "недостаточным для одного
# полноценного действия" — стоимость одного AI-запроса в токенах ещё не
# определена бизнес-логикой (AI-цепочка не реализована). Принято то же
# значение, что использовалось ранее для похожего порога — 100_000.
# Уточните и замените при появлении реальной стоимости действия.
CRITICAL_BALANCE_THRESHOLD_TOKENS = 100_000

# Длительность индивидуального таймера критического восстановления (минуты),
# по тарифу. Developer/Primary Developer не участвует — роль трактуется как
# unlimited, критический таймер для неё не запускается.
CRITICAL_RECOVERY_MINUTES = {
    "free": 4 * 60,
    "pro": 3 * 60,
    "pro_plus": 3 * 60,
    "ultra": 2 * 60,
    "ultra_plus": 2 * 60,
}

# Порог для предупреждения "критически мало токенов" — доля от лимита тарифа.
LOW_BALANCE_WARNING_PERCENT = 5

# Real Life video — это ГЕЙТ ДОСТУПА к функции по тарифу (только
# Ultra/Ultra Plus), а НЕ отдельная числовая квота токенов. Сама функция,
# если включена в проект, расходует общий токен-баланс, как и всё
# остальное. Отдельных часовых лимитов на видео больше нет (убраны).
REAL_LIFE_VIDEO_ROLES = {"ultra", "ultra_plus"}

# --- Токенные коэффициенты (CONTINUATION SPECIFICATION / финальное ТЗ Lunox AI) ---
# Утверждённые бизнес-коэффициенты списания — НЕ утверждение о реальном
# токенизаторе внешнего LLM-провайдера (OpenAI/Anthropic/etc), а именно
# внутренняя экономика Lunox AI.
TOKEN_COST_TEXT_MESSAGE = 0.9        # C1 — обычное текстовое сообщение + агентская обработка
TOKEN_COST_IMAGE = 1.6               # C2 — генерация одного изображения
TOKEN_COST_VIDEO_PER_SECOND = 16     # C3 — генерация видео, за 1 секунду
TOKEN_COST_CODE_GENERATION = 2       # C4 — генерация кода (сообщение + кодовая нагрузка)
TOKEN_COST_FILE_PER_MB = 5           # C5 — обычный файл/TXT, за 1 МБ

# Множитель для архивов/тяжёлых форматов (ZIP и т.п.) поверх
# TOKEN_COST_FILE_PER_MB — точное значение НЕ определено владельцем
# (раздел 9 финального ТЗ: "должны иметь отдельный коэффициент... чтобы
# стоимость могла зависеть от размера и сложности"). Дефолт 1.0
# (=не отличается от обычного файла) — TODO/CONFIG, замените, когда
# будет утверждено бизнес-значение.
TOKEN_COST_ARCHIVE_MULTIPLIER = 1.0

# Стоимость AI-агентской обработки за 1 сообщение при генерации проекта
# (крупные проекты/APK) — точная формула учёта "объёма кода/сложности/
# типа проекта" НЕ определена владельцем (раздел 8). TODO/CONFIG: сейчас
# используется TOKEN_COST_CODE_GENERATION как есть, без множителей на
# объём — минимально соответствует ТЗ, но не более того.


@lru_cache
def get_settings() -> Settings:
    return Settings()
