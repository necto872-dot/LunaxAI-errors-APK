"""
LunaX AI — точка входа приложения.

Все API-роутеры смонтированы под префиксом /api/v1 в соответствии
с LunaX_AI_TZ.txt (например POST /api/v1/auth/register).

ВНИМАНИЕ: init_models() (create_all) используется только для локальной
разработки на SQLite. В production схема БД должна управляться
исключительно через Alembic-миграции (см. alembic/), не через create_all.
"""
from contextlib import asynccontextmanager
import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.config.settings import get_settings
from app.core.ip_blocklist import IPBlocklistMiddleware
from app.core.logger import get_logger
from app.database import init_models
from app.modules.apk_build.routers import router as apk_build_router
from app.modules.auth.routers import router as auth_router
from app.modules.developer_panel.routers import router as developer_router
from app.modules.files.routers import router as files_router
from app.modules.media.routers import router as media_router
from app.modules.payments.routers import router as payments_router
from app.modules.projects.routers import router as projects_router
from app.modules.queue_cache.routers import queue_router
from app.modules.queue_cache.routers import router as biometry_router
from app.modules.search.routers import memory_router
from app.modules.search.routers import router as search_router
from app.modules.tokens.routers import router as tokens_router
from app.modules.updates.routers import router as updates_router
from app.modules.voice.routers import router as voice_router

logger = get_logger("main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Запуск LunaX AI backend...")
    settings = get_settings()
    if settings.env == "development":
        # Только для разработки. В production — Alembic (alembic upgrade head).
        await init_models()
    yield
    logger.info("Остановка LunaX AI backend.")


settings_instance = get_settings()

app = FastAPI(
    title="LunaX AI",
    description="Расширяемая AI-платформа: аккаунты, Developer/Primary Developer система, "
    "файлы, изображения, генерация проектов и клиентская экосистема.",
    version=get_settings().app_version,
    lifespan=lifespan,
)

app.mount("/static", StaticFiles(directory="app/static"), name="static")
if os.path.isdir("client"):
    app.mount("/client", StaticFiles(directory="client", html=True), name="client")
else:
    logger.warning("Папки 'client' нет рядом с сервером — веб-версия /client не раздаётся (это ок, если тут только бэкенд).")

app.add_middleware(IPBlocklistMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings_instance.cors_allowed_origins.split(",") if settings_instance.cors_allowed_origins else [],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    return FileResponse("app/static/logo.png")

API_PREFIX = "/api/v1"

app.include_router(auth_router, prefix=API_PREFIX)
app.include_router(developer_router, prefix=API_PREFIX)
app.include_router(search_router, prefix=API_PREFIX)
app.include_router(memory_router, prefix=API_PREFIX)
app.include_router(files_router, prefix=API_PREFIX)
app.include_router(media_router, prefix=API_PREFIX)
app.include_router(payments_router, prefix=API_PREFIX)
app.include_router(projects_router, prefix=API_PREFIX)
app.include_router(apk_build_router, prefix=API_PREFIX)
app.include_router(biometry_router, prefix=API_PREFIX)
app.include_router(queue_router, prefix=API_PREFIX)
app.include_router(updates_router, prefix=API_PREFIX)
app.include_router(voice_router, prefix=API_PREFIX)
app.include_router(tokens_router, prefix=API_PREFIX)


@app.get("/")
async def root():
    return {"name": "LunaX AI", "version": "0.1.0-demo", "status": "ok"}


@app.get("/health")
async def health():
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host=settings_instance.run_host, port=settings_instance.run_port)
