from datetime import datetime

from pydantic import BaseModel

from app.database.models import ProjectStatus


class ProjectGenerateRequest(BaseModel):
    name: str
    prompt: str


class ProjectOut(BaseModel):
    id: str
    name: str
    prompt: str
    status: ProjectStatus
    current_version: int
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class ProjectVersionOut(BaseModel):
    id: str
    version_number: int
    validation_passed: bool
    artifact_path: str | None
    created_at: datetime

    model_config = {"from_attributes": True}
