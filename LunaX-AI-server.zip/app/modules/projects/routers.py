"""
Генерация проектов (закрывает крупный пробел из аудита — ТЗ раздел 27-28).

/projects/generate ставит генерацию (весь цикл generate->validate->fix,
до project_gen_max_fix_attempts попыток) в приоритетную очередь
пользователя (ТЗ п.9, app/core/queue.py) и сразу возвращает Project со
статусом "generating", не дожидаясь AI/валидации внутри HTTP-запроса.
Прогресс отслеживается опросом GET /projects/{project_id} — status
меняется generating -> ready/failed, аналогично GET /apk/build/{job_id}.
"""
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.projects.generator import (
    ProjectGenerationError,
    delete_project,
    enqueue_project_generation,
    get_owned_project_or_404,
    list_project_versions,
    list_user_projects,
)
from app.database import get_db
from app.database.models import User
from app.modules.auth.dependencies import get_current_user
from app.modules.projects.schemas import ProjectGenerateRequest, ProjectOut, ProjectVersionOut

router = APIRouter(prefix="/projects", tags=["Генерация проектов"])
settings = get_settings()


def _raise(err: ProjectGenerationError):
    raise HTTPException(status_code=err.status_code, detail=err.message)


@router.post("/generate", response_model=ProjectOut, status_code=202)
async def generate(
    data: ProjectGenerateRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        return await enqueue_project_generation(db, user, data.name, data.prompt)
    except ProjectGenerationError as e:
        _raise(e)


@router.get("", response_model=list[ProjectOut])
async def list_projects(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await list_user_projects(db, user)


@router.get("/{project_id}", response_model=ProjectOut)
async def get_project(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        return await get_owned_project_or_404(db, user, project_id)
    except ProjectGenerationError as e:
        _raise(e)


@router.get("/{project_id}/versions", response_model=list[ProjectVersionOut])
async def get_versions(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        return await list_project_versions(db, user, project_id)
    except ProjectGenerationError as e:
        _raise(e)


@router.get("/{project_id}/versions/{version_id}/download")
async def download_version(
    project_id: str,
    version_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    versions = await list_project_versions(db, user, project_id)
    version = next((v for v in versions if v.id == version_id), None)
    if version is None or not version.artifact_path:
        raise HTTPException(status_code=404, detail="Артефакт не найден")

    artifact_path = Path(settings.file_storage_dir) / version.artifact_path
    if not artifact_path.exists():
        raise HTTPException(status_code=404, detail="Файл артефакта не найден на диске")

    return FileResponse(
        path=artifact_path,
        filename=f"project_v{version.version_number}.zip",
        media_type="application/zip",
    )


@router.delete("/{project_id}")
async def remove_project(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        await delete_project(db, user, project_id)
    except ProjectGenerationError as e:
        _raise(e)
    return {"status": "deleted", "project_id": project_id}
