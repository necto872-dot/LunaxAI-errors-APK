from pydantic import BaseModel


class UpdateCheckResponse(BaseModel):
    update_available: bool
    current_version: str
    latest_version: str
    confirmation_token: str | None = None
    expires_in_minutes: int | None = None


class ApplyUpdateRequest(BaseModel):
    confirmation_token: str


class ApplyUpdateResponse(BaseModel):
    status: str
    target_version: str
    instructions: str
