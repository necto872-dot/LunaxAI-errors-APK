"""
Система обновлений (закрывает заглушку из аудита). Доступно только
Developer/Primary Developer/Admin — см. app/core/updates.py для полного
объяснения архитектуры (проверка -> confirmation token -> локальный
CLI-деплой, публичный HTTP никогда сам не переписывает код процесса).
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.updates import UpdatesError, apply_update, check_for_update
from app.database import get_db
from app.database.models import User
from app.modules.auth.dependencies import require_developer
from app.modules.updates.schemas import (
    ApplyUpdateRequest,
    ApplyUpdateResponse,
    UpdateCheckResponse,
)

router = APIRouter(prefix="/updates", tags=["Обновления"])


def _raise(err: UpdatesError):
    raise HTTPException(status_code=err.status_code, detail=err.message)


@router.post("/check", response_model=UpdateCheckResponse)
async def check_updates(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(require_developer),
):
    return await check_for_update(db, user)


@router.post("/apply", response_model=ApplyUpdateResponse)
async def apply_updates(
    data: ApplyUpdateRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(require_developer),
):
    try:
        return await apply_update(db, user, data.confirmation_token)
    except UpdatesError as e:
        _raise(e)
