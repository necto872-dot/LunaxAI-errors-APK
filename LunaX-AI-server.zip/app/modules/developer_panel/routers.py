"""
Developer Console API (LunaX_AI_TZ.txt раздел 10, 14, 19).

- Просмотр/создание/изменение/отзыв вторичных Developer доступны
  только Primary Developer (require_primary_developer).
- Primary Developer нельзя изменить/удалить через эти endpoints
  (forbid_primary_developer_target -> 403 "Cannot modify primary developer"),
  в том числе если Primary попытается сделать это сам с собой.
- Обычный Developer видит только собственный статус в /developer/me,
  но не получает доступ к управлению другими разработчиками.
"""
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.audit import record_audit_event
from app.core.console_commands import ConsoleCommandError, execute_command
from app.core.totp import generate_secret, provisioning_uri, verify_code
from app.core.training.pipeline import TrainingPipelineError, attempt_automatic_deploy, enqueue_training_run
from app.database import get_db
from app.database.models import TrainingRunStatus, User
from app.modules.auth.dependencies import (
    forbid_primary_developer_target,
    get_current_user,
    require_developer,
    require_primary_developer,
)
from app.modules.auth.services import AuthError
from app.modules.developer_panel.schemas import (
    ConsoleCommandRequest,
    ConsoleCommandResult,
    ConsoleHistoryEntry,
    DeveloperCreate,
    DeveloperOut,
    DeveloperUpdate,
    PushTokenIn,
    SecurityDashboardOut,
    SecurityEventOut,
    TOTPSetupOut,
    TOTPVerifyIn,
    TrainingRunCreate,
    TrainingRunOut,
    TrainingRunReview,
)
from app.modules.developer_panel.services import (
    create_developer,
    dashboard_security_events,
    get_developer_or_404,
    get_security_event_or_404,
    get_training_run_or_404,
    list_console_command_history,
    list_developers,
    list_security_events,
    list_training_runs,
    mark_training_run_deployed,
    resolve_security_event,
    review_training_run,
    revoke_developer,
    update_developer,
)
from app.modules.payments.schemas import ManualPaymentOut, PaymentOut
from app.modules.payments.services import (
    PaymentError,
    confirm_manual_payment,
    get_payment_or_404,
    list_manual_payments,
    reject_manual_payment,
)

router = APIRouter(prefix="/developer", tags=["Developer Console"])


def _raise(err: AuthError):
    raise HTTPException(status_code=err.status_code, detail=err.message)


@router.get("/me", response_model=DeveloperOut)
async def my_developer_status(user: User = Depends(require_developer)):
    """Доступно Developer, Primary Developer и Admin — собственный статус."""
    return user


@router.get("/developers", response_model=list[DeveloperOut])
async def get_developers(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_primary_developer),
):
    return await list_developers(db)


@router.post("/developers", response_model=DeveloperOut, status_code=201)
async def add_developer(
    data: DeveloperCreate,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(require_primary_developer),
):
    try:
        developer = await create_developer(db, data.email, data.username, data.password)
    except AuthError as e:
        _raise(e)
    await record_audit_event(db, "developer_created", actor_id=actor.id, target_id=developer.id)
    return developer


@router.patch("/developers/{developer_id}", response_model=DeveloperOut)
async def patch_developer(
    developer_id: str,
    data: DeveloperUpdate,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(require_primary_developer),
):
    try:
        target = await get_developer_or_404(db, developer_id)
    except AuthError as e:
        _raise(e)
    forbid_primary_developer_target(target)

    updated = await update_developer(db, target, data.is_active, data.unlimited_usage)
    await record_audit_event(db, "developer_updated", actor_id=actor.id, target_id=updated.id)
    return updated


@router.delete("/developers/{developer_id}", response_model=DeveloperOut)
async def delete_developer(
    developer_id: str,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(require_primary_developer),
):
    try:
        target = await get_developer_or_404(db, developer_id)
    except AuthError as e:
        _raise(e)
    forbid_primary_developer_target(target)

    await revoke_developer(db, target)
    await record_audit_event(db, "developer_revoked", actor_id=actor.id, target_id=target.id)
    return target


# ---------------------------------------------------------------------------
# Прогоны автопайплайна дообучения (training/auto_pipeline.py).
#
# Пайплайн сам доводит прогон только до EVAL_PASSED/EVAL_NEEDS_REVIEW —
# всё дальше (approve/reject, а тем более "задеплоено") только руками
# Primary Developer и только через эти endpoints, каждый шаг пишется в
# audit_logs. См. TrainingRunStatus в app/database/models.py.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Консоль обновления (Developer Console -> "Обновление") — пишешь/скидываешь
# код или примеры, пайплайн сам собирает + обучает + проверяет, дальше
# решение всегда за Primary Developer. См. app/core/training/pipeline.py.
# ---------------------------------------------------------------------------


@router.post("/training-runs", response_model=TrainingRunOut, status_code=202)
async def start_training_run(
    data: TrainingRunCreate,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(require_primary_developer),
):
    """
    Запуск обучения из Консоли обновления. Единственная точка входа во
    весь пайплайн — ни у обычного пользователя, ни у самого Lunox AI нет
    доступа к этому эндпоинту (require_primary_developer). Возвращает
    задачу сразу же (202), сам прогон идёт в фоне через приоритетную
    очередь — прогресс смотри через GET /training-runs/{id}.
    """
    try:
        run = await enqueue_training_run(
            db,
            actor,
            tier=data.tier,
            max_conversations=data.max_conversations,
            epochs=data.epochs,
            submitted_examples=[ex.model_dump() for ex in data.submitted_examples] if data.submitted_examples else None,
        )
    except TrainingPipelineError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message) from e
    await record_audit_event(
        db, "training_run_started", actor_id=actor.id, target_id=run.id,
        tier=data.tier, submitted_examples_count=len(data.submitted_examples or []),
    )
    return run


@router.get("/training-runs", response_model=list[TrainingRunOut])
async def get_training_runs(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_primary_developer),
):
    return await list_training_runs(db)


@router.get("/training-runs/{run_id}", response_model=TrainingRunOut)
async def get_training_run(
    run_id: str,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_primary_developer),
):
    try:
        return await get_training_run_or_404(db, run_id)
    except AuthError as e:
        _raise(e)


@router.post("/training-runs/{run_id}/approve", response_model=TrainingRunOut)
async def approve_training_run(
    run_id: str,
    data: TrainingRunReview,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(require_primary_developer),
):
    """
    Одобрение кандидата. НЕ разворачивает модель само — это подтверждение,
    что Primary Developer посмотрел training/eval_report.json (особенно
    если статус был EVAL_NEEDS_REVIEW) и принимает решение сознательно.
    Реальную выкладку на инференс-сервер отмечает отдельно
    POST /training-runs/{run_id}/deployed, уже после того как она
    произошла физически.
    """
    try:
        run = await get_training_run_or_404(db, run_id)
        updated = await review_training_run(db, run, actor, approve=True)
    except AuthError as e:
        _raise(e)
    await record_audit_event(
        db, "training_run_approved", actor_id=actor.id, target_id=run_id, note=data.note
    )
    return updated


@router.post("/training-runs/{run_id}/deploy")
async def deploy_training_run(
    run_id: str,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(require_primary_developer),
):
    """
    Попытка АВТОМАТИЧЕСКОГО деплоя — без ручного SSH/рестарта. Работает
    только если self_hosted_supports_dynamic_lora=True (self_hosted_base_url
    — это vLLM с рантайм-обновлением LoRA). Если сервер этого не умеет
    (Ollama/TGI/обычный vLLM) — вернёт честную 503, и тогда единственный
    путь — развернуть вручную и подтвердить через /training-runs/{id}/deployed.
    Вызывается ТОЛЬКО явной командой Primary Developer, никогда сама по
    себе после eval.
    """
    try:
        run = await get_training_run_or_404(db, run_id)
        if run.status != TrainingRunStatus.APPROVED:
            raise HTTPException(status_code=409, detail="Сначала нужно /approve этот прогон")
        deploy_result = await attempt_automatic_deploy(run)
        updated = await mark_training_run_deployed(db, run, actor)
    except AuthError as e:
        _raise(e)
    except TrainingPipelineError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message) from e
    await record_audit_event(
        db, "training_run_auto_deployed", actor_id=actor.id, target_id=run_id, **deploy_result
    )
    return {"training_run": TrainingRunOut.model_validate(updated), "deploy": deploy_result}


@router.post("/training-runs/{run_id}/reject", response_model=TrainingRunOut)
async def reject_training_run(
    run_id: str,
    data: TrainingRunReview,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(require_primary_developer),
):
    try:
        run = await get_training_run_or_404(db, run_id)
        updated = await review_training_run(db, run, actor, approve=False)
    except AuthError as e:
        _raise(e)
    await record_audit_event(
        db, "training_run_rejected", actor_id=actor.id, target_id=run_id, note=data.note
    )
    return updated


@router.post("/training-runs/{run_id}/deployed", response_model=TrainingRunOut)
async def confirm_training_run_deployed(
    run_id: str,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(require_primary_developer),
):
    """
    Вызывается ПОСЛЕ того, как Primary Developer сам вручную указал
    adapter_path этого прогона в инференс-сервере (vLLM/Ollama) и
    перезапустил его. Это запись факта в аудит-историю, а не действие,
    которое разворачивает модель за тебя.
    """
    try:
        run = await get_training_run_or_404(db, run_id)
        updated = await mark_training_run_deployed(db, run, actor)
    except AuthError as e:
        _raise(e)
    await record_audit_event(db, "training_run_deployed", actor_id=actor.id, target_id=run_id)
    return updated


# ---------------------------------------------------------------------------
# Отчёты о подозрительной активности ("Отчёты" в Консоли разработчика).
# Доступно любому Developer/Primary/Admin — это чтение сигналов, не
# управление правами.
# ---------------------------------------------------------------------------


@router.get("/security-events", response_model=list[SecurityEventOut])
async def get_security_events(
    only_unresolved: bool = True,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_developer),
):
    return await list_security_events(db, only_unresolved)


@router.post("/security-events/{event_id}/resolve", response_model=SecurityEventOut)
async def resolve_security_event_endpoint(
    event_id: str,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(require_developer),
):
    try:
        event = await get_security_event_or_404(db, event_id)
    except AuthError as e:
        _raise(e)
    updated = await resolve_security_event(db, event, actor)
    await record_audit_event(db, "security_event_resolved", actor_id=actor.id, target_id=event_id)
    return updated


# ---------------------------------------------------------------------------
# Слэш-команды: выдача привилегий/токенов/розыгрыш (app/core/console_commands.py).
# Только Primary Developer — это прямое изменение роли/баланса пользователя.
# ---------------------------------------------------------------------------


@router.post("/console/command", response_model=ConsoleCommandResult)
async def run_console_command(
    data: ConsoleCommandRequest,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(require_primary_developer),
):
    try:
        result = await execute_command(db, data.command, actor_id=actor.id)
    except ConsoleCommandError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message) from e
    await record_audit_event(db, "console_command_executed", actor_id=actor.id, command=data.command, result=result)
    return ConsoleCommandResult(result=result)


@router.get("/console/history", response_model=list[ConsoleHistoryEntry])
async def get_console_history(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_primary_developer),
):
    return await list_console_command_history(db)


# ---------------------------------------------------------------------------
# Экспорт истории команд консоли в CSV.
# ---------------------------------------------------------------------------


@router.get("/console/history/export")
async def export_console_history_csv(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_primary_developer),
):
    import csv
    import io

    rows = await list_console_command_history(db, limit=10_000)
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["id", "actor_id", "created_at", "details"])
    for r in rows:
        writer.writerow([r.id, r.actor_id, r.created_at.isoformat(), r.details])
    buf.seek(0)
    return StreamingResponse(
        iter([buf.getvalue()]), media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=console_history.csv"},
    )


# ---------------------------------------------------------------------------
# Дашборд: счётчики security_events за 24ч.
# ---------------------------------------------------------------------------


@router.get("/security-events/dashboard", response_model=SecurityDashboardOut)
async def get_security_dashboard(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_developer),
):
    return await dashboard_security_events(db)


# ---------------------------------------------------------------------------
# 2FA/TOTP для входа в Developer Console (app/core/totp.py). Self-service:
# каждый developer/admin включает/выключает 2FA только себе.
# ---------------------------------------------------------------------------


@router.post("/me/2fa/setup", response_model=TOTPSetupOut)
async def setup_totp(
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(get_current_user),
):
    """Генерирует новый secret (перезаписывает старый, если был) и
    возвращает otpauth:// URI для QR. totp_enabled остаётся False, пока
    /me/2fa/verify не подтвердит первый код."""
    secret = generate_secret()
    actor.totp_secret = secret
    actor.totp_enabled = False
    await db.commit()
    return TOTPSetupOut(secret=secret, otpauth_uri=provisioning_uri(secret, actor.email))


@router.post("/me/2fa/verify")
async def verify_totp(
    data: TOTPVerifyIn,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(get_current_user),
):
    if not actor.totp_secret or not verify_code(actor.totp_secret, data.code):
        raise HTTPException(status_code=400, detail="Неверный код")
    actor.totp_enabled = True
    await db.commit()
    await record_audit_event(db, "totp_enabled", actor_id=actor.id, target_id=actor.id)
    return {"totp_enabled": True}


@router.post("/me/2fa/disable")
async def disable_totp(
    # require_developer уже требует X-TOTP-Code если totp_enabled=True —
    # так что отключить 2FA без текущего кода нельзя.
    actor: User = Depends(require_developer),
    db: AsyncSession = Depends(get_db),
):
    actor.totp_enabled = False
    actor.totp_secret = None
    await db.commit()
    await record_audit_event(db, "totp_disabled", actor_id=actor.id, target_id=actor.id)
    return {"totp_enabled": False}


# ---------------------------------------------------------------------------
# Ручные платежи (без ИП — счёт самозанятого в Kaspi.kz, см. чат с
# владельцем): пользователь переводит по реквизитам из /payments/manual/
# requisites и жмёт "Я оплатил" (создаёт Payment pending). Тут Developer
# вручную сверяет перевод и подтверждает/отклоняет — только после этого
# тариф реально включается (payments/services.py:_activate_tariff).
# ---------------------------------------------------------------------------


@router.get("/payments/manual", response_model=list[ManualPaymentOut])
async def get_manual_payments(
    only_pending: bool = True,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_developer),
):
    rows = await list_manual_payments(db, only_pending)
    return [
        ManualPaymentOut(
            id=p.id, tariff=p.tariff, amount_kzt=p.amount_kzt,
            status=p.status, created_at=p.created_at, user_email=email,
        )
        for p, email in rows
    ]


@router.post("/payments/{payment_id}/confirm", response_model=PaymentOut)
async def confirm_payment(
    payment_id: str,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(require_developer),
):
    try:
        payment = await get_payment_or_404(db, payment_id)
        updated = await confirm_manual_payment(db, payment, actor)
    except PaymentError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message) from e
    await record_audit_event(
        db, "developer_confirmed_manual_payment", actor_id=actor.id, target_id=payment_id,
    )
    return updated


@router.post("/payments/{payment_id}/reject", response_model=PaymentOut)
async def reject_payment(
    payment_id: str,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(require_developer),
):
    try:
        payment = await get_payment_or_404(db, payment_id)
        updated = await reject_manual_payment(db, payment, actor)
    except PaymentError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message) from e
    await record_audit_event(
        db, "developer_rejected_manual_payment", actor_id=actor.id, target_id=payment_id,
    )
    return updated


# ---------------------------------------------------------------------------
# Push-токены мобильного клиента (app/core/push.py). Self-service, как 2FA.
# ---------------------------------------------------------------------------


@router.post("/me/push-token")
async def register_push_token(
    data: PushTokenIn,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(get_current_user),
):
    from sqlalchemy import select as sa_select

    from app.database.models import PushDevice, PushPlatform

    result = await db.execute(sa_select(PushDevice).where(PushDevice.fcm_token == data.fcm_token))
    row = result.scalar_one_or_none()
    if row is None:
        row = PushDevice(user_id=actor.id, fcm_token=data.fcm_token, platform=PushPlatform(data.platform))
        db.add(row)
    else:
        row.user_id = actor.id
        row.platform = PushPlatform(data.platform)
    await db.commit()
    return {"registered": True}


@router.delete("/me/push-token")
async def unregister_push_token(
    fcm_token: str,
    db: AsyncSession = Depends(get_db),
    actor: User = Depends(get_current_user),
):
    from sqlalchemy import delete as sa_delete

    from app.database.models import PushDevice

    await db.execute(
        sa_delete(PushDevice).where(PushDevice.fcm_token == fcm_token, PushDevice.user_id == actor.id)
    )
    await db.commit()
    return {"unregistered": True}
