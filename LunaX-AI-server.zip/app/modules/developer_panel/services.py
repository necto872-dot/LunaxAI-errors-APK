"""
Управление вторичными Developer-аккаунтами Primary Developer'ом
(LunaX_AI_TZ.txt раздел 10-13, 20-22).

Ограничения:
- новый Developer НЕ получает роль PRIMARY_DEVELOPER автоматически;
- количество Developer-аккаунтов не ограничивается искусственным
  маленьким лимитом — ограничение только техническими ресурсами;
- Primary Developer нельзя изменить/удалить через эти операции
  (проверяется в роутере через forbid_primary_developer_target).
"""
from datetime import UTC, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import DEVELOPER_TOKEN_LIMIT, get_settings
from app.core.security_events import expire_stale_events
from app.database.models import AuditLog, SecurityEvent, TrainingRun, TrainingRunStatus, User, UserRole
from app.modules.auth.services import (
    AuthError,
    get_user_by_email,
    get_user_by_username,
    hash_password,
)

settings = get_settings()


async def list_developers(db: AsyncSession) -> list[User]:
    result = await db.execute(
        select(User).where(User.role.in_([UserRole.DEVELOPER, UserRole.PRIMARY_DEVELOPER]))
    )
    return list(result.scalars().all())


async def create_developer(db: AsyncSession, email: str, username: str, password: str) -> User:
    if await get_user_by_email(db, email):
        raise AuthError("Пользователь с таким email уже существует", 409)
    if await get_user_by_username(db, username):
        raise AuthError("Имя пользователя уже занято", 409)

    user = User(
        email=email,
        username=username,
        hashed_password=hash_password(password),
        role=UserRole.DEVELOPER,
        is_active=True,
        email_verified=True,  # создаётся доверенным Primary — считается подтверждённым
        unlimited_usage=True,
        token_balance=DEVELOPER_TOKEN_LIMIT,
        token_limit=DEVELOPER_TOKEN_LIMIT,
        # Developer-аккаунт создаётся Primary Developer вручную, а не через
        # публичную самостоятельную регистрацию — возрастная проверка и
        # согласие с пользовательским соглашением здесь неприменимы тем же
        # образом (это внутренний доверенный аккаунт, не конечный
        # пользователь платформы). date_of_birth/terms_* заполняются
        # формально, чтобы не нарушать NOT NULL в модели User.
        date_of_birth=datetime.now(UTC).date(),
        terms_accepted_at=datetime.now(UTC),
        terms_version=settings.terms_version,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


async def get_developer_or_404(db: AsyncSession, developer_id: str) -> User:
    result = await db.execute(select(User).where(User.id == developer_id))
    user = result.scalar_one_or_none()
    if user is None:
        raise AuthError("Разработчик не найден", 404)
    return user


async def update_developer(db: AsyncSession, user: User, is_active: bool | None, unlimited_usage: bool | None) -> User:
    if is_active is not None:
        user.is_active = is_active
    if unlimited_usage is not None:
        user.unlimited_usage = unlimited_usage
    await db.commit()
    await db.refresh(user)
    return user


async def revoke_developer(db: AsyncSession, user: User) -> None:
    """Отзыв доступа: деактивация аккаунта. Роль сохраняется для истории."""
    user.is_active = False
    user.unlimited_usage = False
    await db.commit()


# ---------------------------------------------------------------------------
# Прогоны автопайплайна дообучения (training/auto_pipeline.py) — см.
# app/database/models.py:TrainingRun для того, почему это заканчивается
# EVAL_PASSED/EVAL_NEEDS_REVIEW, а не автоматическим DEPLOYED.
# ---------------------------------------------------------------------------


async def list_training_runs(db: AsyncSession) -> list[TrainingRun]:
    result = await db.execute(select(TrainingRun).order_by(TrainingRun.created_at.desc()))
    return list(result.scalars().all())


async def get_training_run_or_404(db: AsyncSession, run_id: str) -> TrainingRun:
    run = await db.get(TrainingRun, run_id)
    if run is None:
        raise AuthError("Прогон обучения не найден", 404)
    return run


async def review_training_run(
    db: AsyncSession, run: TrainingRun, reviewer: User, approve: bool
) -> TrainingRun:
    """
    Финальное решение человека по прогону. approve=True переводит статус в
    APPROVED — это подтверждение "я согласен с результатом", а не
    действие, которое само что-то разворачивает. Реальная выкладка —
    отдельно, через mark_training_run_deployed (ручное подтверждение) или
    attempt_automatic_deploy (см. app/core/training/pipeline.py, только
    если self_hosted_supports_dynamic_lora=True).
    """
    if run.status not in (TrainingRunStatus.EVAL_PASSED, TrainingRunStatus.EVAL_NEEDS_REVIEW):
        raise AuthError(
            f"Прогон в статусе '{run.status.value}' нельзя одобрить/отклонить — "
            "он ещё не дошёл до самопроверки или уже был обработан ранее",
            409,
        )

    run.status = TrainingRunStatus.APPROVED if approve else TrainingRunStatus.REJECTED
    run.reviewed_by_id = reviewer.id
    run.reviewed_at = datetime.now(UTC)
    await db.commit()
    await db.refresh(run)
    return run


async def mark_training_run_deployed(db: AsyncSession, run: TrainingRun, reviewer: User) -> TrainingRun:
    """
    Отдельный явный шаг ПОСЛЕ approve: Primary Developer подтверждает, что
    физически указал адаптер в SELF_HOSTED_MODEL_NAME и перезапустил
    инференс-сервер (либо это уже сделал attempt_automatic_deploy). Разделён
    с approve намеренно — "одобрено к выкладке" и "реально выложено в
    прод" не одно и то же событие.
    """
    if run.status != TrainingRunStatus.APPROVED:
        raise AuthError("Пометить как задеплоенный можно только уже одобренный (APPROVED) прогон", 409)

    run.status = TrainingRunStatus.DEPLOYED
    run.reviewed_by_id = reviewer.id
    run.reviewed_at = datetime.now(UTC)
    await db.commit()
    await db.refresh(run)
    return run


# ---------------------------------------------------------------------------
# Отчёты о подозрительной активности (app/core/security_events.py создаёт
# записи, тут только чтение и закрытие/resolve оператором).
# ---------------------------------------------------------------------------


async def list_security_events(db: AsyncSession, only_unresolved: bool = True) -> list[SecurityEvent]:
    await expire_stale_events(db)  # лениво закрывает протухшие открытые отчёты
    query = select(SecurityEvent).order_by(SecurityEvent.created_at.desc())
    if only_unresolved:
        query = query.where(SecurityEvent.resolved.is_(False))
    result = await db.execute(query)
    return list(result.scalars().all())


async def get_security_event_or_404(db: AsyncSession, event_id: str) -> SecurityEvent:
    event = await db.get(SecurityEvent, event_id)
    if event is None:
        raise AuthError("Отчёт не найден", 404)
    return event


async def resolve_security_event(db: AsyncSession, event: SecurityEvent, actor: User) -> SecurityEvent:
    event.resolved = True
    event.resolved_by_id = actor.id
    event.resolved_at = datetime.now(UTC)
    await db.commit()
    await db.refresh(event)
    return event


async def dashboard_security_events(db: AsyncSession) -> dict:
    """Агрегация security_events за 24ч: total + by_severity + by_event_type
    (простой agg-запрос, без отдельного view/scheduler)."""
    from collections import Counter

    from sqlalchemy import func as sa_func

    window_start = datetime.now(UTC) - timedelta(hours=24)
    result = await db.execute(
        select(SecurityEvent.severity, SecurityEvent.event_type).where(SecurityEvent.created_at >= window_start)
    )
    rows = result.all()
    by_severity = Counter(r[0].value for r in rows)
    by_event_type = Counter(r[1] for r in rows)
    return {
        "window_hours": 24,
        "total": len(rows),
        "by_severity": dict(by_severity),
        "by_event_type": dict(by_event_type),
    }


async def list_console_command_history(db: AsyncSession, limit: int = 100) -> list[AuditLog]:
    """История /priv, /tokens, /giveaway, /ban... — сами команды уже
    пишутся в audit_logs роутером (event=console_command_executed)."""
    result = await db.execute(
        select(AuditLog)
        .where(AuditLog.event == "console_command_executed")
        .order_by(AuditLog.created_at.desc())
        .limit(limit)
    )
    return list(result.scalars().all())
