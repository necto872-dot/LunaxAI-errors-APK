from datetime import datetime

from pydantic import BaseModel, EmailStr, Field

from app.database.models import SecurityEventSeverity, TrainingRunStatus, UserRole


class DeveloperCreate(BaseModel):
    email: EmailStr
    username: str = Field(min_length=3, max_length=64)
    password: str = Field(min_length=8, max_length=128)


class DeveloperUpdate(BaseModel):
    is_active: bool | None = None
    unlimited_usage: bool | None = None


class DeveloperOut(BaseModel):
    id: str
    email: EmailStr
    username: str
    role: UserRole
    is_active: bool
    email_verified: bool
    unlimited_usage: bool
    token_balance: int
    token_limit: int

    model_config = {"from_attributes": True}


class TrainingRunOut(BaseModel):
    """Один прогон training/auto_pipeline.py — для списка в Developer Console."""

    id: str
    status: TrainingRunStatus
    dataset_size: int
    adapter_path: str | None
    eval_summary: dict | None
    failure_reason: str | None
    log: str
    tier: str
    max_conversations: int
    epochs: int
    triggered_by_id: str | None
    submitted_examples: list | None
    queue_job_id: str | None
    reviewed_by_id: str | None
    reviewed_at: datetime | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class TrainingExample(BaseModel):
    """Одна пара, которую разработчик вручную присылает через Консоль обновления."""

    user: str = Field(min_length=1, max_length=20_000)
    assistant: str = Field(min_length=1, max_length=20_000)


class TrainingRunCreate(BaseModel):
    """
    POST /developer/training-runs — запуск Консоли обновления.

    submitted_examples — то, что разработчик сам написал/скинул (код,
    диалоги, что угодно в формате вопрос-ответ) специально для этого
    прогона. Это НЕ то же самое, что реальные диалоги пользователей
    (те собираются отдельно, только у кого allow_training_data_use=True)
    — оба источника объединяются в один датасет автоматически.
    """

    tier: str = "pro"
    max_conversations: int = Field(default=500, ge=0, le=100_000)
    epochs: int = Field(default=3, ge=1, le=50)
    submitted_examples: list[TrainingExample] | None = None


class TrainingRunReview(BaseModel):
    """Опциональный комментарий Primary Developer при approve/reject."""

    note: str | None = Field(default=None, max_length=2000)


# ---------------------------------------------------------------------------
# Отчёты о подозрительной активности (раздел "Отчёты" консоли).
# ---------------------------------------------------------------------------


class SecurityEventOut(BaseModel):
    id: str
    event_type: str
    severity: SecurityEventSeverity
    email: str | None
    ip_address: str | None
    details: dict | None
    resolved: bool
    resolved_by_id: str | None
    resolved_at: datetime | None
    created_at: datetime

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Слэш-команды консоли: выдача привилегий/токенов (app/core/console_commands.py).
# ---------------------------------------------------------------------------


class ConsoleCommandRequest(BaseModel):
    """Команды: /priv <email> <role>, /tokens <email> <amount>,
    /giveaway <amount> [role|all], /ban <email>, /unban <email>,
    /find <email>, /revoke-sessions <email>, /blockip <ip> [minutes],
    /unblockip <ip>. См. app/core/console_commands.py."""

    command: str = Field(min_length=1, max_length=500)


class ConsoleCommandResult(BaseModel):
    result: dict


class ConsoleHistoryEntry(BaseModel):
    id: str
    actor_id: str | None
    details: dict | None
    created_at: datetime

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Дашборд отчётов + 2FA консоли.
# ---------------------------------------------------------------------------


class SecurityDashboardOut(BaseModel):
    """Счётчики security_events за последние 24ч, сгруппированные по типу
    и severity — для агрегированного виджета в Консоли."""

    window_hours: int
    total: int
    by_severity: dict[str, int]
    by_event_type: dict[str, int]


class TOTPSetupOut(BaseModel):
    secret: str
    otpauth_uri: str


class TOTPVerifyIn(BaseModel):
    code: str = Field(min_length=6, max_length=8)


class PushTokenIn(BaseModel):
    fcm_token: str = Field(min_length=16, max_length=512)
    platform: str = Field(pattern="^(android|ios)$")
