"""
Файловый сервис LunaX AI (ТЗ раздел 25-28, 34-35).

Гарантии:
- ownership: файл всегда привязан к owner_id, доступ проверяется по нему,
  а не по одному лишь знанию id (см. get_owned_file_or_404);
- размер: ограничен settings.max_file_size_mb;
- расширение: сверяется со settings.allowed_file_extensions (allowlist);
- path traversal: физическое имя на диске — случайный UUID + безопасное
  расширение, оригинальное имя пользователя нигде не используется как
  путь на файловой системе;
- хранилище: локальная директория settings.file_storage_dir (для
  production подошло бы S3-совместимое хранилище — не подключено в этом
  проходе, см. README).

Magic-byte валидация: расширение и заявленный клиентом Content-Type — это
только подсказки, им нельзя доверять (клиент может переименовать .exe в
.png). save_uploaded_file() дополнительно проверяет реальные первые байты
содержимого через python-magic и сверяет определённый MIME-тип с
allowlist'ом расширений (см. _EXTENSION_TO_MIME_PREFIXES ниже). Текстовые
форматы (txt/md/json/csv/py/js/ts/html/css) не имеют устойчивой magic-byte
сигнатуры — для них magic-byte проверка пропускается осознанно (это не
дыра: они и так не исполняются сервером и ограничены allowlist'ом
расширений + лимитом размера).

Стоимость операции в токенах (C5, app.core.token_cost.estimate_file_cost)
считается и списывается атомарно ДО записи на диск — см.
save_uploaded_file() ниже.
"""
import asyncio
import os
import uuid
from pathlib import Path

import magic
from fastapi import UploadFile
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.token_cost import InsufficientTokensError, estimate_file_cost, reserve_and_spend
from app.database.models import UploadedFile, User

settings = get_settings()

# Расширение -> допустимые префиксы реального MIME-типа (по magic-bytes).
# Только для форматов с устойчивой бинарной сигнатурой. Расширения, которых
# здесь нет (txt/md/json/csv/py/js/ts/html/css), magic-byte проверку не
# проходят — см. docstring выше.
_EXTENSION_TO_MIME_PREFIXES: dict[str, tuple[str, ...]] = {
    "pdf": ("application/pdf",),
    "png": ("image/png",),
    "jpg": ("image/jpeg",),
    "jpeg": ("image/jpeg",),
    "gif": ("image/gif",),
    "webp": ("image/webp", "video/webp"),
    "zip": ("application/zip", "application/x-zip"),
}


class FileError(Exception):
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


def _verify_magic_bytes(contents: bytes, ext: str) -> None:
    expected_prefixes = _EXTENSION_TO_MIME_PREFIXES.get(ext)
    if expected_prefixes is None:
        return  # текстовый/скриптовый формат без устойчивой сигнатуры — пропускаем осознанно
    detected = magic.from_buffer(contents, mime=True)
    if not any(detected.startswith(prefix) for prefix in expected_prefixes):
        raise FileError(
            f"Содержимое файла не соответствует расширению .{ext} "
            f"(определён тип: {detected}). Возможна подмена типа файла.",
            415,
        )


def _allowed_extensions() -> set[str]:
    return {ext.strip().lower() for ext in settings.allowed_file_extensions.split(",") if ext.strip()}


def _storage_dir() -> Path:
    path = Path(settings.file_storage_dir)
    path.mkdir(parents=True, exist_ok=True)
    return path


def _safe_extension(original_filename: str) -> str:
    # Берём расширение из оригинального имени ТОЛЬКО для валидации/подсказки
    # типа, но никогда не используем оригинальное имя как реальный путь.
    ext = Path(original_filename).suffix.lstrip(".").lower()
    if not ext or ext not in _allowed_extensions():
        raise FileError(
            f"Недопустимое расширение файла. Разрешены: {', '.join(sorted(_allowed_extensions()))}",
            415,
        )
    return ext


async def save_uploaded_file(db: AsyncSession, user: User, file: UploadFile) -> UploadedFile:
    contents = await file.read()
    size_bytes = len(contents)
    max_bytes = settings.max_file_size_mb * 1024 * 1024

    if size_bytes == 0:
        raise FileError("Пустой файл", 400)
    if size_bytes > max_bytes:
        raise FileError(f"Файл превышает лимит {settings.max_file_size_mb} МБ", 413)

    ext = _safe_extension(file.filename or "")
    _verify_magic_bytes(contents, ext)

    # Стоимость по C5 (финальное ТЗ раздел 9) считается и списывается ДО
    # записи на диск — операция не должна стартовать, если токенов не хватит.
    size_mb = size_bytes / (1024 * 1024)
    cost = estimate_file_cost(size_mb, ext)
    try:
        await reserve_and_spend(db, user, cost)
    except InsufficientTokensError as e:
        raise FileError(str(e), 402) from e

    # Случайное имя на диске — исключает path traversal и коллизии.
    stored_filename = f"{uuid.uuid4().hex}.{ext}"
    dest_path = _storage_dir() / stored_filename

    # Доп. защита: убеждаемся, что итоговый путь не выходит за пределы
    # storage_dir (даже теоретически, при странном значении ext).
    resolved = dest_path.resolve()
    if _storage_dir().resolve() not in resolved.parents and resolved != _storage_dir().resolve():
        raise FileError("Недопустимый путь файла", 400)

    await asyncio.to_thread(dest_path.write_bytes, contents)

    record = UploadedFile(
        owner_id=user.id,
        original_filename=(file.filename or "unnamed")[:255],
        stored_filename=stored_filename,
        content_type=file.content_type or "application/octet-stream",
        size_bytes=size_bytes,

    )
    db.add(record)
    await db.commit()
    await db.refresh(record)
    return record


async def list_user_files(db: AsyncSession, user: User) -> list[UploadedFile]:
    result = await db.execute(
        select(UploadedFile).where(UploadedFile.owner_id == user.id).order_by(UploadedFile.created_at.desc())
    )
    return list(result.scalars().all())


async def get_owned_file_or_404(db: AsyncSession, user: User, file_id: str) -> UploadedFile:
    """
    Возвращает файл, ТОЛЬКО если он принадлежит user. Если файла нет
    ИЛИ он принадлежит другому пользователю — одинаковая ошибка 404
    (не 403), чтобы не подтверждать чужому пользователю сам факт
    существования file_id (ТЗ п.35: нельзя получить доступ, просто зная id).
    """
    result = await db.execute(select(UploadedFile).where(UploadedFile.id == file_id))
    record = result.scalar_one_or_none()
    if record is None or record.owner_id != user.id:
        raise FileError("Файл не найден", 404)
    return record


async def delete_owned_file(db: AsyncSession, user: User, file_id: str) -> None:
    record = await get_owned_file_or_404(db, user, file_id)
    disk_path = _storage_dir() / record.stored_filename
    if disk_path.exists():
        os.remove(disk_path)
    await db.delete(record)
    await db.commit()
