from datetime import datetime

from pydantic import BaseModel


class FileOut(BaseModel):
    id: str
    original_filename: str
    content_type: str
    size_bytes: int
    created_at: datetime

    model_config = {"from_attributes": True}


class FileAnalyzeRequest(BaseModel):
    prompt: str = "Опиши содержимое этого файла и выдели ключевые моменты."


class FileAnalyzeOut(BaseModel):
    file_id: str
    result: str
