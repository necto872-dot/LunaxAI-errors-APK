"""
Файлы (ТЗ раздел 25-28, 34-35): upload/list/download/delete с проверкой
ownership, размера, расширения; без path traversal.

Статус (сверено с реализацией, не аспирационный список):
- magic-byte валидация — реализована в app.modules.files.services
  (_verify_magic_bytes, через python-magic);
- списание токенов за загрузку — реализовано в app.modules.files.services
  (save_uploaded_file -> app.core.token_cost.estimate_file_cost +
  reserve_and_spend), коэффициент C5 — TODO/CONFIG (не блокирует работу,
  см. app/core/token_cost.py);
- AI-анализ содержимого файла (п.11) — реализован ниже (POST
  /files/{file_id}/analyze), через app.core.ai.lunox_router.lunox_analyze_file.
  Поддерживает изображения и UTF-8 текстовые файлы; для прочих бинарных
  форматов self-hosted модель без отдельного экстрактора честно отдаёт 415
  (см. LunoxFileAnalysisUnsupportedError) — конвертация PDF/DOCX в текст не
  реализована в этом проходе.
"""
from fastapi import APIRouter, Depends, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.ai.lunox_router import (
    LunoxAIUnavailableError,
    LunoxFileAnalysisUnsupportedError,
    lunox_analyze_file,
)
from app.core.token_cost import InsufficientTokensError, estimate_text_cost, reserve_and_spend
from app.database import get_db
from app.database.models import User
from app.modules.auth.dependencies import get_current_user
from app.modules.files.schemas import FileAnalyzeOut, FileAnalyzeRequest, FileOut
from app.modules.files.services import (
    FileError,
    delete_owned_file,
    get_owned_file_or_404,
    list_user_files,
    save_uploaded_file,
)

router = APIRouter(prefix="/files", tags=["Файлы"])
settings = get_settings()


def _raise(err: FileError):
    raise HTTPException(status_code=err.status_code, detail=err.message)


@router.post("/upload", response_model=FileOut, status_code=201)
async def upload_file(
    file: UploadFile,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        return await save_uploaded_file(db, user, file)
    except FileError as e:
        _raise(e)


@router.get("", response_model=list[FileOut])
async def list_files(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await list_user_files(db, user)


@router.get("/{file_id}")
async def download_file(
    file_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        record = await get_owned_file_or_404(db, user, file_id)
    except FileError as e:
        _raise(e)

    from pathlib import Path

    disk_path = Path(settings.file_storage_dir) / record.stored_filename
    if not disk_path.exists():
        raise HTTPException(status_code=404, detail="Файл не найден на диске")

    return FileResponse(
        path=disk_path,
        filename=record.original_filename,
        media_type=record.content_type,
    )


@router.post("/{file_id}/analyze", response_model=FileAnalyzeOut)
async def analyze_file(
    file_id: str,
    body: FileAnalyzeRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        record = await get_owned_file_or_404(db, user, file_id)
    except FileError as e:
        _raise(e)

    from pathlib import Path

    disk_path = Path(settings.file_storage_dir) / record.stored_filename
    if not disk_path.exists():
        raise HTTPException(status_code=404, detail="Файл не найден на диске")

    # Стоимость анализа списывается ДО обращения к AI (тот же принцип C1,
    # что и для обычного текстового сообщения — см. app.core.token_cost).
    try:
        await reserve_and_spend(db, user, estimate_text_cost())
    except InsufficientTokensError as e:
        raise HTTPException(status_code=402, detail=str(e)) from e

    file_bytes = disk_path.read_bytes()
    try:
        result = await lunox_analyze_file(file_bytes, record.original_filename, body.prompt)
    except LunoxFileAnalysisUnsupportedError as e:
        raise HTTPException(status_code=415, detail=str(e)) from e
    except LunoxAIUnavailableError as e:
        raise HTTPException(status_code=503, detail=str(e)) from e

    return FileAnalyzeOut(file_id=file_id, result=result)


@router.delete("/{file_id}")
async def delete_file(
    file_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        await delete_owned_file(db, user, file_id)
    except FileError as e:
        _raise(e)
    return {"status": "deleted", "file_id": file_id}
