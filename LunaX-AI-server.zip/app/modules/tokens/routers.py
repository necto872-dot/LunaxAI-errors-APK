"""
Токен-квота: статус баланса и списание (используется другими модулями —
AI chat/search/media — как внутренний сервис; здесь выставлен и как
прямой API для собственных нужд пользователя/отладки).

Cooldown-восстановление и полуночный сброс применяются лениво — при
обращении (см. app/core/quota.py про ограничение отсутствия scheduler).
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.quota import (
    InsufficientTokensError,
    quota_status,
    spend_tokens,
    sync_quota_state,
)
from app.database import get_db
from app.database.models import User
from app.modules.auth.dependencies import get_current_user
from app.modules.tokens.schemas import TokenSpendRequest, TokenSpendResult, TokenStatus

router = APIRouter(prefix="/tokens", tags=["Токен-квота"])


@router.get("/status", response_model=TokenStatus)
async def get_token_status(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    user = await sync_quota_state(db, user)
    return quota_status(user)


@router.post("/spend", response_model=TokenSpendResult)
async def spend_token_amount(
    data: TokenSpendRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """
    Ручное списание токенов — для отладки/административных сценариев.
    Реальный продуктовый чат уже подключён и списывает C1 автоматически
    через /api/v1/search/query (см. app.modules.search.routers +
    app.core.ai.lunox_router) — этот эндпоинт им не используется, он
    остаётся отдельным низкоуровневым доступом к движку квоты.
    """
    if data.amount <= 0:
        raise HTTPException(status_code=400, detail="amount должен быть положительным")
    try:
        return await spend_tokens(db, user, data.amount)
    except InsufficientTokensError as e:
        raise HTTPException(status_code=402, detail=e.message) from e
