from datetime import datetime

from pydantic import BaseModel


class TokenStatus(BaseModel):
    token_balance: int | None
    token_limit: int
    unlimited: bool
    critical_recovery_active: bool
    recovery_available_at: datetime | None
    next_daily_reset_at: datetime | None
    low_balance_warning: dict | None


class TokenSpendRequest(BaseModel):
    amount: int


class TokenSpendResult(BaseModel):
    spent: int
    token_balance: int | None
    token_limit: int
    unlimited: bool
    critical_recovery_active: bool
    recovery_available_at: datetime | None
    next_daily_reset_at: datetime | None
    low_balance_warning: dict | None
