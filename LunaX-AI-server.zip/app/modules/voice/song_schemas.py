from pydantic import BaseModel


class LyricsRequest(BaseModel):
    lyrics: str


class VoiceChoiceRequest(BaseModel):
    use_own_voice: bool


class ConsentRequest(BaseModel):
    consent: bool


class FinalizeSongRequest(BaseModel):
    genre: str
    mood: str


class SongSessionOut(BaseModel):
    id: str
    stage: str
    lyrics: str | None
    use_own_voice: bool | None

    model_config = {"from_attributes": True}
