"""
Голос: STT/TTS (закрывает заглушку из аудита: "❌ Whisper, ❌ Coqui TTS,
❌ реальное аудио"). Реальные HTTP-вызовы к self-hosted серверу — см.
app/core/voice/client.py.

ЧЕСТНО НЕ РЕШЕНО владельцем: точная стоимость голосовых операций в
токенах (за минуту STT / за 1000 символов TTS) НЕ утверждена — в
финальном ТЗ (коэффициенты C1-C5) голос не упоминается вообще. Не
выдумываю цену — эти эндпоинты пока НЕ списывают токены. Это сознательная
временная дыра в экономике (можно злоупотребить бесплатным голосом),
а не забытая недоделка — как только появится утверждённое значение,
здесь нужно добавить reserve_and_spend() по аналогии с /media/image/generate.
"""
from fastapi import APIRouter, Depends, HTTPException, Response, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.voice.client import (
    VoiceNotConfiguredError,
    VoiceRequestError,
    synthesize_speech,
    transcribe_audio,
)
from app.core.voice.song_flow import (
    SongFlowError,
    choose_voice,
    finalize_song,
    give_consent,
    set_lyrics,
    start_song_session,
    submit_voice_sample,
)
from app.database import get_db
from app.database.models import User
from app.modules.auth.dependencies import get_current_user
from app.modules.voice.schemas import STTResponse, TTSRequest
from app.modules.voice.song_schemas import (
    ConsentRequest,
    FinalizeSongRequest,
    LyricsRequest,
    SongSessionOut,
    VoiceChoiceRequest,
)

router = APIRouter(prefix="/voice", tags=["Голос и мультимодальность"])


def _raise(err: SongFlowError):
    raise HTTPException(status_code=err.status_code, detail=err.message)


@router.post("/stt", response_model=STTResponse)
async def speech_to_text(audio: UploadFile, user: User = Depends(get_current_user)):
    contents = await audio.read()
    try:
        text = await transcribe_audio(contents, audio.filename or "audio", audio.content_type or "")
    except (VoiceNotConfiguredError, VoiceRequestError) as e:
        raise HTTPException(status_code=503, detail=str(e)) from e
    return STTResponse(text=text)


@router.post("/tts")
async def text_to_speech(data: TTSRequest, user: User = Depends(get_current_user)):
    try:
        audio_bytes = await synthesize_speech(data.text)
    except (VoiceNotConfiguredError, VoiceRequestError) as e:
        raise HTTPException(status_code=503, detail=str(e)) from e
    return Response(content=audio_bytes, media_type="audio/mpeg")


@router.post("/song/start", response_model=SongSessionOut)
async def start_song(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    return await start_song_session(db, user)


@router.post("/song/{session_id}/lyrics", response_model=SongSessionOut)
async def song_lyrics(
    session_id: str,
    data: LyricsRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        return await set_lyrics(db, user, session_id, data.lyrics)
    except SongFlowError as e:
        _raise(e)


@router.post("/song/{session_id}/voice-choice", response_model=SongSessionOut)
async def song_voice_choice(
    session_id: str,
    data: VoiceChoiceRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        return await choose_voice(db, user, session_id, data.use_own_voice)
    except SongFlowError as e:
        _raise(e)


@router.post("/song/{session_id}/consent", response_model=SongSessionOut)
async def song_consent(
    session_id: str,
    data: ConsentRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        return await give_consent(db, user, session_id, data.consent)
    except SongFlowError as e:
        _raise(e)


@router.post("/song/{session_id}/sample", response_model=SongSessionOut)
async def song_sample(
    session_id: str,
    audio: UploadFile,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    contents = await audio.read()
    try:
        return await submit_voice_sample(db, user, session_id, contents)
    except SongFlowError as e:
        _raise(e)


@router.post("/song/{session_id}/finalize")
async def song_finalize(
    session_id: str,
    data: FinalizeSongRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        audio_bytes = await finalize_song(db, user, session_id, data.genre, data.mood)
    except SongFlowError as e:
        _raise(e)
    return Response(content=audio_bytes, media_type="audio/mpeg")
