from datetime import UTC, date, datetime

from pydantic import BaseModel, EmailStr, Field, field_validator

from app.config.settings import get_settings
from app.database.models import SubscriptionTier, UserRole

_settings = get_settings()


class UserRegister(BaseModel):
    email: EmailStr
    username: str = Field(min_length=3, max_length=64)
    password: str = Field(min_length=8, max_length=128)
    date_of_birth: date
    accept_terms: bool

    @field_validator("date_of_birth")
    @classmethod
    def _check_min_age(cls, value: date) -> date:
        today = datetime.now(UTC).date()
        age = today.year - value.year - ((today.month, today.day) < (value.month, value.day))
        if age < _settings.min_registration_age_years:
            raise ValueError(
                f"Регистрация доступна только с {_settings.min_registration_age_years} лет"
            )
        if value > today:
            raise ValueError("Дата рождения не может быть в будущем")
        return value

    @field_validator("accept_terms")
    @classmethod
    def _check_terms_accepted(cls, value: bool) -> bool:
        if not value:
            raise ValueError("Для регистрации нужно принять пользовательское соглашение")
        return value


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class TokenPair(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(BaseModel):
    refresh_token: str


class UserOut(BaseModel):
    id: str
    email: EmailStr
    username: str
    role: UserRole
    subscription_tier: SubscriptionTier
    is_active: bool
    email_verified: bool
    unlimited_usage: bool
    token_balance: int
    token_limit: int
    allow_training_data_use: bool

    model_config = {"from_attributes": True}


class TrainingConsentUpdate(BaseModel):
    """PATCH /auth/me/training-consent — явное opt-in/opt-out пользователя."""

    allow_training_data_use: bool


class VerifyEmailRequest(BaseModel):
    token: str


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str = Field(min_length=8, max_length=128)


class ChangeEmailRequest(BaseModel):
    new_email: EmailStr
    current_password: str


class ConfirmEmailChangeRequest(BaseModel):
    token: str


class GenericStatus(BaseModel):
    status: str


class UsernameAvailability(BaseModel):
    """Ответ на GET /auth/username-available — для живой галочки ✅/❌
    в форме регистрации, ДО отправки формы. Не заменяет серверную
    проверку уникальности в register_user (см. auth/services.py) —
    ник может быть занят кем-то ещё за секунды между проверкой и
    отправкой, финальное решение всегда за /register."""

    available: bool
    detail: str | None = None
