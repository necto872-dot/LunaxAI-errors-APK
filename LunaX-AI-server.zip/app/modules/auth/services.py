"""
Сервисный слой аутентификации LunaX AI.

Реализует (LunaX_AI_TZ.txt разделы 16-23, 33):
- регистрацию с email_verified=false и отправкой verification token;
- подтверждение email (одноразовый токен, срок действия);
- login с проверкой email_verified/is_active;
- forgot/reset password (одноразовый токен, срок действия);
- change/confirm email (требует текущий пароль, отдельный токен);
- JWT access/refresh токены.

Критические данные (роль, статус, email_verified) проверяются на
сервере в момент запроса, а не только по данным из JWT (ТЗ п.19).
"""
from datetime import UTC, date, datetime, timedelta

# SECURITY (найдено при аудите): раньше здесь был python-jose, который
# не обновлялся с 2021 года и содержит подтверждённые CVE-2024-33663
# (обход проверки алгоритма подписи, High) и CVE-2024-33664 (JWT bomb
# DoS через сжатие). Сам FastAPI официально перестал рекомендовать
# python-jose в пользу PyJWT. API encode/decode почти идентичен —
# миграция без изменения остальной логики.
import jwt
from jwt import PyJWTError
from passlib.context import CryptContext
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.email import (
    EmailSendError,
    send_email_change_confirmation,
    send_password_reset_email,
    send_verification_email,
)
from app.core.logger import get_logger, log_security_event
from app.core.tokens import generate_token, hash_token
from app.database.models import (
    EmailChangeToken,
    EmailVerificationToken,
    PasswordResetToken,
    User,
    UserRole,
)

settings = get_settings()
logger = get_logger("auth")

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class AuthError(Exception):
    """Ошибка бизнес-логики аутентификации (маппится на HTTP в роутере)."""

    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def _create_token(data: dict, expires_delta: timedelta) -> str:
    to_encode = data.copy()
    now = datetime.now(UTC)
    # iat нужен для отзыва сессий (User.session_revoked_before) — без него
    # /revoke-sessions не смог бы отличить токен, выданный до отзыва, от
    # выданного после (см. auth/dependencies.py:get_current_user).
    to_encode.update({"exp": now + expires_delta, "iat": now})
    return jwt.encode(to_encode, settings.jwt_secret_key, algorithm=settings.jwt_algorithm)


def create_access_token(user_id: str, role: str) -> str:
    return _create_token(
        {"sub": user_id, "role": role, "type": "access"},
        timedelta(minutes=settings.access_token_expire_minutes),
    )


def create_refresh_token(user_id: str) -> str:
    return _create_token(
        {"sub": user_id, "type": "refresh"},
        timedelta(days=settings.refresh_token_expire_days),
    )


def decode_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, settings.jwt_secret_key, algorithms=[settings.jwt_algorithm])
    except PyJWTError:
        return None


async def get_user_by_email(db: AsyncSession, email: str) -> User | None:
    result = await db.execute(select(User).where(User.email == email))
    return result.scalar_one_or_none()


async def get_user_by_username(db: AsyncSession, username: str) -> User | None:
    # Регистронезависимо ("Nick"/"nick"/"NICK" — один и тот же ник),
    # см. также миграцию 0008 (уникальный индекс по lower(username)).
    result = await db.execute(select(User).where(func.lower(User.username) == username.lower()))
    return result.scalar_one_or_none()


async def get_user_by_id(db: AsyncSession, user_id: str) -> User | None:
    result = await db.execute(select(User).where(User.id == user_id))
    return result.scalar_one_or_none()


def _now() -> datetime:
    return datetime.now(UTC)


def _aware(dt: datetime) -> datetime:
    """Некоторые БД (например SQLite) при round-trip теряют tzinfo у
    DateTime-колонок и возвращают naive datetime, хотя значение было
    записано в UTC. Приводим к aware UTC перед сравнением, иначе
    `naive < aware` кидает TypeError."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt


async def register_user(
    db: AsyncSession, email: str, username: str, password: str, date_of_birth: date
) -> User:
    if await get_user_by_email(db, email):
        raise AuthError("Пользователь с таким email уже существует", 409)
    if await get_user_by_username(db, username):
        raise AuthError("Имя пользователя уже занято", 409)

    # Повторная проверка возраста на уровне сервиса — pydantic-схема уже
    # проверила это на входе HTTP-запроса (см. UserRegister в
    # app/modules/auth/schemas.py), но эта функция может быть вызвана и
    # напрямую (тесты, будущие внутренние вызовы), поэтому не полагаемся
    # только на валидацию схемы (defense in depth, тот же принцип, что и
    # у остальных серверных проверок в проекте).
    today = datetime.now(UTC).date()
    age = today.year - date_of_birth.year - ((today.month, today.day) < (date_of_birth.month, date_of_birth.day))
    if age < settings.min_registration_age_years:
        raise AuthError(f"Регистрация доступна только с {settings.min_registration_age_years} лет", 403)

    from app.config.settings import TOKEN_LIMITS  # локальный импорт во избежание циклов

    free_limit = TOKEN_LIMITS["free"]
    user = User(
        email=email,
        username=username,
        hashed_password=hash_password(password),
        role=UserRole.USER,
        is_active=True,
        email_verified=False,
        token_balance=free_limit,
        token_limit=free_limit,
        date_of_birth=date_of_birth,
        terms_accepted_at=_now(),
        terms_version=settings.terms_version,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)

    await _issue_verification_token(db, user)
    logger.info("Новый пользователь зарегистрирован: %s", user.id)
    return user


async def _issue_verification_token(db: AsyncSession, user: User) -> str:
    raw_token = generate_token()
    record = EmailVerificationToken(
        user_id=user.id,
        token_hash=hash_token(raw_token),
        expires_at=_now() + timedelta(hours=settings.email_verification_token_expire_hours),
    )
    db.add(record)
    await db.commit()

    try:
        send_verification_email(user.email, raw_token)
    except EmailSendError:
        logger.warning("Не удалось отправить письмо верификации user_id=%s", user.id)
    return raw_token


async def verify_email(db: AsyncSession, token: str) -> User:
    token_hash = hash_token(token)
    result = await db.execute(
        select(EmailVerificationToken).where(EmailVerificationToken.token_hash == token_hash)
    )
    record = result.scalar_one_or_none()
    if record is None:
        raise AuthError("Недействительный токен подтверждения", 400)
    if record.used_at is not None:
        raise AuthError("Токен уже был использован", 400)
    if _aware(record.expires_at) < _now():
        raise AuthError("Срок действия токена истёк", 400)

    user = await get_user_by_id(db, record.user_id)
    if user is None:
        raise AuthError("Пользователь не найден", 404)

    user.email_verified = True
    record.used_at = _now()
    await db.commit()
    await db.refresh(user)
    logger.info("Email подтверждён: user_id=%s", user.id)
    return user


async def authenticate_user(db: AsyncSession, email: str, password: str) -> User:
    user = await get_user_by_email(db, email)
    if not user or not verify_password(password, user.hashed_password):
        log_security_event("failed_login_attempt", details={"email": email})
        raise AuthError("Неверный email или пароль", 401)
    if not user.is_active:
        log_security_event("login_attempt_inactive_account", user_id=user.id)
        raise AuthError("Аккаунт деактивирован", 403)
    if user.banned_until is not None and _aware(user.banned_until) > _now():
        log_security_event("login_attempt_banned_account", user_id=user.id)
        raise AuthError(f"Аккаунт временно заблокирован до {user.banned_until.isoformat()}", 403)
    if not user.email_verified:
        raise AuthError("Email не подтверждён. Проверьте почту.", 403)

    user.last_login_at = _now()
    await db.commit()
    await db.refresh(user)
    return user


async def request_password_reset(db: AsyncSession, email: str) -> None:
    """Не раскрывает, существует ли email (ТЗ п.21) — письмо шлётся только если найден."""
    user = await get_user_by_email(db, email)
    if user is None:
        return

    raw_token = generate_token()
    record = PasswordResetToken(
        user_id=user.id,
        token_hash=hash_token(raw_token),
        expires_at=_now() + timedelta(minutes=settings.password_reset_token_expire_minutes),
    )
    db.add(record)
    await db.commit()

    from app.core.audit import record_audit_event  # локальный импорт во избежание циклов

    await record_audit_event(db, "password_reset_requested", actor_id=user.id, target_id=user.id)

    try:
        send_password_reset_email(user.email, raw_token)
    except EmailSendError:
        logger.warning("Не удалось отправить письмо восстановления пароля user_id=%s", user.id)


async def reset_password(db: AsyncSession, token: str, new_password: str) -> User:
    token_hash = hash_token(token)
    result = await db.execute(
        select(PasswordResetToken).where(PasswordResetToken.token_hash == token_hash)
    )
    record = result.scalar_one_or_none()
    if record is None:
        raise AuthError("Недействительный токен восстановления", 400)
    if record.used_at is not None:
        raise AuthError("Токен уже был использован", 400)
    if _aware(record.expires_at) < _now():
        raise AuthError("Срок действия токена истёк", 400)

    user = await get_user_by_id(db, record.user_id)
    if user is None:
        raise AuthError("Пользователь не найден", 404)

    user.hashed_password = hash_password(new_password)
    record.used_at = _now()
    await db.commit()
    logger.info("Пароль сброшен: user_id=%s", user.id)
    return user


async def request_email_change(db: AsyncSession, user: User, new_email: str, current_password: str) -> None:
    if not verify_password(current_password, user.hashed_password):
        raise AuthError("Неверный текущий пароль", 401)
    if await get_user_by_email(db, new_email):
        raise AuthError("Этот email уже используется", 409)

    raw_token = generate_token()
    record = EmailChangeToken(
        user_id=user.id,
        new_email=new_email,
        token_hash=hash_token(raw_token),
        expires_at=_now() + timedelta(hours=settings.email_change_token_expire_hours),
    )
    db.add(record)
    await db.commit()

    try:
        send_email_change_confirmation(new_email, raw_token)
    except EmailSendError:
        logger.warning("Не удалось отправить письмо подтверждения смены email user_id=%s", user.id)


async def confirm_email_change(db: AsyncSession, token: str) -> User:
    token_hash = hash_token(token)
    result = await db.execute(
        select(EmailChangeToken).where(EmailChangeToken.token_hash == token_hash)
    )
    record = result.scalar_one_or_none()
    if record is None:
        raise AuthError("Недействительный токен смены email", 400)
    if record.used_at is not None:
        raise AuthError("Токен уже был использован", 400)
    if _aware(record.expires_at) < _now():
        raise AuthError("Срок действия токена истёк", 400)

    user = await get_user_by_id(db, record.user_id)
    if user is None:
        raise AuthError("Пользователь не найден", 404)

    existing = await get_user_by_email(db, record.new_email)
    if existing and existing.id != user.id:
        raise AuthError("Этот email уже используется", 409)

    user.email = record.new_email
    user.email_verified = True
    record.used_at = _now()
    await db.commit()
    logger.info("Email изменён: user_id=%s", user.id)
    return user
