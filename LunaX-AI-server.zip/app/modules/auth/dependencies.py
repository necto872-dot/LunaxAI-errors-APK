"""
FastAPI-зависимости для защиты эндпоинтов и разграничения ролей.

Реализует ТЗ п.6, п.13, п.33: Primary Developer нельзя изменить/удалить
через обычный API ни одной ролью, включая его самого. Роль всегда
проверяется по актуальному состоянию в БД, а не только по JWT (ТЗ п.19).
"""
from datetime import UTC, datetime

from fastapi import Depends, Header, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.database.models import User, UserRole
from app.modules.auth.services import decode_token, get_user_by_id


def _aware(dt: datetime) -> datetime:
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=UTC)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Не удалось подтвердить учётные данные",
        headers={"WWW-Authenticate": "Bearer"},
    )

    payload = decode_token(token)
    if payload is None or payload.get("type") != "access":
        raise credentials_exception

    user_id = payload.get("sub")
    if user_id is None:
        raise credentials_exception

    # Роль и статус всегда берутся из БД на момент запроса, а не из JWT payload.
    user = await get_user_by_id(db, user_id)
    if user is None or not user.is_active:
        raise credentials_exception

    if user.banned_until is not None and _aware(user.banned_until) > datetime.now(UTC):
        raise credentials_exception

    # /revoke-sessions <email>: любой токен, выданный до этой метки, мёртв,
    # даже если exp ещё не наступил.
    if user.session_revoked_before is not None:
        iat = payload.get("iat")
        if iat is None or datetime.fromtimestamp(iat, tz=UTC) < _aware(user.session_revoked_before):
            raise credentials_exception

    return user


def require_role(*allowed_roles: UserRole):
    """Фабрика зависимости: ограничивает доступ по роли пользователя.
    Для developer/primary_developer/admin с включённым TOTP (2FA Developer
    Console) дополнительно требует заголовок X-TOTP-Code (app/core/totp.py)."""

    async def checker(
        user: User = Depends(get_current_user),
        x_totp_code: str | None = Header(default=None),
    ) -> User:
        if user.role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Недостаточно прав для выполнения этого действия",
            )
        if user.totp_enabled and user.role in (
            UserRole.DEVELOPER, UserRole.PRIMARY_DEVELOPER, UserRole.ADMIN,
        ):
            from app.core.totp import verify_code

            if not x_totp_code or not verify_code(user.totp_secret, x_totp_code):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Требуется 2FA-код (заголовок X-TOTP-Code)",
                )
        return user

    return checker


# Developer-функции доступны Developer, Primary Developer и Admin.
require_developer = require_role(UserRole.DEVELOPER, UserRole.PRIMARY_DEVELOPER, UserRole.ADMIN)

# Управление вторичными разработчиками — только Primary Developer.
require_primary_developer = require_role(UserRole.PRIMARY_DEVELOPER)

require_admin = require_role(UserRole.ADMIN)


def forbid_primary_developer_target(target_user: User) -> None:
    """
    Блокирует любое изменение/удаление Primary Developer через обычный
    management API (ТЗ п.6, п.15, п.33), независимо от того, кто вызывает
    операцию — включая самого Primary Developer.

    Замена Primary разрешена только через серверный CLI
    (scripts/manage_primary.py), не через HTTP API.
    """
    if target_user.role == UserRole.PRIMARY_DEVELOPER:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot modify primary developer",
        )
