from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.audit import record_audit_event
from app.core.rate_limit import rate_limit
from app.core.security_events import check_login_failure_burst, check_mass_registration, check_new_ip_after_credential_change
from app.database import get_db
from app.database.models import User
from app.modules.auth.dependencies import get_current_user
from app.modules.auth.schemas import (
    ChangeEmailRequest,
    ConfirmEmailChangeRequest,
    ForgotPasswordRequest,
    GenericStatus,
    RefreshRequest,
    ResetPasswordRequest,
    TokenPair,
    TrainingConsentUpdate,
    UsernameAvailability,
    UserLogin,
    UserOut,
    UserRegister,
    VerifyEmailRequest,
)
from app.modules.auth.services import (
    AuthError,
    authenticate_user,
    confirm_email_change,
    create_access_token,
    create_refresh_token,
    decode_token,
    get_user_by_id,
    get_user_by_username,
    register_user,
    request_email_change,
    request_password_reset,
    reset_password,
    verify_email,
)

router = APIRouter(prefix="/auth", tags=["Аккаунты и авторизация"])


def _raise(err: AuthError):
    raise HTTPException(status_code=err.status_code, detail=err.message)


@router.get("/username-available", response_model=UsernameAvailability)
async def username_available(
    username: str,
    db: AsyncSession = Depends(get_db),
    _rl=rate_limit("username_check", "rate_limit_register_per_minute"),
):
    """Живая проверка "ник уже занят" для формы регистрации (✅/❌ до
    отправки). Не отдельный секретный лимит — переиспользует лимит
    register, чтобы не плодить настройку под один вспомогательный
    эндпоинт."""
    existing = await get_user_by_username(db, username)
    return UsernameAvailability(available=existing is None)


@router.post("/register", response_model=UserOut, status_code=201)
async def register(
    data: UserRegister,
    request: Request,
    db: AsyncSession = Depends(get_db),
    _rl=rate_limit("register", "rate_limit_register_per_minute"),
):
    ip = request.client.host if request.client else None
    try:
        user = await register_user(db, data.email, data.username, data.password, data.date_of_birth)
    except AuthError as e:
        _raise(e)
    await record_audit_event(db, "user_registered", actor_id=user.id, target_id=user.id, ip=ip)
    await check_mass_registration(db, ip)
    return user


@router.post("/verify-email", response_model=UserOut)
async def verify_email_endpoint(
    data: VerifyEmailRequest,
    db: AsyncSession = Depends(get_db),
    _rl=rate_limit("verify_email", "rate_limit_verify_email_per_minute"),
):
    try:
        user = await verify_email(db, data.token)
    except AuthError as e:
        _raise(e)
    await record_audit_event(db, "email_verified", actor_id=user.id, target_id=user.id)
    return user


@router.post("/login", response_model=TokenPair)
async def login(
    data: UserLogin,
    request: Request,
    db: AsyncSession = Depends(get_db),
    _rl=rate_limit("login", "rate_limit_login_per_minute"),
):
    try:
        user = await authenticate_user(db, data.email, data.password)
    except AuthError as e:
        await record_audit_event(db, "login_failed", details={"email": data.email, "reason": e.message})
        # Репорт в Консоль разработчика при серии неудачных попыток —
        # см. app/core/security_events.py. Не должно ронять сам login.
        ip = request.client.host if request.client else None
        await check_login_failure_burst(db, data.email, ip)
        _raise(e)
    await record_audit_event(db, "login_success", actor_id=user.id, target_id=user.id)

    ip = request.client.host if request.client else None
    await check_new_ip_after_credential_change(db, user, ip)
    user.last_login_ip = ip
    await db.commit()

    return TokenPair(
        access_token=create_access_token(user.id, user.role.value),
        refresh_token=create_refresh_token(user.id),
    )


@router.post("/refresh", response_model=TokenPair)
async def refresh(data: RefreshRequest, db: AsyncSession = Depends(get_db)):
    payload = decode_token(data.refresh_token)
    if payload is None or payload.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="Невалидный refresh-токен")

    user = await get_user_by_id(db, payload.get("sub"))
    if user is None or not user.is_active:
        raise HTTPException(status_code=401, detail="Пользователь не найден")

    return TokenPair(
        access_token=create_access_token(user.id, user.role.value),
        refresh_token=create_refresh_token(user.id),
    )


@router.post("/forgot-password", response_model=GenericStatus)
async def forgot_password(
    data: ForgotPasswordRequest,
    db: AsyncSession = Depends(get_db),
    _rl=rate_limit("forgot_password", "rate_limit_forgot_password_per_minute"),
):
    # Ответ одинаковый независимо от того, существует ли email (ТЗ п.21).
    # Audit-запись создаётся внутри request_password_reset только если email
    # реально найден — иначе нечего логировать (не создаём запись по чужому id).
    await request_password_reset(db, data.email)
    return GenericStatus(status="ok", detail="Если аккаунт существует, письмо отправлено")


@router.post("/reset-password", response_model=GenericStatus)
async def reset_password_endpoint(
    data: ResetPasswordRequest,
    db: AsyncSession = Depends(get_db),
    _rl=rate_limit("reset_password", "rate_limit_reset_password_per_minute"),
):
    try:
        user = await reset_password(db, data.token, data.new_password)
    except AuthError as e:
        _raise(e)
    await record_audit_event(db, "password_reset_completed", actor_id=user.id, target_id=user.id)
    return GenericStatus(status="ok", detail="Пароль обновлён")


@router.post("/change-email", response_model=GenericStatus)
async def change_email(
    data: ChangeEmailRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        await request_email_change(db, user, data.new_email, data.current_password)
    except AuthError as e:
        _raise(e)
    await record_audit_event(
        db, "email_change_requested", actor_id=user.id, target_id=user.id, new_email=data.new_email
    )
    return GenericStatus(status="ok", detail="Письмо для подтверждения отправлено на новый адрес")


@router.post("/confirm-email-change", response_model=UserOut)
async def confirm_email_change_endpoint(data: ConfirmEmailChangeRequest, db: AsyncSession = Depends(get_db)):
    try:
        user = await confirm_email_change(db, data.token)
    except AuthError as e:
        _raise(e)
    await record_audit_event(db, "email_change_confirmed", actor_id=user.id, target_id=user.id)
    return user


@router.get("/me", response_model=UserOut)
async def get_me(user: User = Depends(get_current_user)):
    return user


@router.patch("/me/training-consent", response_model=UserOut)
async def update_training_consent(
    data: TrainingConsentUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """
    Явное opt-in/opt-out: разрешает или запрещает включать переписку этого
    пользователя (Conversation/Message) в датасет для LoRA-дообучения
    Lunox AI. По умолчанию выключено для всех — см. миграцию
    0004_training_pipeline. training/collect_from_db.py экспортирует
    ТОЛЬКО диалоги пользователей с allow_training_data_use=True на момент
    запуска сбора.
    """
    user.allow_training_data_use = data.allow_training_data_use
    await db.commit()
    await db.refresh(user)
    await record_audit_event(
        db,
        "training_consent_updated",
        actor_id=user.id,
        target_id=user.id,
        allow_training_data_use=data.allow_training_data_use,
    )
    return user
