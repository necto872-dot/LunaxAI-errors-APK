"""
Модуль: очередь задач (RQ/Redis) + биометрия.

Биометрия: реальный протокол одноразового challenge, лимита попыток и
временной блокировки (см. app/core/biometry.py — там же честное
объяснение, что визуальный ML-анализ живости в проект не входит).

Очередь: реальная RQ-интеграция (app/core/queue.py) — эндпоинт ниже
только для проверки механизма (health-check job), реальных тяжёлых задач
(APK build, video gen) пока нет как отдельных подсистем.
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from rq.exceptions import NoSuchJobError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.biometry import BiometryError, create_challenge, verify_liveness
from app.core.queue import echo_job, enqueue_job, get_job_status
from app.database import get_db
from app.database.models import User
from app.modules.auth.dependencies import get_current_user

router = APIRouter(prefix="/biometry", tags=["Биометрия"])
queue_router = APIRouter(prefix="/queue", tags=["Очередь задач"])


def _raise(err: BiometryError):
    raise HTTPException(status_code=err.status_code, detail=err.message)


class LivenessVerifyRequest(BaseModel):
    challenge_id: str
    passed: bool
    suspected_replay: bool = False


@router.get("/liveness-challenge")
async def get_liveness_challenge(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    import json

    try:
        challenge = await create_challenge(db, user)
    except BiometryError as e:
        _raise(e)
    return {"challenge_id": challenge.id, "actions": json.loads(challenge.actions)}


@router.post("/liveness-verify")
async def verify(
    data: LivenessVerifyRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        return await verify_liveness(db, user, data.challenge_id, data.passed, data.suspected_replay)
    except BiometryError as e:
        _raise(e)


@queue_router.post("/health-check")
async def queue_health_check(payload: str = "ping", user: User = Depends(get_current_user)):
    """Ставит демо-задачу в очередь, возвращает job_id для опроса статуса."""
    job_id = enqueue_job("default", echo_job, payload)
    return {"job_id": job_id}


@queue_router.get("/jobs/{job_id}")
async def queue_job_status(job_id: str, user: User = Depends(get_current_user)):
    try:
        return get_job_status(job_id)
    except NoSuchJobError as exc:
        raise HTTPException(status_code=404, detail="Задача не найдена") from exc
