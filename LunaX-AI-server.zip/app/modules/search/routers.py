"""
Lunox AI chat endpoint + память (закрывает главный пробел из аудита:
"модель отвечает, но не помнит пользователя").

User -> API -> auth -> token quota (C1) -> загрузка памяти (долговременные
факты + история диалога) -> Lunox AI router -> self-hosted модель ->
Lunox AI -> User -> сохранение сообщений в историю.

ЧЕСТНО: пока settings.lunox_ai_enabled=False или self-hosted сервер не
поднят/не настроен, /search/query отвечает 503 "Lunox AI недоступен", а
НЕ подделывает ответ. Списанные токены при этом возвращаются пользователю
(операция не состоялась). Память при этом продолжает работать сама по
себе — /memory/* эндпоинты не зависят от доступности AI.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.ai.lunox_router import LunoxAIUnavailableError, lunox_generate
from app.core.ai.memory import (
    MemoryError,
    MemoryQuotaExceededError,
    append_message_pair,
    build_full_context,
    build_long_term_context,
    delete_conversation,
    forget_fact,
    get_conversation_messages,
    get_memory_status,
    get_owned_conversation_or_404,
    list_facts,
    list_user_conversations,
    remember_fact,
)
from app.core.ai_moderation import moderate_prompt
from app.core.logger import get_logger
from app.core.quota import InsufficientTokensError, quota_status
from app.core.safety import is_blocked
from app.core.token_cost import estimate_text_cost, reserve_and_spend
from app.core.web_search import (
    WebSearchNotConfiguredError,
    WebSearchRequestError,
    fetch_page,
    format_results_for_context,
    search_web,
)
from app.database import get_db
from app.database.models import Conversation, User
from app.modules.auth.dependencies import get_current_user
from app.modules.search.schemas import (
    ChatRequest,
    ChatResponse,
    ConversationOut,
    MemoryFactOut,
    MemoryStatusOut,
    MessageOut,
    RememberFactRequest,
)

router = APIRouter(prefix="/search", tags=["Lunox AI"])
memory_router = APIRouter(prefix="/memory", tags=["Память Lunox AI"])
logger = get_logger("search_router")
settings = get_settings()


def _raise(err: MemoryError):
    raise HTTPException(status_code=err.status_code, detail=err.message)


@router.post("/query", response_model=ChatResponse)
async def chat_with_lunox(
    data: ChatRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if is_blocked(data.prompt):
        raise HTTPException(status_code=400, detail="Запрос отклонён политикой безопасности")

    # Второй, более гибкий слой поверх regex-фильтра выше (см. честное
    # ограничение в app/core/ai_moderation.py — работает только если
    # включён и AI реально запущен; иначе тихо пропускается, не блокируя
    # запрос дополнительно к тому, что уже проверил regex).
    moderation = await moderate_prompt(data.prompt)
    if moderation.checked and not moderation.allowed:
        raise HTTPException(status_code=400, detail=f"Запрос отклонён политикой безопасности: {moderation.reason}")

    # Существующий диалог загружается сразу (нужна его история для
    # контекста). Новый диалог НЕ создаётся в БД до успешного ответа —
    # иначе при недоступном AI в базе оставался бы диалог-сирота без
    # единого сообщения.
    conversation: Conversation | None = None
    if data.conversation_id:
        try:
            conversation = await get_owned_conversation_or_404(db, user, data.conversation_id)
        except MemoryError as e:
            _raise(e)
        context = await build_full_context(db, user, conversation)
    else:
        context = build_long_term_context(await list_facts(db, user))

    if data.use_web_search and settings.lunox_web_search_enabled:
        try:
            results = await search_web(data.prompt)
            context.append({"role": "system", "content": format_results_for_context(results)})
        except (WebSearchNotConfiguredError, WebSearchRequestError) as e:
            logger.warning("Веб-поиск запрошен, но недоступен: %s", e)

    cost = estimate_text_cost()
    try:
        spend_result = await reserve_and_spend(db, user, cost)
    except InsufficientTokensError as e:
        raise HTTPException(status_code=402, detail=str(e)) from e

    try:
        answer = await lunox_generate(data.prompt, context=context)
    except LunoxAIUnavailableError as e:
        # Операция не состоялась — возвращаем списанные токены пользователю.
        # Ничего не сохраняем в историю — переписки без ответа не было.
        if not spend_result["unlimited"]:
            user.token_balance = (user.token_balance or 0) + spend_result["spent"]
            await db.commit()
        raise HTTPException(status_code=503, detail=str(e)) from e

    if conversation is None:
        conversation = Conversation(owner_id=user.id)
        db.add(conversation)
        await db.commit()
        await db.refresh(conversation)

    try:
        await append_message_pair(db, user, conversation, data.prompt, answer)
    except MemoryQuotaExceededError as e:
        # AI уже ответил и токены списаны честно (операция состоялась) —
        # но сохранить в историю не удалось, лимит хранения исчерпан.
        # Отдаём ответ пользователю всё равно (не выбрасывать сгенерированное),
        # явно предупреждая, что в истории он не останется.
        return ChatResponse(
            response=answer,
            conversation_id=conversation.id,
            token_status=quota_status(user),
            memory_warning=str(e),
        )

    return ChatResponse(response=answer, conversation_id=conversation.id, token_status=quota_status(user))


@router.get("/conversations", response_model=list[ConversationOut])
async def list_conversations(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await list_user_conversations(db, user)


@router.get("/conversations/{conversation_id}/messages", response_model=list[MessageOut])
async def get_messages(
    conversation_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        return await get_conversation_messages(db, user, conversation_id)
    except MemoryError as e:
        _raise(e)


@router.delete("/conversations/{conversation_id}")
async def remove_conversation(
    conversation_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        await delete_conversation(db, user, conversation_id)
    except MemoryError as e:
        _raise(e)
    return {"status": "deleted", "conversation_id": conversation_id}


# --- Долговременная память: явный remember/forget ---

@memory_router.get("/status", response_model=MemoryStatusOut)
async def memory_status(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await get_memory_status(db, user)


@memory_router.post("/remember", response_model=MemoryFactOut, status_code=201)
async def remember(
    data: RememberFactRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        return await remember_fact(db, user, data.content)
    except MemoryError as e:
        _raise(e)


@memory_router.get("/facts", response_model=list[MemoryFactOut])
async def get_facts(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await list_facts(db, user)


@memory_router.delete("/forget/{fact_id}")
async def forget(
    fact_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        await forget_fact(db, user, fact_id)
    except MemoryError as e:
        _raise(e)
    return {"status": "forgotten", "fact_id": fact_id}


@router.post("/fetch-page")
async def fetch_page_endpoint(
    data: dict,
    user: User = Depends(get_current_user),
):
    """Прямое чтение полной страницы по URL. Запрос проверяется safety-фильтром."""
    url = data.get("url", "")
    if is_blocked(url):
        raise HTTPException(status_code=400, detail="Запрос отклонён политикой безопасности")
    try:
        text = await fetch_page(url)
    except (WebSearchNotConfiguredError, WebSearchRequestError) as e:
        raise HTTPException(status_code=503, detail=str(e)) from e
    return {"url": url, "content": text}
