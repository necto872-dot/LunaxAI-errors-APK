from datetime import datetime

from pydantic import BaseModel


class ChatRequest(BaseModel):
    prompt: str
    conversation_id: str | None = None  # None -> создаётся новый диалог
    use_web_search: bool = True  # по умолчанию вкл.; можно передать false, чтобы отключить для запроса


class ChatResponse(BaseModel):
    response: str
    conversation_id: str
    token_status: dict
    memory_warning: str | None = None


class ConversationOut(BaseModel):
    id: str
    title: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class MessageOut(BaseModel):
    id: str
    role: str
    content: str
    created_at: datetime

    model_config = {"from_attributes": True}


class RememberFactRequest(BaseModel):
    content: str


class MemoryFactOut(BaseModel):
    id: str
    content: str
    created_at: datetime

    model_config = {"from_attributes": True}


class MemoryStatusOut(BaseModel):
    used_bytes: int
    limit_bytes: int
    used_percent: float
