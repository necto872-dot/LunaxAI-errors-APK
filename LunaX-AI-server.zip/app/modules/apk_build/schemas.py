from datetime import datetime

from pydantic import BaseModel

from app.database.models import ApkBuildJobStatus


class ApkBuildRequest(BaseModel):
    project_id: str


class ApkBuildJobOut(BaseModel):
    id: str
    project_id: str
    status: ApkBuildJobStatus
    log: str
    artifact_path: str | None
    created_at: datetime

    model_config = {"from_attributes": True}
