"""APK-сборка. Реальная сборка требует Android SDK/Gradle (settings.apk_build_enabled)."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.build.apk import ApkBuildError, enqueue_apk_build, get_owned_apk_job_or_404
from app.database import get_db
from app.database.models import User
from app.modules.apk_build.schemas import ApkBuildJobOut, ApkBuildRequest
from app.modules.auth.dependencies import get_current_user

router = APIRouter(prefix="/apk", tags=["APK-сборка"])


def _raise(err: ApkBuildError):
    raise HTTPException(status_code=err.status_code, detail=err.message)


@router.post("/build", response_model=ApkBuildJobOut, status_code=202)
async def build_apk(
    data: ApkBuildRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """
    Ставит сборку APK в приоритетную очередь пользователя (ТЗ п.9) и сразу
    возвращает задачу со статусом queued — не блокирует запрос ожиданием
    Gradle. Прогресс — через GET /apk/build/{job_id}.
    """
    try:
        return await enqueue_apk_build(db, user, data.project_id)
    except ApkBuildError as e:
        _raise(e)


@router.get("/build/{job_id}", response_model=ApkBuildJobOut)
async def get_build_status(
    job_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        return await get_owned_apk_job_or_404(db, user, job_id)
    except ApkBuildError as e:
        _raise(e)
