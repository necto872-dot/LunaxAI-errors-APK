"""
Изображения (закрывает заглушку из аудита: "нет генерации/анализа
изображений"). Генерация — через self-hosted image-сервер (см.
app/core/media/image_client.py), списание по C2 (согласованный
коэффициент), с возвратом токенов при неудаче — тот же принцип, что и
/search/query (app/modules/search/routers.py).

ЧЕСТНО НЕ реализовано: анализ загруженных изображений (описание
содержимого) — self-hosted vision-модель не подключена в этом проходе.
"""
import base64

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import REAL_LIFE_VIDEO_ROLES
from app.core.media.image_client import (
    ImageGenerationNotConfiguredError,
    ImageGenerationRequestError,
    generate_image,
)
from app.core.media.video_client import (
    VideoGenerationNotConfiguredError,
    VideoGenerationRequestError,
    generate_video,
)
from app.core.quota import InsufficientTokensError
from app.core.token_cost import estimate_image_cost, estimate_video_cost, reserve_and_spend
from app.database import get_db
from app.database.models import User
from app.modules.auth.dependencies import get_current_user
from app.modules.media.schemas import (
    ImageGenerateRequest,
    ImageGenerateResponse,
    VideoGenerateRequest,
    VideoGenerateResponse,
)

router = APIRouter(prefix="/media", tags=["Изображения и медиа"])


@router.post("/image/generate", response_model=ImageGenerateResponse)
async def generate_image_endpoint(
    data: ImageGenerateRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    cost = estimate_image_cost()
    try:
        spend_result = await reserve_and_spend(db, user, cost)
    except InsufficientTokensError as e:
        raise HTTPException(status_code=402, detail=str(e)) from e

    try:
        image_bytes = await generate_image(data.prompt)
    except (ImageGenerationNotConfiguredError, ImageGenerationRequestError) as e:
        if not spend_result["unlimited"]:
            user.token_balance = (user.token_balance or 0) + spend_result["spent"]
            await db.commit()
        raise HTTPException(status_code=503, detail=str(e)) from e

    return ImageGenerateResponse(image_base64=base64.b64encode(image_bytes).decode("ascii"))


@router.post("/video/generate", response_model=VideoGenerateResponse)
async def generate_video_endpoint(
    data: VideoGenerateRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if user.subscription_tier.value not in REAL_LIFE_VIDEO_ROLES:
        raise HTTPException(status_code=403, detail="Генерация видео доступна только на тарифах Ultra и Ultra Plus")

    cost = estimate_video_cost(data.duration_seconds)
    try:
        spend_result = await reserve_and_spend(db, user, cost)
    except InsufficientTokensError as e:
        raise HTTPException(status_code=402, detail=str(e)) from e

    try:
        video_bytes = await generate_video(data.prompt, data.duration_seconds)
    except (VideoGenerationNotConfiguredError, VideoGenerationRequestError) as e:
        if not spend_result["unlimited"]:
            user.token_balance = (user.token_balance or 0) + spend_result["spent"]
            await db.commit()
        raise HTTPException(status_code=503, detail=str(e)) from e

    return VideoGenerateResponse(video_base64=base64.b64encode(video_bytes).decode("ascii"))
