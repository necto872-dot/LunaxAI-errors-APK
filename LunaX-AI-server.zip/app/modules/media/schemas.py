from pydantic import BaseModel


class ImageGenerateRequest(BaseModel):
    prompt: str


class ImageGenerateResponse(BaseModel):
    image_base64: str


class VideoGenerateRequest(BaseModel):
    prompt: str
    duration_seconds: float = 5.0


class VideoGenerateResponse(BaseModel):
    video_base64: str
