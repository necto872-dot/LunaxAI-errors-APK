from datetime import datetime

from pydantic import BaseModel

from app.database.models import PaymentStatus, SubscriptionTier


class CheckoutRequest(BaseModel):
    tariff: SubscriptionTier


class CheckoutResponse(BaseModel):
    payment_id: str
    checkout_url: str
    provider: str


class PaymentOut(BaseModel):
    id: str
    provider: str
    tariff: SubscriptionTier
    amount_kzt: int
    status: PaymentStatus
    created_at: datetime

    model_config = {"from_attributes": True}


class ManualPaymentRequisitesOut(BaseModel):
    """Реквизиты для ручного перевода (счёт самозанятого в Kaspi.kz)."""

    phone: str
    name: str


class ManualPaymentOut(BaseModel):
    """Ручной платёж вместе с email плательщика — для списка в Консоли
    разработчика (собирается вручную в роутере, не через from_attributes,
    т.к. email лежит на User, а не на Payment)."""

    id: str
    tariff: SubscriptionTier
    amount_kzt: int
    status: PaymentStatus
    created_at: datetime
    user_email: str
