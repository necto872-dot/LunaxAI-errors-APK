"""
Payments (финальное ТЗ раздел 10-12): checkout + provider-agnostic webhook.

/checkout — требует JWT, создаёт Payment(status=pending) и просит у
провайдера checkout-сессию.
/webhook/{provider} — публичный (провайдер не передаёт JWT пользователя),
защищён проверкой подписи внутри provider.verify_and_parse_webhook().
"""
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.database import get_db
from app.database.models import User
from app.modules.auth.dependencies import get_current_user
from app.modules.payments.schemas import (
    CheckoutRequest,
    CheckoutResponse,
    ManualPaymentRequisitesOut,
    PaymentOut,
)
from app.modules.payments.services import (
    PaymentError,
    create_checkout,
    create_manual_payment_request,
    list_user_payments,
    process_webhook,
)

router = APIRouter(prefix="/payments", tags=["Платежи"])


def _raise(err: PaymentError):
    raise HTTPException(status_code=err.status_code, detail=err.message)


@router.post("/checkout", response_model=CheckoutResponse)
async def checkout(
    data: CheckoutRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        return await create_checkout(db, user, data.tariff)
    except PaymentError as e:
        _raise(e)


@router.get("/manual/requisites", response_model=ManualPaymentRequisitesOut)
async def manual_requisites():
    """Реквизиты для ручного перевода — заполняются в .env
    (manual_payment_phone / manual_payment_name), пока kaspi/freedompay
    не подключены боевыми ключами. Публичный — нужен на экране "Купить"
    ещё до оплаты."""
    settings = get_settings()
    return ManualPaymentRequisitesOut(phone=settings.manual_payment_phone, name=settings.manual_payment_name)


@router.post("/manual/request", response_model=PaymentOut, status_code=201)
async def manual_request(
    data: CheckoutRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Пользователь жмёт «Я оплатил» — создаёт Payment(pending, provider=
    manual). Тариф НЕ включается тут — только после того, как Developer
    вручную сверит перевод и подтвердит через Консоль разработчика."""
    try:
        return await create_manual_payment_request(db, user, data.tariff)
    except PaymentError as e:
        _raise(e)


@router.get("/my", response_model=list[PaymentOut])
async def my_payments(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await list_user_payments(db, user.id)


@router.post("/webhook/{provider_name}")
async def webhook(
    provider_name: str,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    raw_body = await request.body()
    headers = dict(request.headers)
    try:
        return await process_webhook(db, provider_name, headers, raw_body)
    except PaymentError as e:
        _raise(e)
