"""
Платёжный сервис (финальное ТЗ раздел 10-12).

Поток: User → Checkout → PaymentProvider → Payment Gateway → Webhook →
Payment Service (этот файл) → Tariff Service → Token Balance.

Идемпотентность: обработка webhook ищет Payment по external_payment_id;
если платёж уже в статусе SUCCEEDED — событие логируется, но тариф
повторно НЕ активируется и баланс НЕ начисляется повторно (ТЗ раздел 11:
"Повторный webhook не должен повторно активировать тариф").
"""
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import TIER_PRICE_TENGE, TOKEN_LIMITS
from app.core.audit import record_audit_event
from app.core.logger import get_logger
from app.core.payments.base import PaymentConfigurationError, WebhookEvent, WebhookSignatureError
from app.core.payments.registry import get_provider
from app.database.models import (
    Payment,
    PaymentEvent,
    PaymentStatus,
    SubscriptionTier,
    User,
)

logger = get_logger("payments")


class PaymentError(Exception):
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


async def create_checkout(db: AsyncSession, user: User, tariff: SubscriptionTier) -> dict:
    if tariff == SubscriptionTier.FREE:
        raise PaymentError("FREE тариф не требует оплаты", 400)

    amount_kzt = TIER_PRICE_TENGE.get(tariff.value)
    if amount_kzt is None:
        raise PaymentError(f"Цена для тарифа {tariff.value} не определена в конфигурации", 400)

    provider = get_provider()

    payment = Payment(
        user_id=user.id,
        provider=provider.name,
        tariff=tariff,
        amount_kzt=amount_kzt,
        status=PaymentStatus.PENDING,
    )
    db.add(payment)
    await db.commit()
    await db.refresh(payment)

    try:
        session = await provider.create_checkout(
            payment_id=payment.id, amount_kzt=amount_kzt, description=f"LunaX AI — {tariff.value}"
        )
    except PaymentConfigurationError as e:
        raise PaymentError(str(e), 503) from e
    except NotImplementedError as e:  # audit-allow: честный 501, а не притворный успех — см. *_provider.py
        # Провайдер архитектурно готов, но реальный API-вызов ещё не
        # подключён (нет подтверждённой документации/credentials) — см.
        # app/core/payments/*_provider.py. Честно отдаём 501, а не
        # притворяемся, что checkout создан.
        raise PaymentError(str(e), 501) from e

    return {"payment_id": payment.id, "checkout_url": session.checkout_url, "provider": provider.name}


async def create_manual_payment_request(db: AsyncSession, user: User, tariff: SubscriptionTier) -> Payment:
    """Ручная оплата (без ИП — счёт самозанятого в Kaspi.kz): создаёт
    Payment(provider="manual", status=PENDING). Активацию делает Developer
    через POST /developer/payments/{id}/confirm после того, как реально
    увидел перевод — никакого провайдера/вебхука тут нет."""
    if tariff == SubscriptionTier.FREE:
        raise PaymentError("FREE тариф не требует оплаты", 400)

    amount_kzt = TIER_PRICE_TENGE.get(tariff.value)
    if amount_kzt is None:
        raise PaymentError(f"Цена для тарифа {tariff.value} не определена в конфигурации", 400)

    payment = Payment(
        user_id=user.id, provider="manual", tariff=tariff,
        amount_kzt=amount_kzt, status=PaymentStatus.PENDING,
    )
    db.add(payment)
    await db.commit()
    await db.refresh(payment)
    return payment


async def list_user_payments(db: AsyncSession, user_id: str) -> list[Payment]:
    result = await db.execute(
        select(Payment).where(Payment.user_id == user_id).order_by(Payment.created_at.desc())
    )
    return list(result.scalars().all())


async def list_manual_payments(db: AsyncSession, only_pending: bool = True) -> list[tuple[Payment, str]]:
    """Для Консоли разработчика: платежи с provider="manual", вместе с
    email плательщика (чтобы не искать пользователя отдельно)."""
    query = select(Payment, User.email).join(User, User.id == Payment.user_id).where(Payment.provider == "manual")
    if only_pending:
        query = query.where(Payment.status == PaymentStatus.PENDING)
    query = query.order_by(Payment.created_at.desc())
    result = await db.execute(query)
    return [(row[0], row[1]) for row in result.all()]


async def get_payment_or_404(db: AsyncSession, payment_id: str) -> Payment:
    result = await db.execute(select(Payment).where(Payment.id == payment_id))
    payment = result.scalar_one_or_none()
    if payment is None:
        raise PaymentError("Платёж не найден", 404)
    return payment


async def confirm_manual_payment(db: AsyncSession, payment: Payment, actor: User) -> Payment:
    if payment.provider != "manual":
        raise PaymentError("Это не ручной платёж — подтверждается только через webhook провайдера", 400)
    if payment.status == PaymentStatus.SUCCEEDED:
        return payment  # идемпотентно: повторное нажатие "Подтвердить" не начисляет баланс дважды

    payment.status = PaymentStatus.SUCCEEDED
    payment.external_payment_id = f"manual-{payment.id}"
    await db.commit()

    await _activate_tariff(db, payment)
    await record_audit_event(
        db, "payment_manual_confirmed", actor_id=actor.id, target_id=payment.id,
        tariff=payment.tariff.value, amount_kzt=payment.amount_kzt,
    )
    return payment


async def reject_manual_payment(db: AsyncSession, payment: Payment, actor: User) -> Payment:
    if payment.provider != "manual":
        raise PaymentError("Это не ручной платёж", 400)
    if payment.status != PaymentStatus.SUCCEEDED:
        payment.status = PaymentStatus.FAILED
        await db.commit()
    await record_audit_event(db, "payment_manual_rejected", actor_id=actor.id, target_id=payment.id)
    return payment


async def process_webhook(db: AsyncSession, provider_name: str, headers: dict, raw_body: bytes) -> dict:
    provider = get_provider(provider_name)

    try:
        event: WebhookEvent = provider.verify_and_parse_webhook(headers, raw_body)
    except WebhookSignatureError as e:
        logger.warning("Webhook с неверной подписью: provider=%s", provider_name)
        raise PaymentError(str(e), 401) from e
    except PaymentConfigurationError as e:
        raise PaymentError(str(e), 503) from e
    except NotImplementedError as e:  # audit-allow: честный 501 при неподтверждённом формате webhook провайдера
        raise PaymentError(str(e), 501) from e

    result = await db.execute(
        select(Payment).where(Payment.external_payment_id == event.external_payment_id)
    )
    payment = result.scalar_one_or_none()

    if payment is None:
        # Провайдер прислал webhook для платежа, которого мы не создавали
        # через /checkout (либо external_payment_id не был сопоставлен при
        # создании) — логируем как orphan-событие и отклоняем.
        db.add(
            PaymentEvent(
                payment_id=None,
                provider=provider_name,
                event_type="orphan_webhook",
                payload=event.raw_payload,
            )
        )
        await db.commit()
        raise PaymentError("Платёж не найден для данного external_payment_id", 404)

    db.add(
        PaymentEvent(
            payment_id=payment.id,
            provider=provider_name,
            event_type=event.status,
            payload=event.raw_payload,
        )
    )
    await db.commit()

    if payment.status == PaymentStatus.SUCCEEDED:
        # Идемпотентность: повторный webhook по уже обработанному платежу.
        logger.info("Повторный webhook по уже обработанному платежу: payment_id=%s", payment.id)
        return {"status": "already_processed", "payment_id": payment.id}

    if event.status != "succeeded":
        payment.status = PaymentStatus.FAILED if event.status == "failed" else PaymentStatus.REFUNDED
        await db.commit()
        if payment.status == PaymentStatus.FAILED:
            from app.core.security_events import check_payment_failed_spike

            user_result = await db.execute(select(User).where(User.id == payment.user_id))
            user = user_result.scalar_one_or_none()
            if user:
                await check_payment_failed_spike(db, user)
        return {"status": payment.status.value, "payment_id": payment.id}

    if event.amount_kzt != payment.amount_kzt:
        raise PaymentError(
            f"Сумма webhook ({event.amount_kzt}) не совпадает с ожидаемой ({payment.amount_kzt})", 400
        )

    payment.status = PaymentStatus.SUCCEEDED
    payment.external_payment_id = event.external_payment_id
    await db.commit()

    await _activate_tariff(db, payment)

    await record_audit_event(
        db, "payment_succeeded", actor_id=payment.user_id, target_id=payment.id,
        provider=provider_name, tariff=payment.tariff.value, amount_kzt=payment.amount_kzt,
    )

    return {"status": "succeeded", "payment_id": payment.id}


async def _activate_tariff(db: AsyncSession, payment: Payment) -> None:
    """
    Активирует оплаченный тариф: обновляет subscription_tier и token_limit,
    начисляет полный баланс нового тарифа (ТЗ раздел 11, п.6-7).
    """
    result = await db.execute(select(User).where(User.id == payment.user_id))
    user = result.scalar_one_or_none()
    if user is None:
        logger.error("Пользователь не найден при активации тарифа: user_id=%s", payment.user_id)
        return

    new_limit = TOKEN_LIMITS.get(payment.tariff.value, TOKEN_LIMITS["free"])
    user.subscription_tier = payment.tariff
    user.token_limit = new_limit
    user.token_balance = new_limit
    user.critical_recovery_started_at = None
    await db.commit()

    logger.info("Тариф активирован: user_id=%s tariff=%s", user.id, payment.tariff.value)
