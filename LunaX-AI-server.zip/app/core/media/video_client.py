"""
Генерация видео: prompt -> сцены -> кадры -> сборка (ТЗ раздел 5).
Format — как у image_client.py: OpenAI-совместимый контракт, не сверен
с конкретным self-hosted video-сервером (его ещё нет). Provider отсутствует
— НЕ подделываю рабочий provider, только интерфейс.
"""
import base64

import httpx

from app.config.settings import get_settings
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("video_client")


class VideoGenerationNotConfiguredError(Exception):
    pass


class VideoGenerationRequestError(Exception):
    pass


def _require_configured() -> None:
    if not settings.video_generation_enabled or not settings.self_hosted_video_base_url:
        raise VideoGenerationNotConfiguredError(
            "Генерация видео недоступна: video_generation_enabled=False "
            "или self_hosted_video_base_url не заполнен в .env"
        )


def _headers() -> dict:
    headers = {}
    if settings.self_hosted_video_api_key:
        headers["Authorization"] = f"Bearer {settings.self_hosted_video_api_key}"
    return headers


async def generate_video(prompt: str, duration_seconds: float = 5.0) -> bytes:
    """Генерация видео по текстовому промпту. Возвращает байты видеофайла (MP4)."""
    _require_configured()

    base_url = settings.self_hosted_video_base_url.rstrip("/")
    payload = {
        "model": settings.self_hosted_video_model_name,
        "prompt": prompt,
        "duration_seconds": duration_seconds,
        "response_format": "b64_json",
    }

    async with httpx.AsyncClient(timeout=settings.ai_request_timeout_seconds) as client:
        try:
            resp = await client.post(f"{base_url}/videos/generations", headers=_headers(), json=payload)
            resp.raise_for_status()
        except httpx.HTTPError as e:
            logger.exception("Ошибка video-сервера")
            raise VideoGenerationRequestError(
                f"Video-сервер недоступен или вернул ошибку: {e.__class__.__name__}"
            ) from e

    body = resp.json()
    data = body.get("data")
    if not data or "b64_json" not in data[0]:
        raise VideoGenerationRequestError(
            "Video-сервер ответил без ожидаемого поля data[0].b64_json — формат не совпадает"
        )
    return base64.b64decode(data[0]["b64_json"])
