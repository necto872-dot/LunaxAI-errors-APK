"""Генерация музыки/песен через self-hosted сервер. Тот же паттерн, что image/video."""
import base64

import httpx

from app.config.settings import get_settings
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("music_client")


class MusicGenerationNotConfiguredError(Exception):
    pass


class MusicGenerationRequestError(Exception):
    pass


def _require_configured() -> None:
    if not settings.music_generation_enabled or not settings.self_hosted_music_base_url:
        raise MusicGenerationNotConfiguredError(
            "Генерация музыки недоступна: music_generation_enabled=False "
            "или self_hosted_music_base_url не заполнен в .env"
        )


def _headers() -> dict:
    headers = {}
    if settings.self_hosted_music_api_key:
        headers["Authorization"] = f"Bearer {settings.self_hosted_music_api_key}"
    return headers


async def generate_song(lyrics: str, genre: str, mood: str, pitch_hint_hz: float | None = None) -> bytes:
    """Возвращает готовый аудиофайл (MP3/WAV, зависит от сервера)."""
    _require_configured()
    base_url = settings.self_hosted_music_base_url.rstrip("/")
    payload = {
        "model": settings.self_hosted_music_model_name,
        "lyrics": lyrics,
        "genre": genre,
        "mood": mood,
        "pitch_hint_hz": pitch_hint_hz,
        "response_format": "b64_json",
    }
    async with httpx.AsyncClient(timeout=settings.ai_request_timeout_seconds) as client:
        try:
            resp = await client.post(f"{base_url}/music/generations", headers=_headers(), json=payload)
            resp.raise_for_status()
        except httpx.HTTPError as e:
            logger.exception("Ошибка music-сервера")
            raise MusicGenerationRequestError(f"Music-сервер недоступен: {e.__class__.__name__}") from e

    body = resp.json()
    data = body.get("data")
    if not data or "b64_json" not in data[0]:
        raise MusicGenerationRequestError("Music-сервер ответил без data[0].b64_json")
    return base64.b64decode(data[0]["b64_json"])
