"""
Генерация изображений через self-hosted инференс-сервер (тот же принцип,
что и текст/голос — никаких платных внешних API).

Формат — OpenAI-совместимый /v1/images/generations. Реальные self-hosted
image-серверы (Stable Diffusion WebUI, ComfyUI) обычно требуют
собственный адаптер/прокси для этого конкретного формата — честно: этот
клиент написан под OpenAI-совместимый контракт как наиболее переносимый
вариант, но НЕ сверен с конкретным продакшн-сервером владельца (его ещё
не существует). При реальном деплое возможно потребуется адаптация под
нативный API вашего конкретного image-сервера.
"""
import base64

import httpx

from app.config.settings import get_settings
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("image_client")


class ImageGenerationNotConfiguredError(Exception):
    pass


class ImageGenerationRequestError(Exception):
    pass


def _require_configured() -> None:
    if not settings.image_generation_enabled or not settings.self_hosted_image_base_url:
        raise ImageGenerationNotConfiguredError(
            "Генерация изображений недоступна: image_generation_enabled=False "
            "или self_hosted_image_base_url не заполнен в .env"
        )


def _headers() -> dict:
    headers = {}
    if settings.self_hosted_image_api_key:
        headers["Authorization"] = f"Bearer {settings.self_hosted_image_api_key}"
    return headers


async def generate_image(prompt: str) -> bytes:
    """Генерация изображения по текстовому промпту. Возвращает PNG/JPEG-байты."""
    _require_configured()

    base_url = settings.self_hosted_image_base_url.rstrip("/")
    payload = {
        "model": settings.self_hosted_image_model_name,
        "prompt": prompt,
        "response_format": "b64_json",
    }

    async with httpx.AsyncClient(timeout=settings.ai_request_timeout_seconds) as client:
        try:
            resp = await client.post(f"{base_url}/images/generations", headers=_headers(), json=payload)
            resp.raise_for_status()
        except httpx.HTTPError as e:
            logger.exception("Ошибка image-сервера")
            raise ImageGenerationRequestError(
                f"Image-сервер недоступен или вернул ошибку: {e.__class__.__name__}"
            ) from e

    body = resp.json()
    data = body.get("data")
    if not data or "b64_json" not in data[0]:
        raise ImageGenerationRequestError(
            "Image-сервер ответил без ожидаемого поля data[0].b64_json — формат ответа не совпадает"
        )
    return base64.b64decode(data[0]["b64_json"])
