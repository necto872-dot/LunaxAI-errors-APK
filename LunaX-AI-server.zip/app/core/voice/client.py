"""
Голос: STT/TTS через self-hosted инференс-сервер (тот же принцип, что и
app/core/ai/providers.py — никаких платных внешних API, только
собственный сервер владельца).

Формат — OpenAI-совместимые эндпоинты /v1/audio/transcriptions (STT) и
/v1/audio/speech (TTS). Это распространённый target совместимости для
self-hosted Whisper/TTS-серверов (whisper-asr-webservice, faster-whisper-
server и т.п.), но НЕ гарантия 1-в-1 совместимости с любым конкретным
сервером — честно: этот формат не сверен с конкретным продакшн-сервером
владельца (его ещё не существует), сверьте при реальном деплое.
"""
import httpx

from app.config.settings import get_settings
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("voice_client")


class VoiceNotConfiguredError(Exception):
    """settings.voice_enabled=False или self_hosted_stt/tts_base_url не заполнены."""


class VoiceRequestError(Exception):
    """Self-hosted сервер вернул ошибку или не ответил."""


def _require_stt_configured() -> None:
    if not settings.voice_enabled or not settings.self_hosted_stt_base_url:
        raise VoiceNotConfiguredError(
            "STT недоступен: voice_enabled=False или self_hosted_stt_base_url не заполнен в .env"
        )


def _require_tts_configured() -> None:
    if not settings.voice_enabled or not settings.self_hosted_tts_base_url:
        raise VoiceNotConfiguredError(
            "TTS недоступен: voice_enabled=False или self_hosted_tts_base_url не заполнен в .env"
        )


def _headers() -> dict:
    headers = {}
    if settings.self_hosted_voice_api_key:
        headers["Authorization"] = f"Bearer {settings.self_hosted_voice_api_key}"
    return headers


async def transcribe_audio(audio_bytes: bytes, filename: str, content_type: str) -> str:
    """STT: аудио -> текст. Бросает VoiceNotConfiguredError/VoiceRequestError, не подделывает результат."""
    _require_stt_configured()

    base_url = settings.self_hosted_stt_base_url.rstrip("/")
    files = {"file": (filename, audio_bytes, content_type or "application/octet-stream")}
    data = {"model": settings.self_hosted_stt_model_name}

    async with httpx.AsyncClient(timeout=settings.ai_request_timeout_seconds) as client:
        try:
            resp = await client.post(f"{base_url}/audio/transcriptions", headers=_headers(), files=files, data=data)
            resp.raise_for_status()
        except httpx.HTTPError as e:
            logger.exception("Ошибка STT-сервера")
            raise VoiceRequestError(f"STT-сервер недоступен или вернул ошибку: {e.__class__.__name__}") from e

    body = resp.json()
    text = body.get("text")
    if text is None:
        raise VoiceRequestError("STT-сервер ответил без поля 'text' — формат ответа не совпадает с ожидаемым")
    return text


async def synthesize_speech(text: str) -> bytes:
    """TTS: текст -> аудио (байты, обычно MP3/WAV — зависит от сервера)."""
    _require_tts_configured()

    base_url = settings.self_hosted_tts_base_url.rstrip("/")
    payload = {
        "model": settings.self_hosted_tts_model_name,
        "input": text,
        "voice": settings.self_hosted_tts_voice,
    }

    async with httpx.AsyncClient(timeout=settings.ai_request_timeout_seconds) as client:
        try:
            resp = await client.post(f"{base_url}/audio/speech", headers=_headers(), json=payload)
            resp.raise_for_status()
        except httpx.HTTPError as e:
            logger.exception("Ошибка TTS-сервера")
            raise VoiceRequestError(f"TTS-сервер недоступен или вернул ошибку: {e.__class__.__name__}") from e

    return resp.content
