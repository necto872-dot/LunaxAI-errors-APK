"""
Определение высоты голоса (F0) по WAV-файлу. Автокорреляция на чистом
Python, только stdlib (wave, array) — без numpy/librosa. Работает
медленнее, чем numpy-версия, но реально считает, не выдумывает число.
"""
import array
import wave
from io import BytesIO


class PitchAnalysisError(Exception):
    pass


def _read_wav_samples(wav_bytes: bytes) -> tuple[list[int], int]:
    try:
        with wave.open(BytesIO(wav_bytes), "rb") as wf:
            n_channels = wf.getnchannels()
            sample_width = wf.getsampwidth()
            frame_rate = wf.getframerate()
            raw = wf.readframes(wf.getnframes())
    except wave.Error as e:
        raise PitchAnalysisError(f"Не удалось прочитать WAV: {e}") from e

    if sample_width != 2:
        raise PitchAnalysisError("Поддерживается только 16-bit PCM WAV")

    samples = array.array("h")
    samples.frombytes(raw)
    if n_channels == 2:
        samples = array.array("h", samples[::2])  # берём только левый канал
    return list(samples), frame_rate


def _autocorrelate_pitch(samples: list[int], sample_rate: int, min_hz: float = 60, max_hz: float = 500) -> float | None:
    n = len(samples)
    if n < sample_rate // 10:
        return None

    min_lag = int(sample_rate / max_hz)
    max_lag = int(sample_rate / min_hz)
    max_lag = min(max_lag, n - 1)

    best_lag, best_corr = 0, 0.0
    for lag in range(min_lag, max_lag):
        corr = sum(samples[i] * samples[i + lag] for i in range(0, n - lag, 4))  # шаг 4 для скорости
        if corr > best_corr:
            best_corr, best_lag = corr, lag

    if best_lag == 0:
        return None
    return sample_rate / best_lag


def analyze_pitch(wav_bytes: bytes) -> float | None:
    """Возвращает основную частоту голоса (Гц) или None, если не определить."""
    samples, rate = _read_wav_samples(wav_bytes)
    return _autocorrelate_pitch(samples, rate)
