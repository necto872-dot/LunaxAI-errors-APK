"""
Пошаговый флоу создания песни (ТЗ раздел 6-7). Состояние хранится в
SongSession, не в UI — сервер решает, что можно на каждом шаге.

Порядок: выбор текст/запись -> выбор голоса (свой/сгенерированный) ->
если свой: согласие -> сэмплы -> анализ высоты -> временный VoiceProfile
-> генерация. Голос пользователя никогда не используется без явного
согласия на этом шаге — сервис физически не даст перескочить стадию.
"""
from datetime import UTC, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.media.music_client import (
    MusicGenerationNotConfiguredError,
    MusicGenerationRequestError,
    generate_song,
)
from app.core.voice.pitch import PitchAnalysisError, analyze_pitch
from app.database.models import SongSession, SongSessionStage, User, VoiceProfile, _uuid

settings = get_settings()


class SongFlowError(Exception):
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


async def start_song_session(db: AsyncSession, user: User) -> SongSession:
    session = SongSession(owner_id=user.id)
    db.add(session)
    await db.commit()
    await db.refresh(session)
    return session


async def _get_owned_session(db: AsyncSession, user: User, session_id: str) -> SongSession:
    result = await db.execute(select(SongSession).where(SongSession.id == session_id))
    session = result.scalar_one_or_none()
    if session is None or session.owner_id != user.id:
        raise SongFlowError("Сессия не найдена", 404)
    return session


async def set_lyrics(db: AsyncSession, user: User, session_id: str, lyrics: str) -> SongSession:
    from app.core.safety import is_blocked

    if is_blocked(lyrics):
        raise SongFlowError("Текст песни отклонён политикой безопасности", 400)

    session = await _get_owned_session(db, user, session_id)
    if session.stage != SongSessionStage.AWAITING_LYRICS_OR_RECORDING_CHOICE:
        raise SongFlowError(f"Неверный шаг сессии: {session.stage.value}")
    session.lyrics = lyrics
    session.stage = SongSessionStage.AWAITING_VOICE_CHOICE
    await db.commit()
    await db.refresh(session)
    return session


async def choose_voice(db: AsyncSession, user: User, session_id: str, use_own_voice: bool) -> SongSession:
    session = await _get_owned_session(db, user, session_id)
    if session.stage != SongSessionStage.AWAITING_VOICE_CHOICE:
        raise SongFlowError(f"Неверный шаг сессии: {session.stage.value}")
    session.use_own_voice = use_own_voice
    session.stage = SongSessionStage.AWAITING_CONSENT if use_own_voice else SongSessionStage.READY
    await db.commit()
    await db.refresh(session)
    return session


async def give_consent(db: AsyncSession, user: User, session_id: str, consent: bool) -> SongSession:
    session = await _get_owned_session(db, user, session_id)
    if session.stage != SongSessionStage.AWAITING_CONSENT:
        raise SongFlowError(f"Неверный шаг сессии: {session.stage.value}")
    if not consent:
        raise SongFlowError("Без согласия использование вашего голоса невозможно", 403)
    session.stage = SongSessionStage.AWAITING_SAMPLES
    await db.commit()
    await db.refresh(session)
    return session


async def submit_voice_sample(db: AsyncSession, user: User, session_id: str, wav_bytes: bytes) -> SongSession:
    session = await _get_owned_session(db, user, session_id)
    if session.stage != SongSessionStage.AWAITING_SAMPLES:
        raise SongFlowError(f"Неверный шаг сессии: {session.stage.value}")

    try:
        pitch = analyze_pitch(wav_bytes)
    except PitchAnalysisError as e:
        raise SongFlowError(str(e), 422) from e
    if pitch is None:
        raise SongFlowError("Не удалось определить высоту голоса в записи, попробуйте ещё раз", 422)

    now = datetime.now(UTC)
    profile = VoiceProfile(
        id=_uuid(),
        owner_id=user.id,
        consent_given_at=now,
        pitch_low_hz=pitch * 0.85,
        pitch_high_hz=pitch * 1.3,
        expires_at=now + timedelta(minutes=settings.voice_profile_expire_minutes),
    )
    db.add(profile)
    session.voice_profile_id = profile.id
    session.stage = SongSessionStage.READY
    await db.commit()
    await db.refresh(session)
    return session


async def finalize_song(db: AsyncSession, user: User, session_id: str, genre: str, mood: str) -> bytes:
    session = await _get_owned_session(db, user, session_id)
    if session.stage != SongSessionStage.READY or not session.lyrics:
        raise SongFlowError(f"Сессия не готова: {session.stage.value}")

    pitch_hint = None
    if session.voice_profile_id:
        result = await db.execute(select(VoiceProfile).where(VoiceProfile.id == session.voice_profile_id))
        profile = result.scalar_one_or_none()
        if profile and profile.expires_at.replace(tzinfo=UTC) > datetime.now(UTC):
            pitch_hint = (profile.pitch_low_hz + profile.pitch_high_hz) / 2
        else:
            raise SongFlowError("Голосовой профиль истёк, начните заново", 410)

    try:
        return await generate_song(session.lyrics, genre, mood, pitch_hint)
    except (MusicGenerationNotConfiguredError, MusicGenerationRequestError) as e:
        raise SongFlowError(str(e), 503) from e
