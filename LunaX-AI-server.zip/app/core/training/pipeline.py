"""
Консоль обновления Lunox AI (Developer Console, только Primary Developer).

Тот же архитектурный паттерн, что и APK-сборка (app/core/build/apk.py):
интерфейс есть всегда, реальное тяжёлое исполнение (LoRA-обучение) идёт
через приоритетную очередь (app/core/queue.py), не блокируя HTTP-запрос,
и честно останавливается с понятной ошибкой, если GPU-инфраструктура
(training_pipeline_enabled) ещё не поднята — вместо того чтобы подделать
результат.

ГРАНИЦА ОТВЕТСТВЕННОСТИ (важно, см. предыдущее обсуждение с владельцем):
- Запустить прогон может ТОЛЬКО Primary Developer через
  POST /developer/training-runs (это единственная точка входа — ни у
  обычного пользователя, ни у самой модели нет доступа к этой функции).
- Пайплайн сам доходит только до EVAL_PASSED/EVAL_NEEDS_REVIEW.
- Деплой — либо ручной (Primary Developer сам переставляет модель и
  подтверждает через /deployed), либо, если self_hosted_supports_dynamic_lora
  включён (vLLM с рантайм-обновлением LoRA), automatic_deploy() пытается
  реально это сделать через /v1/load_lora_adapter — но опять же ТОЛЬКО по
  явному вызову Primary Developer (POST /training-runs/{id}/deploy), не
  сама по себе после eval.
"""
import asyncio
import json
import subprocess
from datetime import UTC, datetime
from pathlib import Path

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.logger import get_logger
from app.database.models import TrainingRun, TrainingRunStatus, User

settings = get_settings()
logger = get_logger("training_pipeline")

ROOT_DIR = Path(__file__).resolve().parent.parent.parent.parent


class TrainingPipelineError(Exception):
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


def _workspace_for(run_id: str) -> Path:
    workspace = Path(settings.training_workspace_dir) / run_id
    workspace.mkdir(parents=True, exist_ok=True)
    return workspace


async def _create_training_run(
    db: AsyncSession,
    actor: User,
    *,
    tier: str,
    max_conversations: int,
    epochs: int,
    submitted_examples: list[dict] | None,
) -> TrainingRun:
    for ex in submitted_examples or []:
        if not isinstance(ex, dict) or "user" not in ex or "assistant" not in ex:
            raise TrainingPipelineError(
                "submitted_examples: каждый элемент должен быть {'user': ..., 'assistant': ...}", 422
            )

    run = TrainingRun(
        status=TrainingRunStatus.QUEUED,
        triggered_by_id=actor.id,
        submitted_examples=submitted_examples or None,
        tier=tier,
        max_conversations=max_conversations,
        epochs=epochs,
    )
    db.add(run)
    await db.commit()
    await db.refresh(run)
    return run


async def enqueue_training_run(
    db: AsyncSession,
    actor: User,
    *,
    tier: str = "pro",
    max_conversations: int = 500,
    epochs: int = 3,
    submitted_examples: list[dict] | None = None,
) -> TrainingRun:
    """
    HTTP-путь для Консоли обновления. Создаёт TrainingRun и либо сразу
    честно проваливает его с 503 (нет GPU-сервера — не притворяемся, что
    обучение началось), либо ставит реальное выполнение в приоритетную
    очередь разработчика.
    """
    run = await _create_training_run(
        db, actor, tier=tier, max_conversations=max_conversations, epochs=epochs,
        submitted_examples=submitted_examples,
    )

    if not settings.training_pipeline_enabled:
        return await _execute_training_run(db, run)  # поднимет TrainingPipelineError(503)

    from app.core.queue import enqueue_priority_job

    rq_job_id = enqueue_priority_job(actor, run_training_job_sync, run.id)
    run.queue_job_id = rq_job_id
    await db.commit()
    await db.refresh(run)
    return run


async def _execute_training_run(db: AsyncSession, run: TrainingRun) -> TrainingRun:
    """Тело задачи: сбор -> подготовка -> обучение -> слияние -> самопроверка."""
    if not settings.training_pipeline_enabled:
        run.status = TrainingRunStatus.FAILED
        run.failure_reason = (
            "training_pipeline_enabled=False — нет GPU-сервера с training/requirements.txt. "
            "Можно прогнать вручную: python training/auto_pipeline.py (см. training/README.md)."
        )
        run.log = run.failure_reason
        await db.commit()
        raise TrainingPipelineError(run.failure_reason, 503)

    tier = run.tier
    max_conversations = run.max_conversations
    epochs = run.epochs

    workspace = _workspace_for(run.id)
    raw_path = workspace / "raw_conversations.json"
    dataset_path = workspace / "dataset.jsonl"
    adapter_dir = workspace / "lora-adapter"
    merged_dir = workspace / "merged-model"
    report_path = workspace / "eval_report.json"

    run.status = TrainingRunStatus.COLLECTING
    await db.commit()

    # 1. Собираем opt-in диалоги из БД тем же скриптом, что и CLI-путь.
    collect_result = await asyncio.to_thread(
        subprocess.run,
        ["python3", "training/collect_from_db.py", "--output", str(raw_path),
         "--max-conversations", str(max_conversations)],
        cwd=str(ROOT_DIR), capture_output=True, text=True, check=False,
    )
    run.log += f"\n=== collect_from_db ===\n{collect_result.stdout}{collect_result.stderr}"
    if collect_result.returncode != 0:
        run.status = TrainingRunStatus.FAILED
        run.failure_reason = "collect_from_db.py failed"
        await db.commit()
        raise TrainingPipelineError(run.failure_reason, 500)

    # 2. Примешиваем то, что разработчик прислал вручную через консоль
    # (код/примеры) — отдельно от согласия пользователей, это его
    # собственный явный ввод.
    pairs = json.loads(raw_path.read_text(encoding="utf-8"))
    if run.submitted_examples:
        pairs = list(run.submitted_examples) + pairs
    raw_path.write_text(json.dumps(pairs, ensure_ascii=False, indent=2), encoding="utf-8")

    if not pairs:
        run.status = TrainingRunStatus.FAILED
        run.failure_reason = "Нет данных для обучения: ни одного opt-in диалога и ни одного присланного примера"
        await db.commit()
        raise TrainingPipelineError(run.failure_reason, 422)

    run.dataset_size = len(pairs)
    await db.commit()

    # 3. prepare_dataset.py
    prepare_result = await asyncio.to_thread(
        subprocess.run,
        ["python3", "training/prepare_dataset.py", "--input", str(raw_path),
         "--output", str(dataset_path), "--inject-persona"],
        cwd=str(ROOT_DIR), capture_output=True, text=True, check=False,
    )
    run.log += f"\n=== prepare_dataset ===\n{prepare_result.stdout}{prepare_result.stderr}"
    if prepare_result.returncode != 0:
        run.status = TrainingRunStatus.FAILED
        run.failure_reason = "prepare_dataset.py failed"
        await db.commit()
        raise TrainingPipelineError(run.failure_reason, 500)

    # 4. LoRA-обучение (тяжёлый шаг, свой таймаут)
    run.status = TrainingRunStatus.TRAINING
    await db.commit()
    try:
        train_result = await asyncio.to_thread(
            subprocess.run,
            ["python3", "training/train_lora.py", "--tier", tier, "--dataset", str(dataset_path),
             "--output-dir", str(adapter_dir), "--epochs", str(epochs)],
            cwd=str(ROOT_DIR), capture_output=True, text=True, check=False,
            timeout=settings.training_pipeline_timeout_seconds,
        )
    except subprocess.TimeoutExpired as exc:
        run.status = TrainingRunStatus.FAILED
        run.failure_reason = f"Обучение превысило таймаут {settings.training_pipeline_timeout_seconds}с"
        await db.commit()
        raise TrainingPipelineError(run.failure_reason, 504) from exc

    run.log += f"\n=== train_lora ===\n{train_result.stdout[-5000:]}{train_result.stderr[-5000:]}"
    if train_result.returncode != 0:
        run.status = TrainingRunStatus.FAILED
        run.failure_reason = "train_lora.py failed"
        await db.commit()
        raise TrainingPipelineError(run.failure_reason, 500)

    # 5. Слияние
    from training.tier_configs import get_tier_config

    base_model = get_tier_config(tier)["base_model"]
    merge_result = await asyncio.to_thread(
        subprocess.run,
        ["python3", "training/merge_and_export.py", "--base-model", base_model,
         "--adapter", str(adapter_dir), "--output", str(merged_dir)],
        cwd=str(ROOT_DIR), capture_output=True, text=True, check=False,
    )
    run.log += f"\n=== merge_and_export ===\n{merge_result.stdout}{merge_result.stderr}"
    if merge_result.returncode != 0:
        run.status = TrainingRunStatus.FAILED
        run.failure_reason = "merge_and_export.py failed"
        await db.commit()
        raise TrainingPipelineError(run.failure_reason, 500)

    # 6. Самопроверка
    eval_result = await asyncio.to_thread(
        subprocess.run,
        ["python3", "training/eval_candidate.py", "--model-path", str(merged_dir), "--report", str(report_path)],
        cwd=str(ROOT_DIR), capture_output=True, text=True, check=False,
    )
    run.log += f"\n=== eval_candidate ===\n{eval_result.stdout}{eval_result.stderr}"

    eval_summary = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else None
    run.status = TrainingRunStatus.EVAL_PASSED if eval_result.returncode == 0 else TrainingRunStatus.EVAL_NEEDS_REVIEW
    run.adapter_path = str(merged_dir)
    run.eval_summary = eval_summary
    await db.commit()
    await db.refresh(run)
    return run


async def _run_training_job_async(run_id: str) -> dict:
    """Тело задачи очереди: своя сессия БД (воркер — отдельный процесс)."""
    from app.database import async_session_maker

    async with async_session_maker() as db:
        run = await db.get(TrainingRun, run_id)
        if run is None:
            raise TrainingPipelineError(f"TrainingRun {run_id} не найден в очереди-воркере", 404)
        try:
            await _execute_training_run(db, run)
        except TrainingPipelineError:
            pass  # статус/лог уже сохранены выше — воркеру достаточно пометить задачу failed в своём логе
        return {"run_id": run.id, "status": run.status.value}


def run_training_job_sync(run_id: str) -> dict:
    """Синхронная точка входа для RQ-воркера (та же схема, что run_apk_build_job_sync)."""
    from app.core.queue import run_coro_sync

    return run_coro_sync(_run_training_job_async(run_id))


async def attempt_automatic_deploy(run: TrainingRun) -> dict:
    """
    Лучшее из возможного автоматическое переключение модели в проде —
    БЕЗ рестарта процесса инференс-сервера — через рантайм-загрузку LoRA
    vLLM (эндпоинт /v1/load_lora_adapter, доступен только когда сервер
    запущен с VLLM_ALLOW_RUNTIME_LORA_UPDATING=True).

    ЧЕСТНОЕ ОГРАНИЧЕНИЕ: не проверялось на реальном vLLM в этом проходе
    (нет GPU/сети в sandbox) — эндпоинт и его формат соответствуют
    задокументированному API vLLM на момент написания, но версии vLLM
    меняются, сверьте с версией на вашем сервере перед тем как полагаться
    на это в проде. Ollama/TGI такого эндпоинта не имеют вообще — для них
    результат всегда "деплой вручную".
    """
    if not settings.self_hosted_supports_dynamic_lora:
        raise TrainingPipelineError(
            "self_hosted_supports_dynamic_lora=False — автоматический деплой недоступен для текущего "
            "инференс-сервера. Разверни модель вручную и подтверди через /training-runs/{id}/deployed.",
            503,
        )
    if not run.adapter_path:
        raise TrainingPipelineError("У этого прогона нет adapter_path — сначала дождись EVAL_PASSED", 409)

    lora_name = f"lunox-{run.id[:8]}"
    payload = {"lora_name": lora_name, "lora_path": run.adapter_path}

    try:
        async with httpx.AsyncClient(timeout=settings.ai_request_timeout_seconds) as client:
            resp = await client.post(
                f"{settings.self_hosted_base_url.rstrip('/')}/load_lora_adapter", json=payload
            )
    except httpx.HTTPError as exc:
        raise TrainingPipelineError(f"Не удалось обратиться к инференс-серверу: {exc}", 502) from exc

    if resp.status_code >= 400:
        raise TrainingPipelineError(
            f"Инференс-сервер отклонил загрузку адаптера ({resp.status_code}): {resp.text[:500]}", 502
        )

    return {"lora_name": lora_name, "lora_path": run.adapter_path, "deployed_at": datetime.now(UTC).isoformat()}
