"""
Детекция подозрительной активности -> SecurityEvent (раздел "Отчёты" в
Консоли разработчика). Детекторы:
- login_failure_burst — серия неудачных логинов по email (из audit_logs);
- new_ip_after_credential_change — вход с нового IP вскоре после смены
  пароля/email (типичный маркер захвата аккаунта);
- token_burn_spike — резкий расход токенов за короткое окно (in-memory,
  как rate_limit.py — один процесс, не кросс-воркерный);
- rate_limit_abuse — один и тот же ключ (bucket:ip) упирается в лимит
  повторно (вызывается из app/core/rate_limit.py).

Пороги — technical defaults, не согласованное бизнес-решение, как и
остальные settings.security_*/rate_limit_*.
"""
import time
from collections import defaultdict
from datetime import UTC, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.email import EmailSendError, send_email
from app.core.geoip import lookup_geoip
from app.core.logger import get_logger
from app.core.telegram import TelegramSendError, send_telegram
from app.database.models import AuditLog, SecurityEvent, SecurityEventSeverity, User, UserRole

settings = get_settings()
logger = get_logger("security_events")


async def _has_open_event(
    db: AsyncSession, event_type: str, email: str | None = None, ip_address: str | None = None
) -> bool:
    """Не создавать дубль, пока предыдущий такого же типа/email/ip не resolved."""
    query = select(SecurityEvent).where(
        SecurityEvent.event_type == event_type, SecurityEvent.resolved.is_(False)
    )
    if email is not None:
        query = query.where(SecurityEvent.email == email)
    if ip_address is not None:
        query = query.where(SecurityEvent.ip_address == ip_address)
    result = await db.execute(query)
    return result.scalar_one_or_none() is not None


async def notify_primary_developers(db: AsyncSession, event: SecurityEvent) -> None:
    """Best-effort email/Telegram всем PRIMARY_DEVELOPER при HIGH-событии. Никогда не
    роняет вызывающий поток — ошибка отправки только логируется."""
    if event.severity != SecurityEventSeverity.HIGH:
        return
    result = await db.execute(select(User).where(User.role == UserRole.PRIMARY_DEVELOPER))
    recipients = list(result.scalars())
    body = f"Тип: {event.event_type}\nEmail: {event.email}\nIP: {event.ip_address}\nДетали: {event.details}"

    if settings.security_notify_email_enabled:
        for u in recipients:
            try:
                send_email(u.email, f"[LunaX AI] Security alert: {event.event_type}", f"<pre>{body}</pre>", body)
            except EmailSendError as e:
                logger.warning("Не удалось отправить security-уведомление на %s: %s", u.email, e)

    if settings.security_notify_telegram_enabled and settings.telegram_bot_token:
        for u in recipients:
            if not u.telegram_chat_id:
                continue
            try:
                await send_telegram(u.telegram_chat_id, f"🚨 LunaX AI security alert\n\n{body}")
            except TelegramSendError as e:
                logger.warning("Не удалось отправить Telegram-уведомление user_id=%s: %s", u.id, e)

    if settings.push_notify_enabled and settings.fcm_project_id:
        from app.core.push import PushSendError, send_push
        from app.database.models import PushDevice

        recipient_ids = [u.id for u in recipients]
        if recipient_ids:
            devices_result = await db.execute(select(PushDevice).where(PushDevice.user_id.in_(recipient_ids)))
            for device in devices_result.scalars():
                try:
                    await send_push(
                        device.fcm_token, f"Security alert: {event.event_type}",
                        f"{event.email or event.ip_address or ''}".strip() or "Открой консоль",
                        data={"event_id": event.id, "event_type": event.event_type},
                    )
                except PushSendError as e:
                    logger.warning("Не удалось отправить push device_id=%s: %s", device.id, e)


async def record_security_event(
    db: AsyncSession,
    event_type: str,
    severity: SecurityEventSeverity = SecurityEventSeverity.LOW,
    email: str | None = None,
    ip_address: str | None = None,
    **details,
) -> SecurityEvent:
    if ip_address:
        geo = await lookup_geoip(ip_address)
        if geo:
            details["geo"] = geo
    event = SecurityEvent(
        event_type=event_type, severity=severity, email=email, ip_address=ip_address, details=details or None
    )
    db.add(event)
    await db.commit()
    await db.refresh(event)
    await notify_primary_developers(db, event)
    if severity == SecurityEventSeverity.HIGH:
        await _check_auto_actions(db, event)
    return event


async def _check_auto_actions(db: AsyncSession, event: SecurityEvent) -> None:
    """Реакция на угрозы: N HIGH-событий подряд по email -> временный бан
    аккаунта + отзыв всех его сессий; N HIGH-событий подряд по IP ->
    временная блокировка IP. Только детект->действие, без ручного шага.
    Best-effort: ошибка здесь не должна ронять вызывающий поток."""
    from app.core.audit import record_audit_event
    from app.core.ip_blocklist import block_ip

    window_start = datetime.now(UTC) - timedelta(minutes=settings.security_auto_action_window_minutes)

    try:
        if event.email:
            result = await db.execute(
                select(SecurityEvent).where(
                    SecurityEvent.email == event.email,
                    SecurityEvent.severity == SecurityEventSeverity.HIGH,
                    SecurityEvent.created_at >= window_start,
                )
            )
            count = len(list(result.scalars()))
            if count >= settings.security_auto_ban_high_threshold:
                user_result = await db.execute(select(User).where(User.email == event.email))
                user = user_result.scalar_one_or_none()
                if user and user.role not in (UserRole.PRIMARY_DEVELOPER,) and (
                    user.banned_until is None or _aware(user.banned_until) < datetime.now(UTC)
                ):
                    until = datetime.now(UTC) + timedelta(minutes=settings.security_auto_ban_duration_minutes)
                    user.banned_until = until
                    user.banned_reason = f"auto: {count}x HIGH events ({event.event_type})"
                    user.session_revoked_before = datetime.now(UTC)
                    await db.commit()
                    await record_audit_event(
                        db, "auto_temp_ban", target_id=user.id,
                        until=until.isoformat(), triggering_event_type=event.event_type, count=count,
                    )
                    logger.warning("Авто-бан user_id=%s до %s (%s HIGH-событий)", user.id, until, count)

        if event.ip_address:
            result = await db.execute(
                select(SecurityEvent).where(
                    SecurityEvent.ip_address == event.ip_address,
                    SecurityEvent.severity == SecurityEventSeverity.HIGH,
                    SecurityEvent.created_at >= window_start,
                )
            )
            count = len(list(result.scalars()))
            if count >= settings.security_auto_block_ip_high_threshold:
                await block_ip(
                    db, event.ip_address,
                    reason=f"auto: {count}x HIGH events ({event.event_type})",
                    minutes=settings.security_auto_block_ip_duration_minutes,
                )
                await record_audit_event(
                    db, "auto_ip_block", ip=event.ip_address,
                    triggering_event_type=event.event_type, count=count,
                )
                logger.warning("Авто-блок IP=%s (%s HIGH-событий)", event.ip_address, count)
    except Exception:  # noqa: BLE001 — авто-действие не должно ронять запрос, который его вызвал
        logger.exception("Ошибка авто-реакции на HIGH security event %s", event.id)


def _aware(dt: datetime) -> datetime:
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=UTC)


async def expire_stale_events(db: AsyncSession) -> int:
    """Лениво закрывает открытые события старше settings.security_event_ttl_days
    (нет scheduler'а в проекте — тот же паттерн, что app/core/quota.py).
    Вызывается при чтении списка отчётов, не по расписанию."""
    cutoff = datetime.now(UTC) - timedelta(days=settings.security_event_ttl_days)
    result = await db.execute(
        select(SecurityEvent).where(SecurityEvent.resolved.is_(False), SecurityEvent.created_at < cutoff)
    )
    stale = list(result.scalars())
    for event in stale:
        event.resolved = True
        event.resolved_at = datetime.now(UTC)
        event.details = {**(event.details or {}), "auto_expired": True}
    if stale:
        await db.commit()
    return len(stale)


async def check_mass_registration(db: AsyncSession, ip_address: str | None) -> SecurityEvent | None:
    """N регистраций с одного IP за окно — антифрод register (audit_logs
    event=user_registered, details.ip проставляется в auth/routers.py)."""
    if ip_address is None:
        return None
    window_start = datetime.now(UTC) - timedelta(minutes=settings.security_mass_registration_window_minutes)
    result = await db.execute(
        select(AuditLog).where(AuditLog.event == "user_registered", AuditLog.created_at >= window_start)
    )
    count = sum(1 for row in result.scalars() if (row.details or {}).get("ip") == ip_address)
    if count < settings.security_mass_registration_threshold:
        return None
    if await _has_open_event(db, "mass_registration_same_ip", ip_address=ip_address):
        return None
    return await record_security_event(
        db, "mass_registration_same_ip", severity=SecurityEventSeverity.HIGH, ip_address=ip_address,
        registrations_in_window=count, window_minutes=settings.security_mass_registration_window_minutes,
    )


async def check_payment_failed_spike(db: AsyncSession, user: User) -> SecurityEvent | None:
    """N payment-failed подряд у одного юзера за окно — тот же паттерн, что
    карточный фрод (app/modules/payments/services.py:process_webhook)."""
    from app.database.models import Payment, PaymentStatus  # локальный импорт во избежание циклов

    window_start = datetime.now(UTC) - timedelta(minutes=settings.security_payment_failure_window_minutes)
    result = await db.execute(
        select(Payment).where(
            Payment.user_id == user.id, Payment.status == PaymentStatus.FAILED, Payment.created_at >= window_start,
        )
    )
    count = len(list(result.scalars()))
    if count < settings.security_payment_failure_threshold:
        return None
    if await _has_open_event(db, "payment_failure_spike", email=user.email):
        return None
    return await record_security_event(
        db, "payment_failure_spike", severity=SecurityEventSeverity.HIGH, email=user.email,
        failures_in_window=count, window_minutes=settings.security_payment_failure_window_minutes,
    )


async def check_login_failure_burst(db: AsyncSession, email: str, ip_address: str | None) -> SecurityEvent | None:
    """Считает login_failed в audit_logs за окно по email (Python-фильтр —
    details это общий JSON-столбец, а не колонка email; кросс-диалектный
    JSON-путь тут был бы хрупче полной выборки за короткое окно)."""
    window_start = datetime.now(UTC) - timedelta(minutes=settings.security_login_failure_window_minutes)
    result = await db.execute(
        select(AuditLog).where(AuditLog.event == "login_failed", AuditLog.created_at >= window_start)
    )
    failures = sum(1 for row in result.scalars() if (row.details or {}).get("email") == email)
    if failures < settings.security_login_failure_threshold:
        return None
    if await _has_open_event(db, "login_failure_burst", email):
        return None
    return await record_security_event(
        db, "login_failure_burst", severity=SecurityEventSeverity.HIGH, email=email, ip_address=ip_address,
        failures=failures, window_minutes=settings.security_login_failure_window_minutes,
    )


async def check_new_ip_after_credential_change(
    db: AsyncSession, user: User, ip_address: str | None
) -> SecurityEvent | None:
    """После смены пароля/email вход с IP, отличного от last_login_ip, —
    возможный маркер захвата аккаунта. Смотрит password_reset_completed/
    email_change_confirmed за последние 24ч в audit_logs."""
    if ip_address is None or user.last_login_ip is None or ip_address == user.last_login_ip:
        return None
    window_start = datetime.now(UTC) - timedelta(hours=24)
    result = await db.execute(
        select(AuditLog).where(
            AuditLog.event.in_(["password_reset_completed", "email_change_confirmed"]),
            AuditLog.actor_id == user.id,
            AuditLog.created_at >= window_start,
        )
    )
    if result.scalars().first() is None:
        return None
    if await _has_open_event(db, "new_ip_after_credential_change", user.email):
        return None
    return await record_security_event(
        db, "new_ip_after_credential_change", severity=SecurityEventSeverity.HIGH,
        email=user.email, ip_address=ip_address, previous_ip=user.last_login_ip,
    )


# In-memory окно расхода токенов на пользователя: user_id -> [(ts, amount)].
# Как и rate_limit._hits — один процесс, не переживает рестарт/несколько воркеров.
_token_spend_window: dict[str, list[tuple[float, int]]] = defaultdict(list)


async def check_token_burn_spike(db: AsyncSession, user: User, spent_amount: int) -> SecurityEvent | None:
    """Если пользователь сжигает > threshold% своего token_limit за короткое
    окно — похоже на угнанный аккаунт/скрипт, а не на обычное использование."""
    now = time.monotonic()
    window_start = now - settings.security_token_burn_window_minutes * 60
    hits = _token_spend_window[user.id]
    hits[:] = [(t, a) for t, a in hits if t >= window_start]
    hits.append((now, spent_amount))
    total = sum(a for _, a in hits)

    if user.token_limit <= 0 or total * 100 / user.token_limit < settings.security_token_burn_threshold_percent:
        return None
    if await _has_open_event(db, "token_burn_spike", user.email):
        return None
    return await record_security_event(
        db, "token_burn_spike", severity=SecurityEventSeverity.MEDIUM, email=user.email,
        spent_in_window=total, window_minutes=settings.security_token_burn_window_minutes,
    )


# То же самое для повторного упирания в rate limit одним и тем же ключом.
_rate_limit_hits: dict[str, list[float]] = defaultdict(list)


async def check_rate_limit_abuse(db: AsyncSession, bucket: str, ip_address: str) -> SecurityEvent | None:
    """Вызывается из app/core/rate_limit.py при каждом 429. Если один и тот
    же bucket:ip упёрся в лимит несколько раз за окно — репорт в консоль."""
    key = f"{bucket}:{ip_address}"
    now = time.monotonic()
    window_start = now - settings.security_rate_limit_abuse_window_minutes * 60
    hits = _rate_limit_hits[key]
    hits[:] = [t for t in hits if t >= window_start]
    hits.append(now)

    if len(hits) < settings.security_rate_limit_abuse_threshold:
        return None
    if await _has_open_event(db, "rate_limit_abuse", ip_address=ip_address):
        return None
    return await record_security_event(
        db, "rate_limit_abuse", severity=SecurityEventSeverity.MEDIUM,
        ip_address=ip_address, bucket=bucket, hits_in_window=len(hits),
    )
