"""
Слэш-команды Консоли разработчика (выдача роли/привилегии, начисление
токенов, массовый розыгрыш токенов). Текстовый ввод -> одна из этих
функций, каждая коммитит сама и возвращает dict для аудит-лога + ответа
API. Доступ к самому эндпоинту — только require_primary_developer (см.
routers.py), это не отдельный уровень прав внутри команд.

Primary Developer через эти команды назначить/снять нельзя (ТЗ п.6/п.15/
п.33) — только scripts/manage_primary.py на сервере.
"""
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.ip_blocklist import block_ip, unblock_ip
from app.database.models import User, UserRole
from app.modules.auth.services import AuthError, get_user_by_email

_GRANTABLE_ROLES = {r.value for r in UserRole if r != UserRole.PRIMARY_DEVELOPER}


class ConsoleCommandError(AuthError):
    pass


async def _get_target(db: AsyncSession, email: str) -> User:
    user = await get_user_by_email(db, email)
    if user is None:
        raise ConsoleCommandError(f"Пользователь {email} не найден", 404)
    if user.role == UserRole.PRIMARY_DEVELOPER:
        raise ConsoleCommandError("Primary Developer нельзя изменить через консоль", 403)
    return user


async def grant_privilege(db: AsyncSession, email: str, role: str) -> dict:
    """/priv <email> <role> — role: user|premium|developer|admin."""
    role = role.lower()
    if role not in _GRANTABLE_ROLES:
        raise ConsoleCommandError(
            f"Неизвестная роль '{role}'. Доступно: {', '.join(sorted(_GRANTABLE_ROLES))}", 400
        )
    user = await _get_target(db, email)
    previous = user.role.value
    user.role = UserRole(role)
    await db.commit()
    await db.refresh(user)
    return {"command": "priv", "email": email, "previous_role": previous, "new_role": role}


async def grant_tokens(db: AsyncSession, email: str, amount: int) -> dict:
    """/tokens <email> <amount> — прибавляет amount к балансу (может быть
    отрицательным, чтобы списать); если баланс превысит лимит, лимит
    поднимается вместе с ним, иначе начисление было бы бесполезным."""
    user = await _get_target(db, email)
    user.token_balance = max(0, user.token_balance + amount)
    if user.token_balance > user.token_limit:
        user.token_limit = user.token_balance
    await db.commit()
    await db.refresh(user)
    return {"command": "tokens", "email": email, "delta": amount, "new_balance": user.token_balance}


async def run_giveaway(db: AsyncSession, amount: int, role: str = "all") -> dict:
    """/giveaway <amount> [role] — начисляет amount всем активным
    пользователям (role="all") или только выбранной роли."""
    if amount == 0:
        raise ConsoleCommandError("amount не может быть 0", 400)
    query = select(User).where(User.is_active.is_(True))
    role = role.lower()
    if role != "all":
        if role not in _GRANTABLE_ROLES:
            raise ConsoleCommandError(f"Неизвестная роль '{role}'", 400)
        query = query.where(User.role == UserRole(role))
    result = await db.execute(query)
    users = list(result.scalars().all())
    for user in users:
        user.token_balance = max(0, user.token_balance + amount)
        if user.token_balance > user.token_limit:
            user.token_limit = user.token_balance
    await db.commit()
    return {"command": "giveaway", "role": role, "amount": amount, "users_affected": len(users)}


async def ban_user(db: AsyncSession, email: str) -> dict:
    """/ban <email> — деактивирует аккаунт (алиас на is_active=False)."""
    user = await _get_target(db, email)
    user.is_active = False
    await db.commit()
    return {"command": "ban", "email": email, "is_active": False}


async def unban_user(db: AsyncSession, email: str) -> dict:
    """/unban <email>"""
    user = await _get_target(db, email)
    user.is_active = True
    await db.commit()
    return {"command": "unban", "email": email, "is_active": True}


async def revoke_sessions(db: AsyncSession, email: str) -> dict:
    """/revoke-sessions <email> — все выданные ранее JWT (access и refresh)
    этого пользователя мгновенно перестают приниматься (см.
    auth/dependencies.py:get_current_user), даже если их exp ещё не наступил.
    Новый логин снова работает и выдаёт валидные токены."""
    user = await _get_target(db, email)
    user.session_revoked_before = datetime.now(UTC)
    await db.commit()
    return {"command": "revoke-sessions", "email": email, "revoked_before": user.session_revoked_before.isoformat()}


async def blockip(db: AsyncSession, ip_address: str, minutes: int | None = None, actor_id: str | None = None) -> dict:
    """/blockip <ip> [minutes] — без minutes блокировка бессрочная (до /unblockip)."""
    row = await block_ip(db, ip_address, reason="manual console /blockip", minutes=minutes, actor_id=actor_id)
    return {
        "command": "blockip", "ip": ip_address,
        "expires_at": row.expires_at.isoformat() if row.expires_at else None,
    }


async def set_telegram_chat_id(db: AsyncSession, email: str, chat_id: str) -> dict:
    """/telegram <email> <chat_id> — привязка Telegram chat_id к аккаунту
    Primary Developer/Developer для HIGH-уведомлений (app/core/telegram.py).
    chat_id узнаётся через @userinfobot в самом Telegram."""
    user = await _get_target(db, email)
    user.telegram_chat_id = chat_id
    await db.commit()
    return {"command": "telegram", "email": email, "telegram_chat_id": chat_id}


async def unblockip(db: AsyncSession, ip_address: str) -> dict:
    """/unblockip <ip>"""
    removed = await unblock_ip(db, ip_address)
    if not removed:
        raise ConsoleCommandError(f"IP {ip_address} не был в чёрном списке", 404)
    return {"command": "unblockip", "ip": ip_address}


async def find_user(db: AsyncSession, email: str) -> dict:
    """/find <email> — только чтение, для быстрого просмотра из консоли."""
    user = await get_user_by_email(db, email)
    if user is None:
        raise ConsoleCommandError(f"Пользователь {email} не найден", 404)
    return {
        "command": "find",
        "email": user.email,
        "username": user.username,
        "role": user.role.value,
        "is_active": user.is_active,
        "token_balance": user.token_balance,
        "token_limit": user.token_limit,
        "last_login_at": user.last_login_at.isoformat() if user.last_login_at else None,
        "banned_until": user.banned_until.isoformat() if user.banned_until else None,
    }


async def execute_command(db: AsyncSession, raw: str, actor_id: str | None = None) -> dict:
    """Парсит и выполняет строку вида '/priv email role'. Бросает
    ConsoleCommandError на плохой ввод — роутер превращает её в HTTP-ответ."""
    parts = raw.strip().split()
    if not parts:
        raise ConsoleCommandError("Пустая команда", 400)

    name = parts[0].lstrip("/").lower()
    args = parts[1:]

    if name in ("priv", "privilege"):
        if len(args) != 2:
            raise ConsoleCommandError("Формат: /priv <email> <role>", 400)
        return await grant_privilege(db, args[0], args[1])

    if name == "tokens":
        if len(args) != 2 or not _is_int(args[1]):
            raise ConsoleCommandError("Формат: /tokens <email> <amount>", 400)
        return await grant_tokens(db, args[0], int(args[1]))

    if name == "giveaway":
        if not args or not _is_int(args[0]):
            raise ConsoleCommandError("Формат: /giveaway <amount> [role]", 400)
        role = args[1] if len(args) > 1 else "all"
        return await run_giveaway(db, int(args[0]), role)

    if name == "ban":
        if len(args) != 1:
            raise ConsoleCommandError("Формат: /ban <email>", 400)
        return await ban_user(db, args[0])

    if name == "unban":
        if len(args) != 1:
            raise ConsoleCommandError("Формат: /unban <email>", 400)
        return await unban_user(db, args[0])

    if name == "find":
        if len(args) != 1:
            raise ConsoleCommandError("Формат: /find <email>", 400)
        return await find_user(db, args[0])

    if name == "revoke-sessions":
        if len(args) != 1:
            raise ConsoleCommandError("Формат: /revoke-sessions <email>", 400)
        return await revoke_sessions(db, args[0])

    if name == "blockip":
        if len(args) not in (1, 2) or (len(args) == 2 and not _is_int(args[1])):
            raise ConsoleCommandError("Формат: /blockip <ip> [minutes]", 400)
        minutes = int(args[1]) if len(args) == 2 else None
        return await blockip(db, args[0], minutes, actor_id=actor_id)

    if name == "unblockip":
        if len(args) != 1:
            raise ConsoleCommandError("Формат: /unblockip <ip>", 400)
        return await unblockip(db, args[0])

    if name == "telegram":
        if len(args) != 2:
            raise ConsoleCommandError("Формат: /telegram <email> <chat_id>", 400)
        return await set_telegram_chat_id(db, args[0], args[1])

    raise ConsoleCommandError(
        f"Неизвестная команда '/{name}'. Доступно: /priv, /tokens, /giveaway, /ban, /unban, /find, "
        "/revoke-sessions, /blockip, /unblockip, /telegram", 400
    )


def _is_int(value: str) -> bool:
    try:
        int(value)
        return True
    except ValueError:
        return False
