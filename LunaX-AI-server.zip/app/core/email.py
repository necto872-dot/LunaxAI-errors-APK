"""
Email-сервис LunaX AI (ТЗ раздел 24-27).

Поддерживает:
- STARTTLS (порт 587, Gmail) и SMTP_SSL (порт 465) — переключается конфигом;
- HTML-письмо + plain-text fallback;
- логирование ошибок БЕЗ раскрытия SMTP_PASSWORD/App Password.

ВАЖНО (ТЗ п.30, п.70): успешный вызов send_email() в mock/тестовом окружении
НЕ является доказательством работы реального Gmail SMTP. Реальным тестом
считается только фактическая отправка через smtp.gmail.com с действующим
App Password и получением письма в реальном почтовом ящике — это должно
быть проверено отдельно, вручную, владельцем инфраструктуры.
"""
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from app.config.settings import get_settings
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("email")


class EmailSendError(Exception):
    """Ошибка отправки письма. Никогда не содержит пароль/секреты в тексте."""


def _build_message(to_email: str, subject: str, html_body: str, text_body: str) -> MIMEMultipart:
    message = MIMEMultipart("alternative")
    message["Subject"] = subject
    message["From"] = f"{settings.smtp_from_name} <{settings.smtp_from_email}>"
    message["To"] = to_email
    message.attach(MIMEText(text_body, "plain", "utf-8"))
    message.attach(MIMEText(html_body, "html", "utf-8"))
    return message


def send_email(to_email: str, subject: str, html_body: str, text_body: str) -> bool:
    """
    Отправляет письмо через сконфигурированный SMTP.

    Возвращает True при успешной отправке, иначе бросает EmailSendError.
    Никогда не логирует settings.smtp_password.
    """
    if not settings.smtp_username or not settings.smtp_password:
        logger.warning(
            "SMTP не сконфигурирован (smtp_username/smtp_password пусты) — письмо НЕ отправлено, to=%s",
            to_email,
        )
        raise EmailSendError("SMTP is not configured")

    message = _build_message(to_email, subject, html_body, text_body)

    try:
        if settings.smtp_use_ssl:
            with smtplib.SMTP_SSL(settings.smtp_host, settings.smtp_port, timeout=15) as server:
                server.login(settings.smtp_username, settings.smtp_password)
                server.sendmail(settings.smtp_from_email, [to_email], message.as_string())
        else:
            with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=15) as server:
                if settings.smtp_use_tls:
                    server.starttls()
                server.login(settings.smtp_username, settings.smtp_password)
                server.sendmail(settings.smtp_from_email, [to_email], message.as_string())
    except smtplib.SMTPException as exc:
        # Никогда не включаем settings.smtp_password в лог/исключение.
        logger.exception("Ошибка отправки письма (SMTP) to=%s", to_email)
        raise EmailSendError(f"SMTP send failed: {exc.__class__.__name__}") from exc
    except OSError as exc:
        logger.exception("Ошибка соединения с SMTP-сервером to=%s", to_email)
        raise EmailSendError(f"SMTP connection failed: {exc.__class__.__name__}") from exc
    else:
        logger.info("Письмо отправлено: to=%s subject=%s", to_email, subject)
        return True


def send_verification_email(to_email: str, token: str) -> bool:
    link = f"{settings.frontend_url}/verify-email?token={token}"
    html = f"""
    <p>Здравствуйте!</p>
    <p>Подтвердите ваш email в LunaX AI, перейдя по ссылке:</p>
    <p><a href="{link}">{link}</a></p>
    <p>Ссылка действительна {settings.email_verification_token_expire_hours} ч.</p>
    """
    text = f"Подтвердите email в LunaX AI: {link}"
    return send_email(to_email, "LunaX AI — подтверждение email", html, text)


def send_password_reset_email(to_email: str, token: str) -> bool:
    link = f"{settings.frontend_url}/reset-password?token={token}"
    html = f"""
    <p>Запрошено восстановление пароля LunaX AI.</p>
    <p>Если это были не вы — проигнорируйте это письмо.</p>
    <p><a href="{link}">{link}</a></p>
    <p>Ссылка действительна {settings.password_reset_token_expire_minutes} мин.</p>
    """
    text = f"Восстановление пароля LunaX AI: {link}"
    return send_email(to_email, "LunaX AI — восстановление пароля", html, text)


def send_email_change_confirmation(to_email: str, token: str) -> bool:
    link = f"{settings.frontend_url}/confirm-email-change?token={token}"
    html = f"""
    <p>Запрошена смена email в LunaX AI на этот адрес.</p>
    <p>Подтвердите смену, перейдя по ссылке:</p>
    <p><a href="{link}">{link}</a></p>
    <p>Ссылка действительна {settings.email_change_token_expire_hours} ч.</p>
    """
    text = f"Подтвердите смену email в LunaX AI: {link}"
    return send_email(to_email, "LunaX AI — подтверждение смены email", html, text)
