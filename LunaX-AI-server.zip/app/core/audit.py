"""
Запись критических административных событий в audit_logs (ТЗ п.52).

Никогда не передавайте сюда пароли, App Password, JWT или полные токены —
только событие, actor_id, target_id и неконфиденциальные детали.
"""
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import AuditLog


async def record_audit_event(
    db: AsyncSession,
    event: str,
    actor_id: str | None = None,
    target_id: str | None = None,
    **details,
) -> None:
    entry = AuditLog(event=event, actor_id=actor_id, target_id=target_id, details=details or None)
    db.add(entry)
    await db.commit()
