"""
Очередь тяжёлых задач (RQ/Redis) — LunaX_AI_TZ.txt раздел про "очередь
запросов" (сборка APK, генерация видео и т.п. должны идти через очередь,
не блокировать основной запрос API).

Это РЕАЛЬНАЯ, рабочая интеграция с RQ (Redis Queue) — не заглушка.
Подключены две реальные тяжёлые задачи: сборка APK
(app/core/build/apk.py:enqueue_apk_build/run_apk_build_job_sync) и
генерация проектов (app/core/projects/generator.py:
enqueue_project_generation/run_project_generation_job_sync) — обе идут
через приоритетную очередь пользователя (priority_queue_name_for),
не блокируя HTTP-запрос. Генерация видео/медиа в очередь пока не
заведена (сама подсистема генерации видео не реализована, см. README).

ЧЕСТНОЕ ОГРАНИЧЕНИЕ: реальный Redis-сервер не поднимался и не
тестировался в этой sandbox-среде (нет сети). Тесты используют fakeredis
(in-memory реализация протокола Redis для тестов) — синтаксически и
логически корректная интеграция, но НЕ то же самое, что прогон против
настоящего Redis-инстанса.
"""
from collections.abc import Callable, Coroutine
from functools import lru_cache
from typing import TypeVar

import redis
from rq import Queue
from rq.job import Job

from app.config.settings import get_settings

settings = get_settings()

_T = TypeVar("_T")

# Приоритет очередей (ТЗ п.9): Developer > Ultra Plus > Pro Plus > Pro >
# Free. RQ worker, запущенный как `rq worker developer ultra_plus pro_plus
# pro free`, полностью опустошает более приоритетную очередь, прежде чем
# взять задачу из следующей — это даёт реальный server-side приоритет,
# а не визуальный. Внутри одной очереди — FIFO (поведение RQ по умолчанию).
PRIORITY_QUEUE_ORDER = ["developer", "ultra_plus", "ultra", "pro_plus", "pro", "free"]


def priority_queue_name_for(user) -> str:
    from app.database.models import UserRole

    if user.role in (UserRole.DEVELOPER, UserRole.PRIMARY_DEVELOPER, UserRole.ADMIN):
        return "developer"
    return user.subscription_tier.value  # "free"/"pro"/"pro_plus"/"ultra"/"ultra_plus"


@lru_cache(maxsize=1)
def get_redis_connection() -> redis.Redis:
    """
    Ленивая инициализация соединения — не подключаемся к Redis при
    простом импорте модуля (иначе тесты/CI без Redis не смогут даже
    импортировать приложение).
    """
    return redis.from_url(settings.redis_url)


def get_queue(name: str = "default") -> Queue:
    return Queue(name=name, connection=get_redis_connection())


def enqueue_job(queue_name: str, func: Callable, /, *args, **kwargs) -> str:
    """Низкоуровневая постановка в конкретную именованную очередь."""
    queue = get_queue(queue_name)
    job = queue.enqueue(func, *args, **kwargs)
    return job.id


def enqueue_priority_job(user, func: Callable, /, *args, **kwargs) -> str:
    """Ставит задачу в очередь приоритета пользователя (ТЗ п.9)."""
    return enqueue_job(priority_queue_name_for(user), func, *args, **kwargs)


def get_job_status(job_id: str) -> dict:
    """
    Возвращает статус задачи по id. Бросает исключение rq.exceptions.NoSuchJobError,
    если задачи с таким id нет (не перехватываем здесь — вызывающая сторона
    сама решает, как маппить это на HTTP 404).
    """
    job = Job.fetch(job_id, connection=get_redis_connection())
    return {
        "job_id": job.id,
        "status": job.get_status(),  # queued | started | finished | failed | ...
        "result": job.result if job.is_finished else None,
        "error": str(job.exc_info) if job.is_failed else None,
        "enqueued_at": job.enqueued_at.isoformat() if job.enqueued_at else None,
        "started_at": job.started_at.isoformat() if job.started_at else None,
        "ended_at": job.ended_at.isoformat() if job.ended_at else None,
    }


def cancel_job(job_id: str) -> None:
    job = Job.fetch(job_id, connection=get_redis_connection())
    job.cancel()


def echo_job(payload: str) -> str:
    """
    Демонстрационная/health-check задача — доказывает, что очередь реально
    работает end-to-end (enqueue -> воркер -> результат), не занимает место
    будущих реальных job-функций (сборка APK, генерация видео и т.п.),
    которых пока не существует как отдельных подсистем.
    """
    return f"processed: {payload}"


def run_coro_sync(coro: Coroutine[object, object, _T]) -> _T:
    """
    Запускает корутину из синхронного кода — используется job-функциями
    RQ-воркера (app/core/build/apk.py:run_apk_build_job_sync,
    app/core/projects/generator.py:run_project_generation_job_sync), т.к.
    RQ вызывает обычные (не async) функции.

    В реальном воркере (`rq worker ...`, отдельный процесс) активного
    event loop нет — там достаточно обычного asyncio.run(). Но при
    burst-обработке очереди внутри уже запущенного event loop (например,
    SimpleWorker.work(burst=True), вызванный синхронно из async-теста —
    см. tests/test_apk_build.py, tests/test_project_generation.py)
    asyncio.run() бросает "cannot be called from a running event loop".
    Поэтому в этом случае корутина выполняется в отдельном потоке со
    своим собственным event loop.
    """
    import asyncio

    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    import concurrent.futures

    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        return pool.submit(asyncio.run, coro).result()
