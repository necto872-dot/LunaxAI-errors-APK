"""
Rate limiting для auth-эндпоинтов (LunaX_AI_TZ.txt раздел 41, ТЗ п.41 auth).

ВАЖНО (честно, не скрываю ограничение): это IN-MEMORY sliding-window
лимитер внутри одного процесса. Он работает корректно для одного
uvicorn worker'а. При нескольких worker'ах/репликах каждый процесс будет
считать лимит независимо — это НЕ production-grade реализация для
масштабирования. Для реального продакшена с несколькими воркерами нужен
общий backend (Redis, `settings.redis_url` уже есть в конфиге, но
интеграция не подключена в этом проходе).

Конкретные числа (settings.rate_limit_*) — технические дефолты-заглушки,
не согласованное бизнес-решение (см. CONTINUATION SPECIFICATION раздел 20).
"""
import time
from collections import defaultdict

from fastapi import Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.security_events import check_rate_limit_abuse
from app.database import get_db

settings = get_settings()

# bucket_key -> list[timestamp] (секунды, monotonic)
_hits: dict[str, list[float]] = defaultdict(list)


def _client_key(request: Request, bucket: str) -> str:
    client_ip = request.client.host if request.client else "unknown"
    return f"{bucket}:{client_ip}"


def _check_and_record(bucket: str, key: str, max_per_minute: int) -> None:
    if not settings.rate_limit_enabled or max_per_minute <= 0:
        return

    now = time.monotonic()
    window_start = now - 60.0
    hits = _hits[key]

    # Чистим устаревшие попадания (за пределами окна в 60 секунд).
    while hits and hits[0] < window_start:
        hits.pop(0)

    if len(hits) >= max_per_minute:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Слишком много запросов ({bucket}). Попробуйте позже.",
        )

    hits.append(now)


def rate_limit(bucket: str, max_per_minute_attr: str):
    """
    Фабрика FastAPI-зависимости.

    bucket — имя корзины лимита (например "login").
    max_per_minute_attr — имя поля в Settings, откуда берётся значение
    (например "rate_limit_login_per_minute"), чтобы число не было
    захардкожено дважды.
    """

    async def dependency(request: Request, db: AsyncSession = Depends(get_db)) -> None:
        max_per_minute = getattr(settings, max_per_minute_attr)
        key = _client_key(request, bucket)
        ip = request.client.host if request.client else "unknown"
        try:
            _check_and_record(bucket, key, max_per_minute)
        except HTTPException:
            # 429 сам по себе не критичен — критично, когда один и тот же
            # bucket:ip упирается в лимит повторно (app/core/security_events.py).
            await check_rate_limit_abuse(db, bucket, ip)
            raise

    return Depends(dependency)
