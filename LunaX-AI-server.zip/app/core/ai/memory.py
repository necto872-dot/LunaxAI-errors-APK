"""
Память Lunox AI (закрывает главный пробел из аудита — "модель отвечает,
но не помнит пользователя").

Два независимых уровня, оба реализованы БЕЗ embeddings/векторного поиска
(честное ограничение: семантическая долговременная память потребовала бы
отдельной embedding-модели, которой в проекте нет):

1. КРАТКОВРЕМЕННАЯ (в рамках диалога) — Conversation + Message. При каждом
   запросе с conversation_id подгружаются последние N сообщений этого
   диалога и передаются в AIProvider как context. N ограничен
   settings.lunox_memory_short_term_messages — это физический предел
   контекстного окна модели, а не квота хранения (см. п.2).

2. ДОЛГОВРЕМЕННАЯ (между диалогами) — UserMemoryFact, явный механизм
   remember/forget. Добавляются в context каждого запроса как системная
   память, пока не будут явно удалены.

КВОТА ХРАНЕНИЯ (согласована с владельцем в чате): Free=2ГБ, Pro=3ГБ,
Pro Plus=4ГБ, Ultra=5ГБ, Ultra Plus=6ГБ, Developer/Primary=10ГБ — суммарно
на весь текст всех Message + UserMemoryFact пользователя (байты UTF-8).
Это гарантия "ничего не удаляется само по себе" — при достижении лимита
НОВЫЕ записи блокируются с понятной ошибкой (пользователь сам решает:
удалить старые диалоги или повысить тариф), а не тихо стираются старые
данные и не превышается лимит молча. История, однажды сохранённая, живёт
до тех пор, пока пользователь сам её не удалит — так решается проблема
"я тебе это уже присылал, а ты потерял".

ВАЖНО, честно (см. подробное объяснение в Settings): эта ГБ-квота НЕ
означает, что модель видит всю историю целиком в каждом ответе — это
физически невозможно ни для одной LLM (гигабайты текста — сотни
миллионов токенов, ни один context window столько не вмещает). Квота
хранения и контекст, реально идущий в модель за один раз (п.1,
lunox_memory_short_term_messages) — разные величины по своей природе.
"""
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import (
    DEVELOPER_MEMORY_STORAGE_LIMIT_GB,
    GIGABYTE,
    MEGABYTE,
    MEMORY_STORAGE_LIMIT_MB,
    get_settings,
)
from app.database.models import (
    Conversation,
    Message,
    MessageRole,
    User,
    UserMemoryFact,
    UserRole,
    _now,
)

settings = get_settings()


class MemoryError(Exception):
    def __init__(self, message: str, status_code: int = 404):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


class MemoryQuotaExceededError(MemoryError):
    def __init__(self, message: str):
        super().__init__(message, status_code=507)  # 507 Insufficient Storage


def _byte_len(text: str) -> int:
    return len(text.encode("utf-8"))


def memory_limit_bytes_for(user: User) -> int:
    """Лимит хранения памяти в байтах — по роли (Developer/Primary) или тарифу."""
    if user.role in (UserRole.DEVELOPER, UserRole.PRIMARY_DEVELOPER, UserRole.ADMIN):
        return DEVELOPER_MEMORY_STORAGE_LIMIT_GB * GIGABYTE
    mb = MEMORY_STORAGE_LIMIT_MB.get(user.subscription_tier.value, MEMORY_STORAGE_LIMIT_MB["free"])
    return round(mb * MEGABYTE)


async def get_memory_usage_bytes(db: AsyncSession, user: User) -> int:
    """
    Суммарный объём хранимого текста (все сообщения во всех диалогах
    пользователя + все долговременные факты), в байтах UTF-8.
    """
    messages_result = await db.execute(
        select(func.coalesce(func.sum(func.length(Message.content)), 0))
        .join(Conversation, Message.conversation_id == Conversation.id)
        .where(Conversation.owner_id == user.id)
    )
    messages_bytes = messages_result.scalar_one() or 0

    facts_result = await db.execute(
        select(func.coalesce(func.sum(func.length(UserMemoryFact.content)), 0))
        .where(UserMemoryFact.owner_id == user.id)
    )
    facts_bytes = facts_result.scalar_one() or 0

    # func.length() в SQLite/Postgres считает символы, не обязательно байты
    # UTF-8 1-в-1 для не-ASCII текста (кириллица и т.п.) — для точной квоты
    # это может недооценивать фактический байтовый размер. Для полной
    # точности лучше считать по факту при каждой записи (см. append_message/
    # remember_fact ниже, где используется реальный _byte_len() построчно),
    # эта функция даёт быструю агрегатную оценку для /memory/status.
    return int(messages_bytes) + int(facts_bytes)


async def get_memory_status(db: AsyncSession, user: User) -> dict:
    used = await get_memory_usage_bytes(db, user)
    limit = memory_limit_bytes_for(user)
    return {
        "used_bytes": used,
        "limit_bytes": limit,
        "used_percent": round(100 * used / limit, 2) if limit else 0,
    }


async def _ensure_quota_available(db: AsyncSession, user: User, additional_bytes: int) -> None:
    used = await get_memory_usage_bytes(db, user)
    limit = memory_limit_bytes_for(user)
    if used + additional_bytes > limit:
        limit_mb = limit / MEGABYTE
        raise MemoryQuotaExceededError(
            f"Лимит хранения памяти исчерпан ({limit_mb:.1f} МБ на вашем тарифе). "
            "Удалите старые диалоги/записи памяти или повысьте тариф."
        )


# --- Conversations / кратковременная память ---

async def get_owned_conversation_or_404(db: AsyncSession, user: User, conversation_id: str) -> Conversation:
    result = await db.execute(select(Conversation).where(Conversation.id == conversation_id))
    conversation = result.scalar_one_or_none()
    if conversation is None or conversation.owner_id != user.id:
        # 404 и для "не найдено", и для "чужое" — не подтверждаем чужому
        # пользователю сам факт существования conversation_id (тот же
        # принцип, что и в files/services.py).
        raise MemoryError("Диалог не найден")
    return conversation


async def get_or_create_conversation(db: AsyncSession, user: User, conversation_id: str | None) -> Conversation:
    if conversation_id:
        return await get_owned_conversation_or_404(db, user, conversation_id)

    conversation = Conversation(owner_id=user.id)
    db.add(conversation)
    await db.commit()
    await db.refresh(conversation)
    return conversation


async def list_user_conversations(db: AsyncSession, user: User) -> list[Conversation]:
    result = await db.execute(
        select(Conversation).where(Conversation.owner_id == user.id).order_by(Conversation.updated_at.desc())
    )
    return list(result.scalars().all())


async def delete_conversation(db: AsyncSession, user: User, conversation_id: str) -> None:
    conversation = await get_owned_conversation_or_404(db, user, conversation_id)
    result = await db.execute(select(Message).where(Message.conversation_id == conversation.id))
    for message in result.scalars().all():
        await db.delete(message)
    await db.delete(conversation)
    await db.commit()


async def append_message(
    db: AsyncSession, user: User, conversation: Conversation, role: MessageRole, content: str
) -> Message:
    """
    Сохраняет сообщение НАВСЕГДА (до явного удаления диалога пользователем)
    — если квота хранения (см. модуль-докстринг) исчерпана, бросает
    MemoryQuotaExceededError и НИЧЕГО не пишет в БД, а не молча обрезает
    старые сообщения. Так гарантируется "ничего не теряется без спроса".
    """
    await _ensure_quota_available(db, user, _byte_len(content))

    message = Message(conversation_id=conversation.id, role=role, content=content)
    db.add(message)
    conversation.updated_at = _now()
    await db.commit()
    await db.refresh(message)
    return message


async def append_message_pair(
    db: AsyncSession, user: User, conversation: Conversation, user_content: str, assistant_content: str
) -> tuple[Message, Message]:
    """
    Сохраняет реплику пользователя и ответ ассистента атомарно относительно
    квоты: проверяет, что хватит места на ОБА сообщения ДО записи первого
    — иначе возможна ситуация "вопрос сохранён, ответ не влез", что рвёт
    диалог пополам. Обычный append_message() по отдельности такую
    комбинированную проверку не делает.
    """
    await _ensure_quota_available(db, user, _byte_len(user_content) + _byte_len(assistant_content))

    user_message = Message(conversation_id=conversation.id, role=MessageRole.USER, content=user_content)
    assistant_message = Message(conversation_id=conversation.id, role=MessageRole.ASSISTANT, content=assistant_content)
    db.add(user_message)
    db.add(assistant_message)
    conversation.updated_at = _now()
    await db.commit()
    await db.refresh(user_message)
    await db.refresh(assistant_message)
    return user_message, assistant_message


async def get_conversation_messages(db: AsyncSession, user: User, conversation_id: str) -> list[Message]:
    conversation = await get_owned_conversation_or_404(db, user, conversation_id)
    result = await db.execute(
        select(Message).where(Message.conversation_id == conversation.id).order_by(Message.created_at.asc())
    )
    return list(result.scalars().all())


async def get_recent_context(db: AsyncSession, conversation: Conversation) -> list[dict]:
    """
    Последние N сообщений диалога в формате context для AIProvider. N —
    физический предел контекстного окна модели (settings.
    lunox_memory_short_term_messages), НЕ квота хранения — полная история
    диалога (сколько бы её ни было в пределах ГБ-квоты) всегда доступна
    целиком через get_conversation_messages()/GET /search/conversations/{id}/messages,
    даже если в конкретный ответ модели попадает только её недавний хвост.
    """
    limit = settings.lunox_memory_short_term_messages
    result = await db.execute(
        select(Message)
        .where(Message.conversation_id == conversation.id)
        .order_by(Message.created_at.desc())
        .limit(limit)
    )
    recent = list(reversed(result.scalars().all()))
    return [{"role": m.role.value, "content": m.content} for m in recent]


# --- Долговременная память: remember/forget ---

async def remember_fact(db: AsyncSession, user: User, content: str) -> UserMemoryFact:
    await _ensure_quota_available(db, user, _byte_len(content))

    fact = UserMemoryFact(owner_id=user.id, content=content)
    db.add(fact)
    await db.commit()
    await db.refresh(fact)
    return fact


async def list_facts(db: AsyncSession, user: User) -> list[UserMemoryFact]:
    result = await db.execute(
        select(UserMemoryFact).where(UserMemoryFact.owner_id == user.id).order_by(UserMemoryFact.created_at.desc())
    )
    return list(result.scalars().all())


async def forget_fact(db: AsyncSession, user: User, fact_id: str) -> None:
    result = await db.execute(select(UserMemoryFact).where(UserMemoryFact.id == fact_id))
    fact = result.scalar_one_or_none()
    if fact is None or fact.owner_id != user.id:
        raise MemoryError("Запись памяти не найдена")
    await db.delete(fact)
    await db.commit()


def build_long_term_context(facts: list[UserMemoryFact]) -> list[dict]:
    """
    Долговременные факты — отдельным системным сообщением ПЕРЕД историей
    диалога (персона из app/core/ai/persona.py добавляется provider'ом
    отдельно, эта функция её не трогает).
    """
    if not facts:
        return []
    bullet_list = "\n".join(f"- {fact.content}" for fact in facts)
    return [{
        "role": "system",
        "content": f"Известные факты о пользователе, которые он попросил запомнить:\n{bullet_list}",
    }]


async def build_full_context(db: AsyncSession, user: User, conversation: Conversation) -> list[dict]:
    """Долговременная память + кратковременная история — в этом порядке."""
    facts = await list_facts(db, user)
    long_term = build_long_term_context(facts)
    short_term = await get_recent_context(db, conversation)
    return long_term + short_term
