"""
Цикл само-проверки Lunox AI (ТЗ раздел 15).

Схема, как её описал владелец:

    основной provider отвечает
    -> если задача требует проверки, второй provider ТОЛЬКО указывает
       на ошибки (не пишет готовый ответ вместо основного)
    -> основной provider сам переделывает ответ по этому фидбеку
    -> повтор, пока второй provider не подтвердит "верно" ИЛИ не
       закончится лимит попыток (lunox_max_revision_attempts)

ВАЖНОЕ АРХИТЕКТУРНОЕ РЕШЕНИЕ (и почему): решение "нужна ли проверка для
этого конкретного ответа" принимает ВЫЗЫВАЮЩИЙ КОД (например пайплайн
генерации кода передаёт verify=True), а не парсинг свободного текста
модели в духе "я не уверен". Автоматически детектировать неуверенность
по тексту ответа ненадёжно и не может быть протестировано без реальных
API-ключей — поэтому явный флаг, а не эвристика.

Основной и проверяющий provider ДОЛЖНЫ указывать на разные endpoint'ы
(settings.self_hosted_verification_base_url/model заполнены и отличаются
от основного) — иначе проверка бессмысленна (модель "проверяет" сама
себя теми же весами). Если второй endpoint не настроен —
get_verification_provider() вернёт None и этот модуль честно работает
без верификации, не подделывая проверку.
"""
from dataclasses import dataclass

from app.config.settings import get_settings
from app.core.ai.providers import get_primary_provider, get_verification_provider
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("lunox_verification")


CRITIC_SYSTEM_INSTRUCTION = """\
Ты выступаешь ТОЛЬКО в роли рецензента, не автора ответа.

Тебе дан вопрос пользователя и ответ, который на него подготовила другая \
система. Твоя задача — проверить ответ на фактические и логические ошибки.

СТРОГО ЗАПРЕЩЕНО:
- писать собственный полный ответ на вопрос пользователя вместо проверяемого;
- переписывать проверяемый ответ целиком.

Формат твоего ответа — ровно так, без отступлений:

Первая строка: либо "STATUS: CORRECT", либо "STATUS: ISSUES_FOUND"
Если ISSUES_FOUND — далее маркированный список конкретных проблем \
(что именно неверно и почему), без предложения готовой замены текста.
"""

REVISION_INSTRUCTION_TEMPLATE = """\
Ты уже отвечал на этот вопрос пользователя:

--- ВОПРОС ---
{original_prompt}

--- ТВОЙ ПРЕДЫДУЩИЙ ОТВЕТ ---
{previous_answer}

--- ЗАМЕЧАНИЯ РЕЦЕНЗЕНТА (не готовый ответ, только перечень проблем) ---
{critique}

Исправь СВОЙ ответ с учётом этих замечаний. Ответь только исправленной \
версией — без пояснений о том, что именно ты изменил.
"""


@dataclass
class VerifiedAnswer:
    text: str
    verified: bool  # True только если рецензент явно подтвердил STATUS: CORRECT
    attempts_used: int


def _parse_critique(critique_text: str) -> tuple[bool, str]:
    """Возвращает (is_correct, issues_text)."""
    stripped = critique_text.strip()
    first_line = stripped.split("\n", 1)[0].strip().upper()
    is_correct = first_line.startswith("STATUS: CORRECT") or first_line == "STATUS:CORRECT"
    issues = stripped.split("\n", 1)[1].strip() if "\n" in stripped else ""
    return is_correct, issues


async def generate_with_verification(prompt: str, context: list[dict] | None = None) -> VerifiedAnswer:
    """
    Основной вход для задач, которым явно нужна проверка вторым provider'ом
    (вызывающий код решает это сам, см. docstring модуля).

    Если lunox_verification_enabled=False или второй endpoint не
    сконфигурирован — просто генерирует ответ основным provider'ом без
    проверки (verified=False, attempts_used=1), не притворяясь, что
    проверка прошла.
    """
    primary = get_primary_provider()
    answer = (await primary.generate(prompt, context)).text

    if not settings.lunox_verification_enabled:
        logger.info(
            "Проверка вторым provider'ом отключена "
            "(lunox_verification_enabled=False) — возвращаю без верификации"
        )
        return VerifiedAnswer(text=answer, verified=False, attempts_used=1)

    critic = get_verification_provider()
    if critic is None:
        logger.warning(
            "lunox_verification_enabled=True, но self_hosted_verification_base_url/model_name не заполнены "
            "— пропускаю верификацию"
        )
        return VerifiedAnswer(text=answer, verified=False, attempts_used=1)

    for attempt in range(1, settings.lunox_max_revision_attempts + 1):
        critique_context = [{"role": "system", "content": CRITIC_SYSTEM_INSTRUCTION}]
        critique_prompt = f"Вопрос пользователя:\n{prompt}\n\nПроверяемый ответ:\n{answer}"
        critique_text = (await critic.generate(critique_prompt, critique_context)).text

        is_correct, issues = _parse_critique(critique_text)
        logger.info("Верификация попытка=%s статус=%s", attempt, "CORRECT" if is_correct else "ISSUES_FOUND")

        if is_correct:
            return VerifiedAnswer(text=answer, verified=True, attempts_used=attempt)

        if attempt == settings.lunox_max_revision_attempts:
            # Лимит попыток исчерпан — возвращаем последнюю версию честно
            # НЕ подтверждённой (verified=False), а не подделываем успех.
            logger.warning("Лимит попыток верификации исчерпан (%s), ответ не подтверждён", attempt)
            return VerifiedAnswer(text=answer, verified=False, attempts_used=attempt)

        revision_prompt = REVISION_INSTRUCTION_TEMPLATE.format(
            original_prompt=prompt, previous_answer=answer, critique=issues or critique_text
        )
        answer = (await primary.generate(revision_prompt, context)).text

    # Недостижимо при max_revision_attempts >= 1, но на случай 0 — честно.
    return VerifiedAnswer(text=answer, verified=False, attempts_used=0)
