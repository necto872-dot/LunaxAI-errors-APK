"""
SelfHostedProvider — единственная реализация AIProvider (по решению
владельца: убрать все платные внешние API-ключи, использовать
собственный сервер с дообученной моделью).

Формат запросов — OpenAI-совместимый chat/completions API. Это НЕ
означает обращение к OpenAI: это просто общепринятый формат протокола,
который реализуют инференс-серверы для самостоятельного хостинга —
vLLM (`--served-model-name`, встроенный OpenAI-совместимый сервер),
text-generation-inference, Ollama (`/v1/chat/completions`). Обращение
идёт на твой собственный settings.self_hosted_base_url, никаких
сторонних сервисов и платных API-ключей не требуется.

Как получить модель для self_hosted_base_url — см. training/README.md:
дообучение (LoRA/QLoRA) открытой модели на своих данных + запуск через
vLLM/Ollama на своём сервере.
"""
import base64
import json

import httpx

from app.config.settings import get_settings
from app.core.ai.persona import build_openai_style_messages
from app.core.ai.provider import AIProvider, AIProviderNotConfigured, AIResponse
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("ai_providers")


class UnsupportedFileForAnalysisError(Exception):
    """Формат файла не поддерживается для AI-анализа (не изображение и не UTF-8 текст)."""


def _raise_for_provider_error(provider_name: str, resp: httpx.Response) -> None:
    if resp.status_code >= 400:
        try:
            body = resp.json()
        except ValueError:
            body = resp.text
        logger.error("%s API вернул ошибку %s: %s", provider_name, resp.status_code, body)
    resp.raise_for_status()


class SelfHostedProvider(AIProvider):
    """
    Провайдер для собственного инференс-сервера (vLLM/Ollama/TGI),
    поднятого владельцем на своей GPU-машине.

    Один класс обслуживает ДВЕ независимые роли — основную генерацию и
    (опционально) верификацию — потому что это просто HTTP-клиент к
    указанному base_url; сама модель на другом конце определяется тем,
    что владелец туда задеплоил (см. training/README.md). Для роли
    verification нужен отдельный base_url/model — например второй
    инстанс vLLM с другим чекпоинтом, иначе цикл само-проверки
    (app/core/ai/verification.py) автоматически отключается (проверка
    моделью самой себя бессмысленна).
    """

    name = "self_hosted"
    supports_web_search = False  # честно: у self-hosted LLM нет нативного веб-инструмента,
    # это отдельная фича, требующая своей поисковой интеграции — не реализовано в этом проходе.

    def __init__(self, base_url: str, model_name: str, api_key: str = ""):
        self.base_url = base_url.rstrip("/")
        self.model_name = model_name
        self.api_key = api_key

    def is_configured(self) -> bool:
        return bool(self.base_url and self.model_name)

    def _require_configured(self):
        if not self.is_configured():
            raise AIProviderNotConfigured(
                "Self-hosted provider не сконфигурирован: заполните "
                "SELF_HOSTED_BASE_URL и SELF_HOSTED_MODEL_NAME (или *_VERIFICATION_* "
                "для второй роли) в .env, указав адрес своего инференс-сервера."
            )

    def _headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _build_messages(self, prompt: str, context: list[dict] | None) -> list[dict]:
        return build_openai_style_messages(prompt, context)

    async def generate(self, prompt: str, context=None) -> AIResponse:
        self._require_configured()
        payload = {
            "model": self.model_name,
            "messages": self._build_messages(prompt, context),
            "max_tokens": settings.ai_max_tokens,
        }
        async with httpx.AsyncClient(timeout=settings.ai_request_timeout_seconds) as client:
            resp = await client.post(f"{self.base_url}/chat/completions", headers=self._headers(), json=payload)
            _raise_for_provider_error(self.name, resp)
            data = resp.json()
        return AIResponse(text=data["choices"][0]["message"]["content"], provider_used=self.name)

    async def stream(self, prompt: str, context=None):
        self._require_configured()
        payload = {
            "model": self.model_name,
            "messages": self._build_messages(prompt, context),
            "max_tokens": settings.ai_max_tokens,
            "stream": True,
        }
        async with (
            httpx.AsyncClient(timeout=settings.ai_request_timeout_seconds) as client,
            client.stream(
                "POST", f"{self.base_url}/chat/completions", headers=self._headers(), json=payload
            ) as resp,
        ):
            if resp.status_code >= 400:
                body = await resp.aread()
                logger.error("%s API stream вернул ошибку %s: %s", self.name, resp.status_code, body)
                resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line or not line.startswith("data:"):
                    continue
                data_str = line[len("data:"):].strip()
                if data_str == "[DONE]":
                    break
                chunk = json.loads(data_str)
                delta = chunk["choices"][0]["delta"].get("content")
                if delta:
                    yield delta

    async def analyze_image(self, image_bytes: bytes, prompt: str, mime_type: str = "image/jpeg") -> AIResponse:
        """
        Анализ изображения через OpenAI-совместимый vision-формат
        (content = [{"type": "text", ...}, {"type": "image_url", ...}]).
        Это открытый, задокументированный протокол Chat Completions API —
        его реализуют инференс-серверы при развёртывании vision-моделей
        (vLLM/Ollama с LLaVA, Qwen2-VL и т.п.).

        ЧЕСТНОЕ ОГРАНИЧЕНИЕ: сама модель на self_hosted_base_url должна
        реально поддерживать vision — если развёрнута текстовая-only
        модель, сервер вернёт ошибку формата запроса (не эта функция
        врёт о поддержке, а конкретный деплой её не имеет). Проверить
        поддержку можно у своего инференс-сервера напрямую.
        """
        self._require_configured()
        b64_image = base64.b64encode(image_bytes).decode("ascii")
        payload = {
            "model": self.model_name,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:{mime_type};base64,{b64_image}"},
                        },
                    ],
                }
            ],
            "max_tokens": settings.ai_max_tokens,
        }
        async with httpx.AsyncClient(timeout=settings.ai_request_timeout_seconds) as client:
            resp = await client.post(f"{self.base_url}/chat/completions", headers=self._headers(), json=payload)
            _raise_for_provider_error(self.name, resp)
            data = resp.json()
        return AIResponse(text=data["choices"][0]["message"]["content"], provider_used=self.name)

    async def analyze_file(self, file_bytes: bytes, filename: str, prompt: str) -> AIResponse:
        self._require_configured()

        # Изображения — не "бинарный файл без поддержки", у нас уже есть
        # рабочий путь для них (analyze_image, vision-запрос с base64).
        image_ext = ("png", "jpg", "jpeg", "gif", "webp")
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext in image_ext:
            mime_type = "image/jpeg" if ext == "jpg" else f"image/{ext}"
            return await self.analyze_image(file_bytes, prompt, mime_type=mime_type)

        try:
            text_content = file_bytes.decode("utf-8")
        except UnicodeDecodeError as exc:
            # audit-allow: честная, обрабатываемая бизнес-ошибка (НЕ NotImplementedError):
            # self-hosted чат-модель без vision получает файлы только как
            # текст в промпте, а для этого формата бинарное содержимое
            # нельзя декодировать как UTF-8 текст. Это ограничение формата
            # файла, а не недоделанный код — вызывающая сторона (Lunox AI
            # router) превращает это в понятный ответ пользователю.
            raise UnsupportedFileForAnalysisError(
                f"Файл '{filename}' нельзя проанализировать: это не изображение и не "
                "текстовый файл в кодировке UTF-8. Self-hosted модель без vision может "
                "анализировать только изображения и UTF-8 текст."
            ) from exc
        payload = {
            "model": self.model_name,
            "messages": self._build_messages(f"{prompt}\n\n--- Файл: {filename} ---\n{text_content}", None),
            "max_tokens": settings.ai_max_tokens,
        }
        async with httpx.AsyncClient(timeout=settings.ai_request_timeout_seconds) as client:
            resp = await client.post(f"{self.base_url}/chat/completions", headers=self._headers(), json=payload)
            _raise_for_provider_error(self.name, resp)
            data = resp.json()
        return AIResponse(text=data["choices"][0]["message"]["content"], provider_used=self.name)


def get_primary_provider() -> SelfHostedProvider:
    return SelfHostedProvider(
        base_url=settings.self_hosted_base_url,
        model_name=settings.self_hosted_model_name,
        api_key=settings.self_hosted_api_key,
    )


def get_verification_provider() -> SelfHostedProvider | None:
    """
    None, если второй инстанс (для роли рецензента в цикле само-проверки,
    app/core/ai/verification.py) не сконфигурирован — это ОПЦИОНАЛЬНО,
    основной чат работает и без него.
    """
    if not settings.self_hosted_verification_base_url or not settings.self_hosted_verification_model_name:
        return None
    return SelfHostedProvider(
        base_url=settings.self_hosted_verification_base_url,
        model_name=settings.self_hosted_verification_model_name,
        api_key=settings.self_hosted_verification_api_key,
    )
