"""
AIProvider — единый интерфейс для внешних AI-провайдеров, к которым
Lunox AI может обращаться фоновой маршрутизацией (финальное ТЗ раздел
15-16). Backend НЕ должен быть жёстко связан с одним провайдером.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class AIResponse:
    text: str
    provider_used: str  # для внутреннего аудита/логов; НЕ показывается пользователю


class AIProviderNotConfigured(Exception):
    """У провайдера нет API-ключа в .env — TODO/CONFIG."""


class AIProvider(ABC):
    name: str
    # Веб-поиск — отдельная функция, требующая своей интеграции (поисковый
    # API), не встроенная возможность self-hosted LLM. False по умолчанию,
    # честно, не выдумываем то, чего нет (см. providers.py, SelfHostedProvider).
    supports_web_search: bool = False

    @abstractmethod
    def is_configured(self) -> bool:
        ...

    @abstractmethod
    async def generate(self, prompt: str, context: list[dict] | None = None) -> AIResponse:
        ...

    @abstractmethod
    async def stream(self, prompt: str, context: list[dict] | None = None):
        ...

    @abstractmethod
    async def analyze_image(self, image_bytes: bytes, prompt: str, mime_type: str = "image/jpeg") -> AIResponse:
        ...

    @abstractmethod
    async def analyze_file(self, file_bytes: bytes, filename: str, prompt: str) -> AIResponse:
        ...
