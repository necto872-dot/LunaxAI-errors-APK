"""
Lunox AI — единый видимый пользователю AI-слой (финальное ТЗ раздел 1, 15).

РЕШЕНИЕ ВЛАДЕЛЬЦА: все платные внешние API убраны. Backend обращается
ТОЛЬКО к собственному self-hosted инференс-серверу (settings.self_hosted_*)
— своя дообученная модель, свой сервер, никаких сторонних ключей. Как
получить такую модель — см. training/README.md в корне проекта (реальный
пайплайн LoRA/QLoRA дообучения, который нужно запустить самостоятельно
на своей GPU).

Архитектура: User -> Lunox AI -> (self-hosted модель) -> Lunox AI -> User.

ЧЕСТНОЕ ОГРАНИЧЕНИЕ (принципиально, не убирать): backend НЕ содержит
модель внутри себя — он HTTP-клиент к инференс-серверу, который должен
быть поднят и доступен по self_hosted_base_url. Если сервер не поднят
или не настроен — Lunox AI честно возвращает ошибку "AI недоступен", а
НЕ подделывает ответ заглушкой.

ПЕРСОНА (как Lunox AI общается): системный промпт добавляется в
app/core/ai/providers.py автоматически при каждом запросе (persona.py).
Это дополнительный слой ПОВЕРХ обученного поведения модели — training/
задаёт характер на уровне весов, этот промпт — быстрый способ
скорректировать поведение без переобучения.

ПАМЯТЬ: сам lunox_generate() по-прежнему не хранит состояние — это
чистая функция (prompt+context -> ответ). Сохранение истории диалога и
подгрузка контекста реализованы ВЫШЕ по стеку, в
app.modules.search.routers (эндпоинт /search/query собирает context
через app.core.ai.memory.build_full_context() перед вызовом
lunox_generate) — см. app/core/ai/memory.py.
"""
from app.config.settings import get_settings
from app.core.ai.provider import AIProviderNotConfigured, AIResponse
from app.core.ai.providers import UnsupportedFileForAnalysisError, get_primary_provider
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("lunox_ai")


class LunoxAIUnavailableError(Exception):
    """Self-hosted провайдер не сконфигурирован/недоступен — Lunox AI не может ответить."""


class LunoxFileAnalysisUnsupportedError(Exception):
    """Формат файла не поддерживается для AI-анализа (не изображение и не UTF-8 текст)."""


async def lunox_generate(prompt: str, context: list[dict] | None = None) -> str:
    """
    Единственная точка входа для текстового ответа Lunox AI.

    Возвращает ТОЛЬКО текст ответа — какая именно модель на self-hosted
    сервере фактически отвечала, остаётся во внутреннем логе.
    """
    if not settings.lunox_ai_enabled:
        raise LunoxAIUnavailableError(
            "Lunox AI выключен: settings.lunox_ai_enabled=False. Заполните "
            "SELF_HOSTED_BASE_URL/SELF_HOSTED_MODEL_NAME в .env, поднимите свой "
            "инференс-сервер (см. training/README.md) и включите LUNOX_AI_ENABLED=true."
        )

    provider = get_primary_provider()
    if not provider.is_configured():
        raise LunoxAIUnavailableError(
            "Lunox AI: self-hosted provider не сконфигурирован (пусты SELF_HOSTED_BASE_URL "
            "или SELF_HOSTED_MODEL_NAME в .env)."
        )

    try:
        response: AIResponse = await provider.generate(prompt, context)
    except AIProviderNotConfigured as e:
        raise LunoxAIUnavailableError(str(e)) from e

    logger.info("Lunox AI ответ сгенерирован (self-hosted, скрыто от пользователя)")
    return response.text


async def lunox_analyze_file(file_bytes: bytes, filename: str, prompt: str) -> str:
    """
    Точка входа для AI-анализа содержимого загруженного файла (ТЗ раздел 11).

    Поддерживает изображения (через vision-путь analyze_image) и текстовые
    файлы в UTF-8. Для остальных форматов честно возвращает
    LunoxFileAnalysisUnsupportedError — self-hosted чат-модель без vision
    не может проанализировать произвольный бинарный файл.
    """
    if not settings.lunox_ai_enabled:
        raise LunoxAIUnavailableError(
            "Lunox AI выключен: settings.lunox_ai_enabled=False. Заполните "
            "SELF_HOSTED_BASE_URL/SELF_HOSTED_MODEL_NAME в .env, поднимите свой "
            "инференс-сервер (см. training/README.md) и включите LUNOX_AI_ENABLED=true."
        )

    provider = get_primary_provider()
    if not provider.is_configured():
        raise LunoxAIUnavailableError(
            "Lunox AI: self-hosted provider не сконфигурирован (пусты SELF_HOSTED_BASE_URL "
            "или SELF_HOSTED_MODEL_NAME в .env)."
        )

    try:
        response: AIResponse = await provider.analyze_file(file_bytes, filename, prompt)
    except AIProviderNotConfigured as e:
        raise LunoxAIUnavailableError(str(e)) from e
    except UnsupportedFileForAnalysisError as e:
        raise LunoxFileAnalysisUnsupportedError(str(e)) from e

    logger.info("Lunox AI: файл проанализирован (self-hosted, скрыто от пользователя)")
    return response.text
