"""
TOTP-2FA для входа в Developer Console (app/modules/developer_panel).
pyotp — стандартная RFC 6238 реализация, секрет base32, совместим с
Google Authenticator/Authy/1Password.
"""
import pyotp

from app.config.settings import get_settings

settings = get_settings()


def generate_secret() -> str:
    return pyotp.random_base32()


def provisioning_uri(secret: str, email: str) -> str:
    return pyotp.totp.TOTP(secret).provisioning_uri(name=email, issuer_name=settings.totp_issuer_name)


def verify_code(secret: str, code: str) -> bool:
    return pyotp.totp.TOTP(secret).verify(code, valid_window=1)
