"""
Абстракция платёжного провайдера (финальное ТЗ раздел 10-12).

Не привязываем бизнес-логику тарифов к конкретному эквайрингу — новый
provider добавляется реализацией этого интерфейса и регистрацией в
app.core.payments.registry, без изменения payments-роутера или
token/tariff-сервисов.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class CheckoutSession:
    """Результат создания платёжной сессии — то, что уходит клиенту."""

    payment_id: str  # внутренний Payment.id (LunaX), не id провайдера
    checkout_url: str
    provider: str


@dataclass
class WebhookEvent:
    """Разобранное и провалидированное событие от провайдера."""

    external_payment_id: str
    status: str  # "succeeded" | "failed" | "refunded" — нормализовано провайдером
    amount_kzt: int
    raw_payload: dict


class PaymentConfigurationError(Exception):
    """Provider не сконфигурирован (нет merchant_id/API key) — TODO/CONFIG."""


class WebhookSignatureError(Exception):
    """Подпись webhook не прошла проверку — событие отклонено."""


class PaymentProvider(ABC):
    """
    Общий интерфейс. Конкретные реализации (KaspiPaymentProvider,
    FreedomPayProvider) в этом же пакете.
    """

    name: str

    @abstractmethod
    def is_configured(self) -> bool:
        """True, если у провайдера заполнены реальные credentials."""

    @abstractmethod
    async def create_checkout(self, *, payment_id: str, amount_kzt: int, description: str) -> CheckoutSession:
        """Создаёт платёжную сессию у провайдера и возвращает checkout_url."""

    @abstractmethod
    def verify_and_parse_webhook(self, headers: dict, raw_body: bytes) -> WebhookEvent:
        """
        Проверяет подпись webhook (ТЗ раздел 11, п.1) и разбирает событие.
        Бросает WebhookSignatureError, если подпись неверна — вызывающая
        сторона ДОЛЖНА отклонить запрос, не обрабатывая payload.
        """
