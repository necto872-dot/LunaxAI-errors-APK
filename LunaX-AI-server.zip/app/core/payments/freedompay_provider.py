"""
FreedomPayProvider — реализация PaymentProvider для Freedom Pay
Kazakhstan (финальное ТЗ раздел 10, 12, международный эквайринг).

ЧЕСТНОЕ ОГРАНИЧЕНИЕ: как и Kaspi-реализация — это каркас с общепринятым
паттерном подписи (HMAC-SHA256), НЕ сверенный с реальной документацией
Freedom Pay API. Не считать протестированным без реальных credentials и
интеграционного теста против песочницы Freedom Pay.
"""
import hashlib
import hmac

from app.config.settings import get_settings
from app.core.payments.base import (
    CheckoutSession,
    PaymentConfigurationError,
    PaymentProvider,
    WebhookEvent,
    WebhookSignatureError,
)

settings = get_settings()


class FreedomPayProvider(PaymentProvider):
    name = "freedompay"

    def is_configured(self) -> bool:
        return bool(settings.freedompay_merchant_id and settings.freedompay_secret_key)

    async def create_checkout(self, *, payment_id: str, amount_kzt: int, description: str) -> CheckoutSession:
        if not self.is_configured():
            raise PaymentConfigurationError(
                "Freedom Pay не сконфигурирован: заполните FREEDOMPAY_MERCHANT_ID/"
                "FREEDOMPAY_SECRET_KEY в .env"
            )
        raise NotImplementedError(  # audit-allow: нет подтверждённой Freedom Pay API-документации, см. docstring
            "Freedom Pay checkout API не реализован в этом проходе: нужна "
            "подтверждённая документация Freedom Pay Kazakhstan и реальные credentials."
        )

    def verify_and_parse_webhook(self, headers: dict, raw_body: bytes) -> WebhookEvent:
        if not self.is_configured():
            raise PaymentConfigurationError("Freedom Pay не сконфигурирован")

        signature = headers.get("X-FreedomPay-Signature", "")
        expected = hmac.new(settings.freedompay_webhook_secret.encode(), raw_body, hashlib.sha256).hexdigest()
        if not signature or not hmac.compare_digest(signature, expected):
            raise WebhookSignatureError("Неверная подпись Freedom Pay webhook")

        raise NotImplementedError(  # audit-allow: формат Freedom Pay webhook payload не подтверждён, см. docstring
            "Разбор тела Freedom Pay webhook не реализован — формат payload не подтверждён "
            "по официальной документации в этом проходе."
        )
