"""Реестр PaymentProvider — выбор реализации по settings.payment_provider."""
from app.config.settings import get_settings
from app.core.payments.base import PaymentProvider
from app.core.payments.freedompay_provider import FreedomPayProvider
from app.core.payments.kaspi_provider import KaspiPaymentProvider

settings = get_settings()

_PROVIDERS: dict[str, type[PaymentProvider]] = {
    "kaspi": KaspiPaymentProvider,
    "freedompay": FreedomPayProvider,
}


def get_provider(name: str | None = None) -> PaymentProvider:
    key = (name or settings.payment_provider).lower()
    provider_cls = _PROVIDERS.get(key)
    if provider_cls is None:
        raise ValueError(f"Неизвестный payment provider: {key}. Доступны: {list(_PROVIDERS)}")
    return provider_cls()
