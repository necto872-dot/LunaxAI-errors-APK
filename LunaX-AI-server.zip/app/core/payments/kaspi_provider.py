"""
KaspiPaymentProvider — реализация PaymentProvider для Kaspi Pay
(финальное ТЗ раздел 10, 12).

ЧЕСТНОЕ ОГРАНИЧЕНИЕ (важно): точный формат checkout API и структура/
алгоритм подписи webhook Kaspi Pay здесь НЕ подтверждены по реальной
документации Kaspi (в этом проходе нет сетевого доступа для сверки с
актуальным Kaspi Pay API). Реализован общепринятый паттерн (HMAC-SHA256
подписи по сырому телу запроса с секретом мерчанта) как каркас,
подставляемый под конкретные названия полей/заголовков, когда владелец
подключит реальный мерчант-аккаунт и документацию Kaspi Pay for Business.

НЕ считать эту реализацию протестированной или готовой к продакшену без
сверки с официальным Kaspi Pay API и реального интеграционного теста.
"""
import hashlib
import hmac

from app.config.settings import get_settings
from app.core.payments.base import (
    CheckoutSession,
    PaymentConfigurationError,
    PaymentProvider,
    WebhookEvent,
    WebhookSignatureError,
)

settings = get_settings()


class KaspiPaymentProvider(PaymentProvider):
    name = "kaspi"

    def is_configured(self) -> bool:
        return bool(settings.kaspi_merchant_id and settings.kaspi_api_key)

    async def create_checkout(self, *, payment_id: str, amount_kzt: int, description: str) -> CheckoutSession:
        if not self.is_configured():
            raise PaymentConfigurationError(
                "Kaspi Pay не сконфигурирован: заполните KASPI_MERCHANT_ID/KASPI_API_KEY в .env"
            )
        # TODO/CONFIG: реальный вызов Kaspi Pay checkout API (HTTP-запрос
        # к их эндпоинту создания счёта/QR) не реализован — нет
        # подтверждённой спецификации API в этом проходе.
        raise NotImplementedError(  # audit-allow: нет публичного Kaspi Pay API, см. docstring
            "Kaspi Pay checkout API не реализован в этом проходе: нужна "
            "подтверждённая документация Kaspi Pay for Business и реальные credentials."
        )

    def verify_and_parse_webhook(self, headers: dict, raw_body: bytes) -> WebhookEvent:
        if not self.is_configured():
            raise PaymentConfigurationError("Kaspi Pay не сконфигурирован")

        # Каркас HMAC-проверки — точное имя заголовка подписи и алгоритм
        # НЕ подтверждены по реальной документации Kaspi (см. docstring).
        signature = headers.get("X-Kaspi-Signature", "")
        expected = hmac.new(settings.kaspi_webhook_secret.encode(), raw_body, hashlib.sha256).hexdigest()
        if not signature or not hmac.compare_digest(signature, expected):
            raise WebhookSignatureError("Неверная подпись Kaspi webhook")

        raise NotImplementedError(  # audit-allow: формат Kaspi webhook payload не подтверждён, см. docstring
            "Разбор тела Kaspi webhook не реализован — формат payload не подтверждён "
            "по официальной документации в этом проходе."
        )
