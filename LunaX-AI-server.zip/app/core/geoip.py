"""
Гео-IP для security_events (страна/город вместо голого IP в отчётах).
Best-effort через внешний бесплатный API (ip-api.com, без ключа, лимит
~45 req/min — достаточно для security-событий, не для общего трафика).
Кэш в памяти процесса, т.к. IP атакующего обычно повторяется в серии
событий подряд.
"""
import httpx

from app.config.settings import get_settings
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("geoip")

_cache: dict[str, dict | None] = {}


async def lookup_geoip(ip_address: str) -> dict | None:
    if not settings.geoip_enabled:
        return None
    if ip_address in _cache:
        return _cache[ip_address]
    if ip_address in ("127.0.0.1", "localhost", "testclient") or ip_address.startswith(("10.", "192.168.")):
        _cache[ip_address] = None
        return None

    result = None
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            resp = await client.get(
                f"http://ip-api.com/json/{ip_address}", params={"fields": "status,country,city"}
            )
            data = resp.json()
            if data.get("status") == "success":
                result = {"country": data.get("country"), "city": data.get("city")}
    except (httpx.HTTPError, ValueError) as e:
        logger.warning("GeoIP lookup не удался для %s: %s", ip_address, e)

    _cache[ip_address] = result
    return result
