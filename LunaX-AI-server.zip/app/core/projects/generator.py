"""
Генерация проектов + автоисправление кода (ТЗ раздел 27-28):

    Prompt -> Lunox AI (файловое дерево+код) -> Validation (compileall/pytest)
    -> если ошибка -> Lunox AI получает лог ошибки -> Patch -> повторная
    проверка -> ... до project_gen_max_fix_attempts -> Artifact (zip)

РЕАЛЬНО РАБОТАЕТ прямо сейчас: парсинг ответа AI, запись файлов в
изолированную рабочую директорию (без path traversal), запуск
`python -m compileall`/`pytest` в подпроцессе, разбор ошибок, упаковка
в zip, полный цикл retry с лимитом попыток — вся эта логика реальна и
покрыта тестами (AI-вызов в тестах мокается, остальное — нет).

ЧЕСТНОЕ ОГРАНИЧЕНИЕ: без сконфигурированного self-hosted AI
(settings.lunox_ai_enabled) реальной генерации не будет — pipeline
корректно дойдёт до вызова lunox_generate() и остановится с понятной
ошибкой, как и /search/query. Валидация сейчас поддерживает только
Python-проекты (compileall + pytest, если есть tests/) — валидация для
других языков/стеков (Node.js, Android/Gradle — см. app/core/build/) не
входит в этот модуль.
"""
import json
import re
import shutil
import subprocess
import tempfile
import uuid
import zipfile
from contextlib import suppress
from datetime import UTC, datetime
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.ai.lunox_router import LunoxAIUnavailableError, lunox_generate
from app.core.logger import get_logger
from app.core.quota import InsufficientTokensError
from app.core.safety import is_blocked
from app.core.token_cost import estimate_code_cost, reserve_and_spend
from app.database.models import BuildJob, BuildJobStatus, Project, ProjectStatus, ProjectVersion, User

settings = get_settings()
logger = get_logger("project_generator")


class ProjectGenerationError(Exception):
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


GENERATION_SYSTEM_INSTRUCTION = """\
Ты генерируешь структуру программного проекта. Отвечай СТРОГО валидным \
JSON без markdown-обрамления (без ```), в формате:

{"files": [{"path": "относительный/путь/файла.py", "content": "полное содержимое файла"}]}

Требования:
- пути ТОЛЬКО относительные, без ".." и без начального "/";
- включай реально рабочий код, а не заглушки;
- если проект на Python и подразумевает тесты — добавь файлы в папке tests/.
"""

FIX_INSTRUCTION_TEMPLATE = """\
Проект, который ты сгенерировал ранее, не прошёл проверку. Вот лог ошибки:

--- ЛОГ ОШИБКИ ---
{error_log}
--- КОНЕЦ ЛОГА ---

Вот файлы проекта в текущем виде:

{files_summary}

Верни ИСПРАВЛЕННУЮ версию всего проекта в том же JSON-формате
({{"files": [...]}}), устранив причину ошибки из лога.
"""


def _safe_relative_path(path: str) -> Path:
    p = Path(path)
    if p.is_absolute() or ".." in p.parts:
        raise ProjectGenerationError(f"Небезопасный путь файла в ответе AI: {path}", 502)
    return p


def parse_file_tree_response(ai_text: str) -> dict[str, str]:
    """
    Разбирает ответ AI в {relative_path: content}. Терпим к markdown-
    обрамлению (```json ... ```), которое модели иногда добавляют вопреки
    инструкции — вырезаем его перед парсингом.
    """
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", ai_text.strip(), flags=re.MULTILINE).strip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise ProjectGenerationError(f"AI вернул невалидный JSON файлового дерева: {e}", 502) from e

    files = data.get("files")
    if not isinstance(files, list) or not files:
        raise ProjectGenerationError("AI вернул JSON без непустого списка 'files'", 502)

    result: dict[str, str] = {}
    for entry in files:
        if "path" not in entry or "content" not in entry:
            raise ProjectGenerationError("Запись файла без 'path'/'content'", 502)
        safe_path = _safe_relative_path(entry["path"])
        result[str(safe_path)] = entry["content"]
    return result


def write_workspace(files: dict[str, str], workspace_dir: Path) -> None:
    for rel_path, content in files.items():
        dest = workspace_dir / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding="utf-8")


def run_validation(workspace_dir: Path) -> tuple[bool, str]:
    """
    Реальный запуск проверки: `python -m compileall` всегда, `pytest`
    дополнительно, если есть папка tests/. Возвращает (успех, лог).

    ВАЖНОЕ ОГРАНИЧЕНИЕ БЕЗОПАСНОСТИ (найдено при аудите): AI-сгенерированный
    код здесь РЕАЛЬНО ВЫПОЛНЯЕТСЯ через pytest — это значит произвольный
    Python-код, который решила написать модель (или который через
    jailbreak-промпт заставили написать), исполняется. write_workspace/
    _safe_relative_path защищают только от записи файлов ВНЕ рабочей
    директории (path traversal) — это НЕ песочница исполнения.

    Ниже — защита уровня процесса (что можно сделать без внешней
    инфраструктуры): пустое окружение (не наследует .env/секреты
    родительского процесса) + resource limits на CPU/память/число
    процессов (Unix only, через preexec_fn).

    ЧЕГО ЭТО НЕ ЗАКРЫВАЕТ: сетевой доступ подпроцесса НЕ ограничен — код
    может делать HTTP-запросы (exfiltration, DDoS-участие) и то же
    файловое дерево контейнера, что видит сам backend, всё ещё доступно
    на чтение (запись ограничена cwd только конвенцией, не правами ОС).
    Для реальной защиты в продакшене нужна настоящая изоляция —
    отдельный Docker-контейнер/gVisor/Firecracker с закрытой сетью на
    каждый запуск валидации, не process-level ограничения. Это
    инфраструктурная работа, не входит в этот проход.
    """
    log_parts: list[str] = []

    # Минимальное окружение — НЕ os.environ родителя. Иначе AI-сгенерированный
    # тест мог бы прочитать JWT_SECRET_KEY/DATABASE_URL/SMTP_PASSWORD и т.п.
    # через os.environ и слить их (например, через HTTP-запрос — сеть не
    # изолирована, см. ограничение выше).
    _minimal_env = {"PATH": "/usr/bin:/bin:/usr/local/bin", "HOME": str(workspace_dir)}

    def _limit_resources():
        """preexec_fn: применяется в дочернем процессе после fork, до exec.
        Только Unix (subprocess на Windows это молча не поддерживает —
        preexec_fn там вообще не принимается, см. вызов ниже)."""
        import resource

        cpu_seconds = settings.project_gen_timeout_seconds
        mem_bytes = 512 * 1024 * 1024  # 512MB — достаточно для compileall/pytest, не для майнинга/DoS
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds))
        resource.setrlimit(resource.RLIMIT_AS, (mem_bytes, mem_bytes))
        resource.setrlimit(resource.RLIMIT_NPROC, (32, 32))  # против fork-бомб
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))  # без core dump (могут содержать память процесса)

    import platform

    _preexec = _limit_resources if platform.system() != "Windows" else None

    compile_result = subprocess.run(
        ["python3", "-m", "compileall", "-q", str(workspace_dir)],
        capture_output=True,
        text=True,
        timeout=settings.project_gen_timeout_seconds,
        env=_minimal_env,
        preexec_fn=_preexec,
        check=False,
    )
    log_parts.append("=== compileall ===\n" + compile_result.stdout + compile_result.stderr)
    if compile_result.returncode != 0:
        return False, "\n".join(log_parts)

    tests_dir = workspace_dir / "tests"
    if tests_dir.is_dir():
        pytest_result = subprocess.run(
            ["python3", "-m", "pytest", "-q", str(tests_dir)],
            capture_output=True,
            text=True,
            timeout=settings.project_gen_timeout_seconds,
            cwd=str(workspace_dir),
            env=_minimal_env,
            preexec_fn=_preexec,
            check=False,
        )
        log_parts.append("=== pytest ===\n" + pytest_result.stdout + pytest_result.stderr)
        if pytest_result.returncode != 0:
            return False, "\n".join(log_parts)

    return True, "\n".join(log_parts)


def _files_summary(files: dict[str, str]) -> str:
    parts = []
    for path, content in files.items():
        parts.append(f"--- {path} ---\n{content}")
    return "\n\n".join(parts)


def _package_zip(files: dict[str, str], dest_zip_path: Path) -> None:
    dest_zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest_zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for path, content in files.items():
            zf.writestr(path, content)


async def _create_generation_job(db: AsyncSession, user: User, name: str, prompt: str) -> tuple[Project, BuildJob]:
    """Валидация безопасности + создание Project(status=GENERATING)/BuildJob(status=QUEUED). Быстро, без AI-вызовов."""
    if is_blocked(prompt):
        raise ProjectGenerationError("Запрос отклонён политикой безопасности", 400)

    project = Project(owner_id=user.id, name=name, prompt=prompt, status=ProjectStatus.GENERATING)
    db.add(project)
    await db.commit()
    await db.refresh(project)

    job = BuildJob(project_id=project.id, status=BuildJobStatus.QUEUED)
    db.add(job)
    await db.commit()
    await db.refresh(job)
    return project, job


async def _run_generation_job(db: AsyncSession, user: User, project: Project, job: BuildJob, prompt: str) -> Project:
    """
    Тяжёлая часть: цикл generate->validate->fix до project_gen_max_fix_attempts,
    пакует успешный результат в zip. Общее тело для синхронного
    generate_project() и для задачи, исполняемой воркером очереди
    (см. _run_project_generation_job_async ниже).

    Токены (C4, estimate_code_cost()) списываются за КАЖДУЮ попытку
    генерации/исправления отдельно — реальная AI-нагрузка на каждый вызов.
    """
    job.status = BuildJobStatus.RUNNING
    job.started_at = datetime.now(UTC)
    await db.commit()

    current_prompt = f"{GENERATION_SYSTEM_INSTRUCTION}\n\nЗадача пользователя: {prompt}"
    last_files: dict[str, str] = {}
    last_log = ""

    for attempt in range(1, settings.project_gen_max_fix_attempts + 1):
        job.attempt_count = attempt
        await db.commit()

        cost = estimate_code_cost()
        try:
            await reserve_and_spend(db, user, cost)
        except InsufficientTokensError as e:
            job.status = BuildJobStatus.FAILED
            job.log = f"Недостаточно токенов на попытке {attempt}: {e}"
            job.finished_at = datetime.now(UTC)
            project.status = ProjectStatus.FAILED
            await db.commit()
            raise ProjectGenerationError(str(e), 402) from e

        try:
            ai_response = await lunox_generate(current_prompt)
        except LunoxAIUnavailableError as e:
            job.status = BuildJobStatus.FAILED
            job.log = f"Lunox AI недоступен на попытке {attempt}: {e}"
            job.finished_at = datetime.now(UTC)
            project.status = ProjectStatus.FAILED
            await db.commit()
            raise ProjectGenerationError(str(e), 503) from e

        try:
            last_files = parse_file_tree_response(ai_response)
        except ProjectGenerationError as e:
            last_log = str(e)
            logger.warning("Попытка %s: ответ AI не распарсился: %s", attempt, e)
            current_prompt = FIX_INSTRUCTION_TEMPLATE.format(
                error_log=f"Ответ не является валидным файловым деревом: {e}",
                files_summary="(предыдущий ответ был нечитаемым, файлов нет)",
            )
            continue

        workspace_dir = Path(tempfile.mkdtemp(prefix=f"lunax-project-{uuid.uuid4().hex}-"))
        try:
            write_workspace(last_files, workspace_dir)
            success, validation_log = run_validation(workspace_dir)
            last_log = validation_log

            if success:
                version_number = project.current_version + 1
                artifact_rel_path = f"projects/{project.id}/v{version_number}.zip"
                artifact_full_path = Path(settings.file_storage_dir) / artifact_rel_path
                _package_zip(last_files, artifact_full_path)

                version_id = str(uuid.uuid4())
                version = ProjectVersion(
                    id=version_id,
                    project_id=project.id,
                    version_number=version_number,
                    file_manifest=last_files,
                    validation_passed=True,
                    artifact_path=artifact_rel_path,
                )
                db.add(version)
                project.current_version = version_number
                project.status = ProjectStatus.READY
                job.status = BuildJobStatus.SUCCEEDED
                job.project_version_id = version_id
                job.log = validation_log
                job.finished_at = datetime.now(UTC)
                await db.commit()
                await db.refresh(project)
                return project

            logger.info("Попытка %s: валидация не прошла, готовлю fix-промпт", attempt)
            current_prompt = FIX_INSTRUCTION_TEMPLATE.format(
                error_log=validation_log, files_summary=_files_summary(last_files)
            )
        finally:
            shutil.rmtree(workspace_dir, ignore_errors=True)

    job.status = BuildJobStatus.FAILED
    job.log = last_log
    job.finished_at = datetime.now(UTC)
    project.status = ProjectStatus.FAILED
    await db.commit()
    raise ProjectGenerationError(
        f"Не удалось сгенерировать рабочий проект за {settings.project_gen_max_fix_attempts} попыток. "
        f"Последняя ошибка: {last_log[-2000:]}",
        422,
    )


async def generate_project(db: AsyncSession, user: User, name: str, prompt: str) -> Project:
    """
    Синхронный полный цикл (создание + немедленное выполнение) в рамках
    одного await-вызова — НЕ проходит через очередь. Оставлен для обратной
    совместимости (тесты) и как тело задачи, вызываемое воркером очереди.
    Для реального HTTP-пути используйте enqueue_project_generation().
    """
    project, job = await _create_generation_job(db, user, name, prompt)
    return await _run_generation_job(db, user, project, job, prompt)


async def enqueue_project_generation(db: AsyncSession, user: User, name: str, prompt: str) -> Project:
    """
    HTTP-путь (ТЗ п.9 + известное ограничение, описанное в docstring
    app/modules/projects/routers.py: раньше /projects/generate ждал весь
    цикл generate->validate->fix внутри одного запроса). Создаёт
    Project+BuildJob и сразу возвращает Project со статусом "generating",
    не дожидаясь AI/валидации — реальная работа ставится в приоритетную
    очередь пользователя (app/core/queue.py) и выполняется воркером RQ.

    Прогресс отслеживается опросом GET /projects/{project_id} (status
    меняется generating -> ready/failed) или GET /projects/{id}/versions.
    """
    project, job = await _create_generation_job(db, user, name, prompt)

    from app.core.queue import enqueue_priority_job

    rq_job_id = enqueue_priority_job(
        user, run_project_generation_job_sync, project.id, job.id, user.id, prompt
    )
    job.queue_job_id = rq_job_id
    await db.commit()
    return project


async def _run_project_generation_job_async(project_id: str, job_id: str, user_id: str, prompt: str) -> dict:
    """Тело задачи очереди: открывает СВОЮ сессию БД (воркер — отдельный процесс) и выполняет генерацию."""
    from app.database import async_session_maker

    async with async_session_maker() as db:
        project = (await db.execute(select(Project).where(Project.id == project_id))).scalar_one_or_none()
        job = (await db.execute(select(BuildJob).where(BuildJob.id == job_id))).scalar_one_or_none()
        user = (await db.execute(select(User).where(User.id == user_id))).scalar_one_or_none()
        if project is None or job is None or user is None:
            raise ProjectGenerationError(f"Задача генерации {job_id} не найдена в очереди-воркере", 404)
        # Статус/лог уже сохранены в _run_generation_job до исключения —
        # воркеру RQ достаточно того, что задача пометится как failed в его логе.
        with suppress(ProjectGenerationError):
            await _run_generation_job(db, user, project, job, prompt)
        return {"project_id": project.id, "status": project.status.value}


def run_project_generation_job_sync(project_id: str, job_id: str, user_id: str, prompt: str) -> dict:
    """
    Синхронная точка входа для RQ-воркера — см. подробный комментарий в
    app/core/queue.py:run_coro_sync (та же причина, что и у
    run_apk_build_job_sync в app/core/build/apk.py).
    """
    from app.core.queue import run_coro_sync

    return run_coro_sync(_run_project_generation_job_async(project_id, job_id, user_id, prompt))


async def get_owned_project_or_404(db: AsyncSession, user: User, project_id: str) -> Project:
    result = await db.execute(select(Project).where(Project.id == project_id))
    project = result.scalar_one_or_none()
    if project is None or project.owner_id != user.id:
        raise ProjectGenerationError("Проект не найден", 404)
    return project


async def list_user_projects(db: AsyncSession, user: User) -> list[Project]:
    result = await db.execute(select(Project).where(Project.owner_id == user.id).order_by(Project.created_at.desc()))
    return list(result.scalars().all())


async def list_project_versions(db: AsyncSession, user: User, project_id: str) -> list[ProjectVersion]:
    await get_owned_project_or_404(db, user, project_id)
    result = await db.execute(
        select(ProjectVersion)
        .where(ProjectVersion.project_id == project_id)
        .order_by(ProjectVersion.version_number.desc())
    )
    return list(result.scalars().all())


async def delete_project(db: AsyncSession, user: User, project_id: str) -> None:
    project = await get_owned_project_or_404(db, user, project_id)

    versions_result = await db.execute(select(ProjectVersion).where(ProjectVersion.project_id == project_id))
    for version in versions_result.scalars().all():
        if version.artifact_path:
            artifact_full_path = Path(settings.file_storage_dir) / version.artifact_path
            if artifact_full_path.exists():
                artifact_full_path.unlink()
        await db.delete(version)

    jobs_result = await db.execute(select(BuildJob).where(BuildJob.project_id == project_id))
    for job in jobs_result.scalars().all():
        await db.delete(job)

    await db.delete(project)
    await db.commit()
