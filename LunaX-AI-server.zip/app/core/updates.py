"""
Система обновлений (ТЗ раздел 9): проверка версии + подтверждение через
доверенную консоль, без публичного "применить обновление одним запросом".

ЧЕСТНАЯ АРХИТЕКТУРНАЯ ГРАНИЦА: HTTP API никогда САМ не переписывает
работающий код процесса — это тот же принцип, что у Primary Developer
(нельзя опасное действие одним запросом без локального подтверждения).
/updates/apply проверяет токен, логирует намерение в audit_logs и
возвращает ИНСТРУКЦИЮ — реальный деплой (git pull, alembic upgrade,
рестарт процесса) выполняется владельцем локально через
scripts/apply_update.py, аналогично bootstrap_primary.py/manage_primary.py.

ЧЕСТНОЕ ОГРАНИЧЕНИЕ: settings.latest_available_version — не подключено
к реальному источнику фида обновлений (registry/CDN/git tags API), это
TODO/CONFIG. По умолчанию равно settings.app_version, то есть "обновлений
нет", пока владелец не настроит реальный источник или не проставит
значение вручную перед релизом новой версии.
"""
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.logger import get_logger
from app.core.tokens import generate_token, hash_token
from app.database.models import UpdateConfirmationToken, User

settings = get_settings()
logger = get_logger("updates")


class UpdatesError(Exception):
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


def _now():
    from datetime import UTC, datetime

    return datetime.now(UTC)


def _aware(dt):
    from datetime import UTC

    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt


async def check_for_update(db: AsyncSession, user: User) -> dict:
    """
    Сравнивает текущую версию с settings.latest_available_version.
    Если версии совпадают — обновлений нет, токен не создаётся.
    Если отличаются — создаёт одноразовый confirmation_token с TTL.
    """
    current = settings.app_version
    latest = settings.latest_available_version

    if current == latest:
        return {"update_available": False, "current_version": current, "latest_version": latest}

    raw_token = generate_token()
    record = UpdateConfirmationToken(
        requested_by=user.id,
        target_version=latest,
        token_hash=hash_token(raw_token),
        expires_at=_now() + timedelta(minutes=settings.update_confirmation_token_expire_minutes),
    )
    db.add(record)
    await db.commit()

    logger.info("Update confirmation token issued: user_id=%s target_version=%s", user.id, latest)

    return {
        "update_available": True,
        "current_version": current,
        "latest_version": latest,
        "confirmation_token": raw_token,
        "expires_in_minutes": settings.update_confirmation_token_expire_minutes,
    }


async def apply_update(db: AsyncSession, user: User, confirmation_token: str) -> dict:
    token_hash = hash_token(confirmation_token)
    result = await db.execute(
        select(UpdateConfirmationToken).where(UpdateConfirmationToken.token_hash == token_hash)
    )
    record = result.scalar_one_or_none()

    if record is None:
        raise UpdatesError("Недействительный confirmation_token", 400)
    if record.requested_by != user.id:
        # 404, а не 403 — не подтверждаем чужому пользователю сам факт
        # существования этого токена (тот же принцип, что и у файлов/памяти).
        raise UpdatesError("Токен не найден", 404)
    if record.used_at is not None:
        raise UpdatesError("Токен уже был использован", 400)
    if _aware(record.expires_at) < _now():
        raise UpdatesError("Срок действия токена истёк, запросите проверку обновлений заново", 400)

    record.used_at = _now()
    await db.commit()

    logger.info(
        "Update confirmed (НЕ применён автоматически): user_id=%s target_version=%s",
        user.id,
        record.target_version,
    )

    return {
        "status": "confirmed",
        "target_version": record.target_version,
        "instructions": (
            "Подтверждение зафиксировано. Реальное обновление выполните локально на сервере: "
            "python scripts/apply_update.py"
        ),
    }
