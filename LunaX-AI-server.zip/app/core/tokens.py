"""
Утилиты для одноразовых токенов (email verification, password reset,
email change) — ТЗ п.17, п.21, п.22, п.23.

Токен, отправляемый пользователю по email, никогда не хранится в БД
в открытом виде — хранится только его хэш (sha256). Это не пароль,
поэтому bcrypt здесь избыточен, но открытый токен из БД восстановить
нельзя, что предотвращает злоупотребление при утечке БД.
"""
import hashlib
import secrets


def generate_token() -> str:
    """Криптографически случайный, URL-safe токен."""
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()
