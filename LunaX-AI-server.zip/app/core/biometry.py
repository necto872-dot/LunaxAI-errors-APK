"""
Биометрия — сервисный слой (закрывает заглушки из аудита: "❌ replay-
защита, ❌ хранение попыток, ❌ блокировка после 5 неудач, ❌ переход на
пароль, ❌ запись user.is_biometric_verified").

Честно: то, что здесь РЕАЛЬНО реализовано — протокол вокруг проверки
(одноразовый серверный challenge, лимит попыток, временная блокировка,
запись итога). То, что НЕ реализовано и не может быть добавлено без
отдельной ML-подсистемы — собственно визуальный анализ (действительно ли
пользователь моргнул/повернул голову перед камерой, антиспуфинг). Параметр
`passed` в verify_liveness() приходит от вызывающей стороны (клиент,
который должен был провести реальный локальный/серверный CV-анализ) —
это явная точка интеграции для такой подсистемы в будущем, а не встроенный
самообман.
"""
import json
import random
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.audit import record_audit_event
from app.core.logger import log_security_event
from app.core.security_events import record_security_event
from app.database.models import BiometryChallenge, SecurityEventSeverity, User

settings = get_settings()

LIVENESS_ACTIONS = [
    "моргнуть",
    "улыбнуться",
    "повернуть голову вправо",
    "повернуть голову влево",
    "посмотреть вверх",
    "посмотреть вниз",
    "помахать рукой",
]


class BiometryError(Exception):
    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


def _now():
    from datetime import UTC, datetime

    return datetime.now(UTC)


def _aware(dt):
    from datetime import UTC

    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt


async def create_challenge(db: AsyncSession, user: User) -> BiometryChallenge:
    if user.biometry_locked_until and _aware(user.biometry_locked_until) > _now():
        raise BiometryError(
            f"Биометрия временно заблокирована после {settings.biometry_max_failed_attempts} неудачных "
            f"попыток. Используйте вход по паролю или попробуйте позже.",
            423,  # 423 Locked
        )

    actions = random.sample(LIVENESS_ACTIONS, k=3)
    challenge = BiometryChallenge(
        user_id=user.id,
        actions=json.dumps(actions, ensure_ascii=False),
        expires_at=_now() + timedelta(minutes=settings.biometry_challenge_expire_minutes),
    )
    db.add(challenge)
    await db.commit()
    await db.refresh(challenge)
    return challenge


async def verify_liveness(
    db: AsyncSession, user: User, challenge_id: str, passed: bool, suspected_replay: bool = False
) -> dict:
    result = await db.execute(select(BiometryChallenge).where(BiometryChallenge.id == challenge_id))
    challenge = result.scalar_one_or_none()

    if challenge is None or challenge.user_id != user.id:
        raise BiometryError("Challenge не найден", 404)
    if challenge.used_at is not None:
        # Повторное предъявление уже использованного challenge — это и
        # есть replay на уровне протокола, даже без suspected_replay от
        # клиента. Отклоняем безусловно.
        log_security_event("biometry_challenge_reuse_attempt", user_id=user.id)
        await record_security_event(
            db, "biometry_challenge_reuse", severity=SecurityEventSeverity.MEDIUM, email=user.email
        )
        raise BiometryError("Challenge уже был использован", 409)
    if _aware(challenge.expires_at) < _now():
        raise BiometryError("Срок действия challenge истёк, запросите новый", 410)

    challenge.used_at = _now()

    if suspected_replay:
        await db.commit()
        await record_audit_event(db, "biometry_replay_suspected", actor_id=user.id, target_id=user.id)
        log_security_event("biometry_replay_suspected", user_id=user.id)
        await record_security_event(
            db, "biometry_replay_suspected", severity=SecurityEventSeverity.HIGH, email=user.email
        )
        raise BiometryError("Проверка отклонена: подозрение на подмену/воспроизведение", 403)

    if not passed:
        user.biometry_failed_attempts += 1
        locked = user.biometry_failed_attempts >= settings.biometry_max_failed_attempts
        if locked:
            user.biometry_locked_until = _now() + timedelta(minutes=settings.biometry_lockout_minutes)
            user.biometry_failed_attempts = 0  # счётчик сбрасывается, отсчёт блокировки — по времени
        await db.commit()

        log_security_event("biometry_failed", user_id=user.id, details={"locked": locked})
        if locked:
            await record_audit_event(db, "biometry_locked_out", actor_id=user.id, target_id=user.id)
            await record_security_event(
                db, "biometry_locked_out", severity=SecurityEventSeverity.HIGH, email=user.email
            )
            return {
                "status": "locked",
                "detail": f"Превышен лимит попыток ({settings.biometry_max_failed_attempts}). "
                f"Биометрия заблокирована на {settings.biometry_lockout_minutes} мин, используйте пароль.",
            }
        return {"status": "failed", "retry_allowed": True}

    user.is_biometric_verified = True
    user.biometry_failed_attempts = 0
    user.biometry_locked_until = None
    await db.commit()
    await record_audit_event(db, "biometry_verified", actor_id=user.id, target_id=user.id)

    return {"status": "verified"}
