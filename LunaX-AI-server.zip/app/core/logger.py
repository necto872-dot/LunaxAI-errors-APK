"""
Централизованный логгер LunaX AI.

Согласно ТЗ (раздел 8, 17): подозрительные команды и события должны
логироваться, а для спорных случаев сохраняется серверная
доказательная база. Этот модуль — единая точка логирования для всего
проекта, чтобы впоследствии подключить сюда шифрование/отправку
в панель разработчика.
"""
import logging
import sys

from app.config.settings import get_settings

settings = get_settings()

_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(_LOG_FORMAT))
        logger.addHandler(handler)
        logger.setLevel(settings.log_level)
    return logger


def log_security_event(event: str, user_id: str | None = None, **details) -> None:
    """
    Единая точка логирования подозрительных/безопасностных событий
    (ТЗ п.8-9: антиподстава и блокировки).

    В проде сюда нужно добавить отправку события в панель разработчика
    (модуль 17) и в защищённое хранилище доказательной базы.
    """
    logger = get_logger("security")
    logger.warning("SECURITY_EVENT=%s user_id=%s details=%s", event, user_id, details)
