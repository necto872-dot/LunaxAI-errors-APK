"""
Telegram-уведомления (альтернатива/дополнение email для HIGH security-событий
— быстрее долетает на мобильный, см. app/core/security_events.py).
Best-effort: ошибка отправки только логируется, никогда не роняет вызывающий поток.
"""
import httpx

from app.config.settings import get_settings
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("telegram")


class TelegramSendError(Exception):
    pass


async def send_telegram(chat_id: str, text: str) -> None:
    if not settings.telegram_bot_token:
        raise TelegramSendError("TELEGRAM_BOT_TOKEN не задан")
    url = f"https://api.telegram.org/bot{settings.telegram_bot_token}/sendMessage"
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(url, json={"chat_id": chat_id, "text": text})
            resp.raise_for_status()
    except httpx.HTTPError as e:
        raise TelegramSendError(str(e)) from e
