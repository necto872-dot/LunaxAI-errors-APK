"""
Токен-квота LunaX AI — окончательная схема (согласована с владельцем в чате).

Правила:

- Лимиты по тарифам: FREE=5_000_000 (0₸), PRO=10_000_000 (10 000₸),
  PRO_PLUS=15_000_000 (15 000₸), ULTRA=20_000_000 (20 000₸),
  ULTRA_PLUS=25_000_000 (25 000₸). DEVELOPER/PRIMARY_DEVELOPER =
  50_000_000_000 (не тариф подписки, роль трактуется как unlimited).

- Отдельных лимитов на изображения/видео/демонстрацию экрана/сайт
  НЕТ — всё расходуется из token_balance через spend_tokens().

- Восстановление — ДВА независимых механизма:
  1. Безусловный полный сброс в 00:00 каждый календарный день,
     НЕЗАВИСИМО от того, сколько токенов осталось.
  2. Критическое восстановление: если после списания остаток падает
     ниже CRITICAL_BALANCE_THRESHOLD_TOKENS (недостаточно для одного
     полноценного действия), запускается индивидуальный таймер с
     МОМЕНТА этого критического списания (а не с момента последнего
     обычного запроса): 4ч (FREE), 3ч (PRO/PRO_PLUS), 2ч
     (ULTRA/ULTRA_PLUS). По истечении — полный сброс лимита, раньше
     полуночи, если критический момент наступил не в конце дня.

ОГРАНИЧЕНИЕ РЕАЛИЗАЦИИ (честно, без замалчивания): в проекте нет
фонового cron/scheduler-процесса. И суточный сброс, и критическое
восстановление применяются ЛЕНИВО — при первом обращении пользователя
после наступления соответствующего момента, а не строго по часам
сервера. Для точного тайминга (например push-уведомления ровно в
момент восстановления) понадобится реальный планировщик (RQ/Celery
beat) — не сделано в этом проходе.

ДОПУЩЕНИЕ (тоже честно): точное числовое значение "недостаточно для
одного полноценного действия" в постановке не задано (стоимость
AI-запроса в токенах ещё не определена, AI-цепочка не реализована).
Использовано CRITICAL_BALANCE_THRESHOLD_TOKENS = 100_000 как разумное
дефолтное значение — заменить, когда появится реальная стоимость
действия.
"""
from datetime import UTC, date, datetime, timedelta

from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import (
    CRITICAL_BALANCE_THRESHOLD_TOKENS,
    CRITICAL_RECOVERY_MINUTES,
    DEVELOPER_TOKEN_LIMIT,
    LOW_BALANCE_WARNING_PERCENT,
    TOKEN_LIMITS,
)
from app.core.logger import get_logger
from app.core.security_events import check_token_burn_spike
from app.database.models import User, UserRole

logger = get_logger("quota")


class InsufficientTokensError(Exception):
    def __init__(self, message: str = "Недостаточно токенов"):
        super().__init__(message)
        self.message = message


def _now() -> datetime:
    return datetime.now(UTC)


def _aware(dt: datetime) -> datetime:
    """Некоторые БД (например SQLite) при round-trip теряют tzinfo у
    DateTime-колонок и возвращают naive datetime, хотя значение было
    записано в UTC. Приводим к aware UTC перед сравнением, иначе
    `naive < aware`/`aware >= naive` кидает TypeError. Тот же паттерн,
    что в app/modules/auth/services.py — держать синхронно."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt


def _today() -> date:
    return _now().date()


def is_unlimited_role(user: User) -> bool:
    return user.role in (UserRole.DEVELOPER, UserRole.PRIMARY_DEVELOPER) or user.unlimited_usage


def token_limit_for(user: User) -> int:
    """Максимум токенов для пользователя по его роли/тарифу."""
    if user.role in (UserRole.DEVELOPER, UserRole.PRIMARY_DEVELOPER):
        return DEVELOPER_TOKEN_LIMIT
    return TOKEN_LIMITS.get(user.subscription_tier.value, TOKEN_LIMITS["free"])


def recovery_minutes_for(user: User) -> int | None:
    """
    Длительность индивидуального таймера критического восстановления.
    None для unlimited-ролей (Developer/Primary) — таймер для них не применим.
    """
    if is_unlimited_role(user):
        return None
    return CRITICAL_RECOVERY_MINUTES.get(user.subscription_tier.value, CRITICAL_RECOVERY_MINUTES["free"])


def _next_midnight_utc() -> datetime:
    tomorrow = _today() + timedelta(days=1)
    return datetime(tomorrow.year, tomorrow.month, tomorrow.day, tzinfo=UTC)


async def sync_quota_state(db: AsyncSession, user: User) -> User:
    """
    Применяет отложенные изменения баланса ПЕРЕД любой проверкой/списанием:

    1) Если наступил новый календарный день — безусловный полный сброс.
    2) Иначе, если активен таймер критического восстановления и он истёк —
       полный сброс (раньше полуночи).
    """
    if is_unlimited_role(user):
        return user

    today = _today()
    changed = False

    if user.last_daily_reset_date != today:
        user.token_balance = token_limit_for(user)
        user.critical_recovery_started_at = None
        user.last_daily_reset_date = today
        changed = True
        logger.info("Суточный сброс токенов (00:00): user_id=%s limit=%s", user.id, user.token_balance)
    elif user.critical_recovery_started_at is not None:
        recovery_minutes = recovery_minutes_for(user)
        if recovery_minutes is not None:
            deadline = _aware(user.critical_recovery_started_at) + timedelta(minutes=recovery_minutes)
            if _now() >= deadline:
                user.token_balance = token_limit_for(user)
                user.critical_recovery_started_at = None
                changed = True
                logger.info("Критическое восстановление токенов: user_id=%s limit=%s", user.id, user.token_balance)

    if changed:
        await db.commit()
        await db.refresh(user)
    return user


def _recovery_available_at(user: User) -> datetime | None:
    if user.critical_recovery_started_at is None:
        return None
    recovery_minutes = recovery_minutes_for(user)
    if recovery_minutes is None:
        return None
    return _aware(user.critical_recovery_started_at) + timedelta(minutes=recovery_minutes)


def low_balance_warning(user: User) -> dict | None:
    limit = token_limit_for(user)
    if limit <= 0:
        return None
    percent_left = (user.token_balance / limit) * 100
    if percent_left <= LOW_BALANCE_WARNING_PERCENT:
        return {
            "warning": "critically_low_tokens",
            "percent_left": round(percent_left, 2),
            "message": f"У вас осталось {round(percent_left, 2)}% токенов.",
        }
    return None


async def spend_tokens(db: AsyncSession, user: User, amount: int) -> dict:
    """
    Списывает `amount` токенов, если пользователь не unlimited и хватает
    баланса. Если после списания остаток падает ниже критического порога
    и таймер восстановления ещё не запущен — запускает его с текущего
    момента (момента именно этого критического списания).
    """
    if amount <= 0:
        raise ValueError("amount должен быть положительным")

    await sync_quota_state(db, user)

    if not is_unlimited_role(user):
        if user.token_balance < amount:
            raise InsufficientTokensError(
                f"Недостаточно токенов: доступно {user.token_balance}, требуется {amount}"
            )
        user.token_balance -= amount

        if user.token_balance < CRITICAL_BALANCE_THRESHOLD_TOKENS and user.critical_recovery_started_at is None:
            user.critical_recovery_started_at = _now()
            logger.info("Запущен критический таймер восстановления: user_id=%s", user.id)

        await db.commit()
        await db.refresh(user)
        await check_token_burn_spike(db, user, amount)

    return _status_payload(user, spent=amount)


def _status_payload(user: User, spent: int | None = None) -> dict:
    unlimited = is_unlimited_role(user)
    payload = {
        "token_balance": None if unlimited else user.token_balance,
        "token_limit": token_limit_for(user),
        "unlimited": unlimited,
        "critical_recovery_active": (not unlimited) and user.critical_recovery_started_at is not None,
        "recovery_available_at": None if unlimited else _recovery_available_at(user),
        "next_daily_reset_at": None if unlimited else _next_midnight_utc(),
        "low_balance_warning": None if unlimited else low_balance_warning(user),
    }
    if spent is not None:
        payload["spent"] = spent
    return payload


def quota_status(user: User) -> dict:
    return _status_payload(user)
