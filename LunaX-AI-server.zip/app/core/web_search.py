"""
Веб-поиск через self-hosted SearXNG. Формат — реальный SearXNG JSON API
(GET /search?q=...&format=json), это не выдумка — SearXNG действительно
отдаёт JSON при format=json (нужно включить в settings.yml инстанса:
search.formats: [html, json]).
"""
import ipaddress
import socket
from urllib.parse import urlparse

import httpx

from app.config.settings import get_settings
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("web_search")


class WebSearchNotConfiguredError(Exception):
    pass


class WebSearchRequestError(Exception):
    pass


class SSRFBlockedError(WebSearchRequestError):
    """URL резолвится в приватный/локальный адрес — запрос заблокирован."""


def _require_configured() -> None:
    if not settings.web_search_enabled or not settings.searxng_base_url:
        raise WebSearchNotConfiguredError(
            "Веб-поиск недоступен: web_search_enabled=False или searxng_base_url не заполнен в .env"
        )


def _is_blocked_ip(ip_str: str) -> bool:
    """
    True, если IP не должен быть доступен извне через fetch_page:
    loopback (127.0.0.0/8, ::1), приватные сети (RFC1918, RFC4193),
    link-local (169.254.0.0/16 — сюда попадает cloud metadata endpoint
    169.254.169.254 у AWS/GCP/Azure, это отдельно важно), multicast,
    reserved/unspecified.
    """
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return True  # не распарсился — не доверяем, блокируем
    return (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_multicast
        or ip.is_reserved
        or ip.is_unspecified
    )


def _resolve_and_validate_host(hostname: str) -> None:
    """
    Резолвит hostname и проверяет ВСЕ полученные адреса (A и AAAA) —
    хватает одного приватного/loopback среди них, чтобы заблокировать.

    ЧЕСТНОЕ ОГРАНИЧЕНИЕ (DNS rebinding): между этой проверкой и реальным
    TCP-соединением httpx резолвит домен заново — атакующий с полным
    контролем над DNS теоретически может подменить ответ между двумя
    резолвами (TOCTOU). Полная защита требует резолвить самому и
    подключаться по IP напрямую с Host-заголовком поверх, либо кастомный
    transport с зафиксированным resolver — не реализовано в этом проходе.
    Для большинства реальных SSRF-попыток (прямой localhost/RFC1918/
    metadata IP в URL) этой проверки достаточно.
    """
    try:
        addr_infos = socket.getaddrinfo(hostname, None)
    except socket.gaierror as e:
        raise WebSearchRequestError(f"Не удалось разрешить хост: {hostname}") from e

    for info in addr_infos:
        ip_str = info[4][0]
        if _is_blocked_ip(ip_str):
            logger.warning("SSRF-попытка заблокирована: %s -> %s", hostname, ip_str)
            raise SSRFBlockedError(f"Доступ к {hostname} ({ip_str}) запрещён — приватный/локальный адрес")


def _validate_url_for_ssrf(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise WebSearchRequestError("Некорректный URL: разрешены только http/https")
    if not parsed.hostname:
        raise WebSearchRequestError("Некорректный URL: не удалось определить хост")
    _resolve_and_validate_host(parsed.hostname)


async def search_web(query: str) -> list[dict]:
    """Возвращает список {"title", "url", "content"} — не более web_search_max_results."""
    _require_configured()
    base_url = settings.searxng_base_url.rstrip("/")

    async with httpx.AsyncClient(timeout=settings.web_search_timeout_seconds) as client:
        try:
            resp = await client.get(f"{base_url}/search", params={"q": query, "format": "json"})
            resp.raise_for_status()
        except httpx.HTTPError as e:
            logger.exception("Ошибка SearXNG")
            raise WebSearchRequestError(f"SearXNG недоступен: {e.__class__.__name__}") from e

    body = resp.json()
    results = body.get("results", [])[: settings.web_search_max_results]
    return [
        {"title": r.get("title", ""), "url": r.get("url", ""), "content": r.get("content", "")}
        for r in results
    ]


def format_results_for_context(results: list[dict]) -> str:
    """Сжимает результаты в текст для подмешивания в промпт AI."""
    if not results:
        return "Поиск не дал результатов."
    parts = [f"[{i+1}] {r['title']}\n{r['url']}\n{r['content']}" for i, r in enumerate(results)]
    return "Результаты веб-поиска:\n\n" + "\n\n".join(parts)


def _strip_html(html: str) -> str:
    import re

    html = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r"<style[^>]*>.*?</style>", "", html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", html)
    return re.sub(r"\s+", " ", text).strip()


_MAX_REDIRECTS = 5


async def fetch_page(url: str, max_chars: int = 5000) -> str:
    """
    Прямое чтение полной страницы (не только сниппет из поиска) — реальный
    доступ в интернет, не через SearXNG.

    SSRF-защита: URL и каждый редирект резолвятся и проверяются на
    приватные/loopback/link-local адреса (включая cloud metadata
    169.254.169.254) ДО того, как к ним пойдёт запрос — см.
    _validate_url_for_ssrf. Редиректы обрабатываются вручную
    (follow_redirects=False + свой цикл), а не через httpx
    follow_redirects=True, иначе сервер мог бы отдать 302 на
    http://127.0.0.1/... в обход проверки исходного URL.
    """
    if not settings.web_search_enabled:
        raise WebSearchNotConfiguredError("Веб-доступ отключён: web_search_enabled=False")

    current_url = url
    async with httpx.AsyncClient(timeout=settings.web_search_timeout_seconds, follow_redirects=False) as client:
        for _ in range(_MAX_REDIRECTS + 1):
            _validate_url_for_ssrf(current_url)
            try:
                resp = await client.get(current_url)
            except httpx.HTTPError as e:
                logger.exception("Ошибка fetch_page")
                raise WebSearchRequestError(f"Не удалось загрузить страницу: {e.__class__.__name__}") from e

            if resp.status_code in (301, 302, 303, 307, 308) and "location" in resp.headers:
                current_url = httpx.URL(current_url).join(resp.headers["location"]).human_repr()
                continue

            try:
                resp.raise_for_status()
            except httpx.HTTPError as e:
                raise WebSearchRequestError(f"Не удалось загрузить страницу: {e.__class__.__name__}") from e

            text = _strip_html(resp.text)
            return text[:max_chars]

    raise WebSearchRequestError(f"Превышен лимит редиректов ({_MAX_REDIRECTS})")
