"""
Расчёт стоимости AI-операций в токенах (финальное ТЗ Lunox AI, раздел 4-9).

Единый источник истины для стоимости: НИ ОДИН роутер не должен вызывать
spend_tokens() напрямую с придуманным числом — стоимость всегда считается
здесь, по утверждённым коэффициентам из app.config.settings.

Принцип "не начинать операцию, если баланс не хватит целиком" (раздел 5,
ТЗ): estimate_cost() считается ДО запуска дорогой операции, затем
reserve_and_spend() проверяет баланс и списывает атомарно одним вызовом
spend_tokens() — если баланса не хватает, операция не стартует вообще.

ЧЕСТНОЕ ОГРАНИЧЕНИЕ: это не "резервирование" в смысле блокировки средств
на время долгой генерации (нет фоновых воркеров/устойчивой очереди в этом
проходе) — списание происходит одномоментно перед стартом операции. Для
по-настоящему длинных асинхронных генераций (видео, APK) потребуется
двухфазная модель (reserve -> commit/release), которая не реализована.
"""
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import (
    TOKEN_COST_ARCHIVE_MULTIPLIER,
    TOKEN_COST_CODE_GENERATION,
    TOKEN_COST_FILE_PER_MB,
    TOKEN_COST_IMAGE,
    TOKEN_COST_TEXT_MESSAGE,
    TOKEN_COST_VIDEO_PER_SECOND,
)
from app.core.quota import InsufficientTokensError, spend_tokens
from app.database.models import User

ARCHIVE_EXTENSIONS = {"zip", "rar", "7z", "tar", "gz"}


def estimate_text_cost() -> float:
    """C1 — обычное текстовое сообщение (включая необходимую агентскую обработку)."""
    return TOKEN_COST_TEXT_MESSAGE


def estimate_image_cost(count: int = 1) -> float:
    """C2 — генерация изображения(й)."""
    return TOKEN_COST_IMAGE * count


def estimate_video_cost(seconds: float) -> float:
    """C3 — генерация видео, за секунду."""
    if seconds <= 0:
        raise ValueError("seconds должно быть положительным")
    return TOKEN_COST_VIDEO_PER_SECOND * seconds


def estimate_code_cost() -> float:
    """
    C4 — генерация кода (сообщение + кодовая нагрузка). TODO/CONFIG: точная
    формула учёта объёма/сложности/типа проекта не утверждена владельцем
    (финальное ТЗ раздел 8) — используется фиксированный коэффициент.
    """
    return TOKEN_COST_CODE_GENERATION


def estimate_file_cost(size_mb: float, extension: str = "") -> float:
    """C5 — файл/TXT за МБ, с множителем для архивов (TODO/CONFIG значение)."""
    if size_mb <= 0:
        raise ValueError("size_mb должно быть положительным")
    base = TOKEN_COST_FILE_PER_MB * size_mb
    if extension.lower().lstrip(".") in ARCHIVE_EXTENSIONS:
        base *= TOKEN_COST_ARCHIVE_MULTIPLIER
    return base


async def reserve_and_spend(db: AsyncSession, user: User, estimated_cost: float) -> dict:
    """
    Проверяет и списывает стоимость операции ДО её запуска.

    Стоимость округляется вверх до целого токена (нельзя списать долю
    токена в БД, поле BigInteger) — округление вверх исключает ситуацию,
    когда операция стартует, будучи фактически чуть дороже, чем позволяет
    остаток.

    Бросает InsufficientTokensError, если баланса не хватает — операция
    вызывающей стороной не должна запускаться в этом случае.
    """
    import math

    amount = max(1, math.ceil(estimated_cost))
    return await spend_tokens(db, user, amount)


__all__ = [
    "InsufficientTokensError",
    "estimate_code_cost",
    "estimate_file_cost",
    "estimate_image_cost",
    "estimate_text_cost",
    "estimate_video_cost",
    "reserve_and_spend",
]
