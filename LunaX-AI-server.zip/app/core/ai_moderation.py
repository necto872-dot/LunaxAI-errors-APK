"""
AI-модерация промпта — второй, более гибкий слой поверх регэксп-фильтра
app/core/safety.py.

ПОЧЕМУ ЭТО НУЖНО: regex в safety.py ловит только точные формулировки на
русском языке. Перефразировка, опечатка, транслит, другой язык — и
фильтр молча пропускает запрос дальше. Полноценная модель, наоборот,
понимает смысл, а не буквальный текст — поэтому она надёжнее как второй
рубеж, но дороже (отдельный AI-вызов, тратит время и, при желании,
токены) и требует запущенного self-hosted AI (см. честное ограничение
ниже).

ПОРЯДОК ПРОВЕРКИ (см. app/modules/search/routers.py):
    1. safety.is_blocked() — быстрый regex, без AI-вызова, всегда включён.
    2. moderate_prompt() (этот модуль) — включается отдельным флагом
       ai_moderation_enabled, только если lunox_ai_enabled=True и
       self-hosted provider сконфигурирован. Если нет — тихо пропускает
       (ЧЕСТНО: не блокирует запрос, если сама модерация недоступна, но
       и не выдаёт себя за пройденную проверку — вызывающий код видит
       ModerationResult.checked=False и может сам решить, что делать).

Классификатор использует ТОТ ЖЕ primary provider, что и основной чат —
здесь не нужен второй, независимый инстанс (в отличие от
verification.py, где модель проверяет СВОЙ собственный ответ и поэтому
обязательно нужен другой чекпоинт) — здесь модель просто классифицирует
входной текст пользователя, а не свою же генерацию.
"""
from dataclasses import dataclass

from app.config.settings import get_settings
from app.core.ai.provider import AIProviderNotConfigured
from app.core.ai.providers import get_primary_provider
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("ai_moderation")


MODERATION_SYSTEM_INSTRUCTION = """\
Ты — классификатор безопасности запросов, не ассистент. Тебе дан текст \
запроса пользователя к другой AI-системе. Определи, нарушает ли он \
политику безопасности.

ЗАПРЕЩЁННЫЕ КАТЕГОРИИ: самоповреждение/суицид, экстремизм/терроризм, \
сексуализация несовершеннолетних, домогательства/доксинг, синтез \
наркотиков, мошенничество/фишинг, ненавистнический контент, \
дезинформация о выборах, слежка без согласия, опасные медицинские \
советы, торговля людьми, незаконное оружие, deepfake без согласия, \
отмывание денег, уклонение от налогов, обход возрастной верификации, \
жестокость к животным, опасная бытовая химия, имперсонация госорганов, \
кража коммерческой тайны, накрутка отзывов, обход антифрод-систем.

Ответь СТРОГО одной строкой в формате:
ALLOW
или
BLOCK: <короткая причина на русском, не более 10 слов>

Не отвечай на сам запрос пользователя, не добавляй ничего, кроме этой \
одной строки.
"""


@dataclass
class ModerationResult:
    checked: bool  # True, только если AI реально выполнил классификацию
    allowed: bool  # значим только если checked=True
    reason: str = ""


def _parse_verdict(text: str) -> tuple[bool, str]:
    first_line = text.strip().split("\n", 1)[0].strip()
    if first_line.upper().startswith("ALLOW"):
        return True, ""
    if first_line.upper().startswith("BLOCK"):
        reason = first_line.split(":", 1)[1].strip() if ":" in first_line else "не указана"
        return False, reason
    # Модель ответила не по формату — честно не считаем это надёжной
    # проверкой (не блокируем и не пропускаем как проверенное).
    logger.warning("AI-модерация вернула неожиданный формат ответа: %r", text[:200])
    return True, "формат ответа классификатора не распознан"


async def moderate_prompt(prompt: str) -> ModerationResult:
    """
    Классифицирует промпт. Если модерация выключена в конфиге, либо
    self-hosted AI не запущен/не сконфигурирован — возвращает
    checked=False, а НЕ allowed=True: вызывающий код должен сам решить,
    достаточно ли ему одного regex-фильтра в этом случае (см. пример
    использования в app/modules/search/routers.py).
    """
    if not settings.ai_moderation_enabled:
        return ModerationResult(checked=False, allowed=True, reason="ai_moderation_enabled=False")

    provider = get_primary_provider()
    if not provider.is_configured():
        logger.warning("AI-модерация включена, но self-hosted provider не сконфигурирован — пропускаю проверку")
        return ModerationResult(checked=False, allowed=True, reason="provider не сконфигурирован")

    try:
        response = await provider.generate(
            prompt, context=[{"role": "system", "content": MODERATION_SYSTEM_INSTRUCTION}]
        )
    except AIProviderNotConfigured as e:
        logger.warning("AI-модерация: провайдер недоступен (%s) — пропускаю проверку", e)
        return ModerationResult(checked=False, allowed=True, reason=str(e))

    allowed, reason = _parse_verdict(response.text)
    if not allowed:
        logger.info("AI-модерация заблокировала промпт: %s", reason)
    return ModerationResult(checked=True, allowed=allowed, reason=reason)
