"""
Push-уведомления через FCM HTTP v1 (единственный живой FCM API — legacy
fcm.googleapis.com/fcm/send Google отключил в 2024). Один и тот же вызов
покрывает Android и iOS: FCM сам релеит на APNs для iOS-токенов.

Требует service account с ролью Firebase Cloud Messaging API Admin —
JSON-ключ целиком в settings.fcm_service_account_json (.env, одна строка).
Best-effort: ошибка только логируется, никогда не роняет вызывающий поток.
"""
import json

import httpx
from google.auth.transport.requests import Request as GoogleAuthRequest
from google.oauth2 import service_account

from app.config.settings import get_settings
from app.core.logger import get_logger

settings = get_settings()
logger = get_logger("push")

_SCOPES = ["https://www.googleapis.com/auth/firebase.messaging"]

_credentials: service_account.Credentials | None = None


class PushSendError(Exception):
    pass


def _get_access_token() -> str:
    global _credentials
    if not settings.fcm_service_account_json:
        raise PushSendError("FCM_SERVICE_ACCOUNT_JSON не задан")
    if _credentials is None:
        info = json.loads(settings.fcm_service_account_json)
        _credentials = service_account.Credentials.from_service_account_info(info, scopes=_SCOPES)
    if not _credentials.valid:
        _credentials.refresh(GoogleAuthRequest())
    return _credentials.token


async def send_push(fcm_token: str, title: str, body: str, data: dict | None = None) -> None:
    if not settings.fcm_project_id:
        raise PushSendError("FCM_PROJECT_ID не задан")

    token = _get_access_token()
    url = f"https://fcm.googleapis.com/v1/projects/{settings.fcm_project_id}/messages:send"
    payload = {
        "message": {
            "token": fcm_token,
            "notification": {"title": title, "body": body},
            "data": {k: str(v) for k, v in (data or {}).items()},
        }
    }
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                url, json=payload, headers={"Authorization": f"Bearer {token}"}
            )
            resp.raise_for_status()
    except httpx.HTTPError as e:
        raise PushSendError(str(e)) from e
