"""
Чёрный список IP ("Реакция на угрозы" — блокировка, не только детект).

Как и app/core/rate_limit.py, кэш блокировок — in-memory на процесс
(один worker). Источник истины — таблица blocked_ips; кэш лениво
перечитывается раз в settings.ip_blocklist_cache_ttl_seconds, чтобы не
бить в БД на каждый запрос. Явный block_ip()/unblock_ip() сразу обновляют
и БД, и кэш текущего процесса — при нескольких воркерах остальные
подхватят изменение по истечении TTL, не мгновенно (то же ограничение,
что честно описано в rate_limit.py).
"""
import time
from datetime import UTC, datetime, timedelta

from fastapi import Request, Response
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.middleware.base import BaseHTTPMiddleware

from app.config.settings import get_settings
from app.core.logger import get_logger
from app.database.models import BlockedIP

settings = get_settings()
logger = get_logger("ip_blocklist")

# ip -> expires_at (None = бессрочно)
_cache: dict[str, datetime | None] = {}
_cache_loaded_at: float = 0.0


def _aware(dt: datetime) -> datetime:
    return dt if dt.tzinfo is not None else dt.replace(tzinfo=UTC)


async def _refresh_cache(db: AsyncSession) -> None:
    global _cache_loaded_at
    now = datetime.now(UTC)
    result = await db.execute(select(BlockedIP))
    rows = list(result.scalars())
    _cache.clear()
    for row in rows:
        if row.expires_at is not None and _aware(row.expires_at) < now:
            continue
        _cache[row.ip_address] = row.expires_at
    _cache_loaded_at = time.monotonic()


async def is_blocked(db: AsyncSession, ip_address: str) -> bool:
    if time.monotonic() - _cache_loaded_at > settings.ip_blocklist_cache_ttl_seconds:
        await _refresh_cache(db)
    expires_at = _cache.get(ip_address)
    if ip_address not in _cache:
        return False
    if expires_at is not None and _aware(expires_at) < datetime.now(UTC):
        _cache.pop(ip_address, None)
        return False
    return True


async def block_ip(
    db: AsyncSession, ip_address: str, reason: str | None = None,
    minutes: int | None = None, actor_id: str | None = None,
) -> BlockedIP:
    expires_at = datetime.now(UTC) + timedelta(minutes=minutes) if minutes else None
    existing = await db.execute(select(BlockedIP).where(BlockedIP.ip_address == ip_address))
    row = existing.scalar_one_or_none()
    if row is None:
        row = BlockedIP(ip_address=ip_address)
        db.add(row)
    row.reason = reason
    row.expires_at = expires_at
    row.blocked_by_id = actor_id
    await db.commit()
    await db.refresh(row)
    _cache[ip_address] = expires_at
    return row


async def unblock_ip(db: AsyncSession, ip_address: str) -> bool:
    result = await db.execute(delete(BlockedIP).where(BlockedIP.ip_address == ip_address))
    await db.commit()
    _cache.pop(ip_address, None)
    return result.rowcount > 0


class IPBlocklistMiddleware(BaseHTTPMiddleware):
    """Отклоняет запрос 403 до того, как он дойдёт до роутера, если IP в
    чёрном списке. Использует отдельную сессию БД (middleware выполняется
    вне Depends(get_db) роутеров)."""

    async def dispatch(self, request: Request, call_next):
        if not settings.ip_blocklist_enabled:
            return await call_next(request)

        ip = request.client.host if request.client else None
        if ip:
            from app.database import async_session_maker

            async with async_session_maker() as db:
                if await is_blocked(db, ip):
                    logger.warning("Заблокированный IP отклонён: %s %s", ip, request.url.path)
                    return Response(
                        content='{"detail":"IP заблокирован"}',
                        status_code=403,
                        media_type="application/json",
                    )
        return await call_next(request)
