"""add users.last_login_ip

Revision ID: 0006_last_login_ip
Revises: 0005_security_events
Create Date: 2026-09-07

Нужна для детектора new_ip_after_credential_change
(app/core/security_events.py) — сравнивает IP текущего логина с
последним известным.

NOT VERIFIED: не прогонялась в этой sandbox (нет сети/пакета alembic).
Прогнать локально:
    alembic upgrade head
    alembic downgrade -1
    alembic upgrade head
"""
from alembic import op
import sqlalchemy as sa

revision = "0006_last_login_ip"
down_revision = "0005_security_events"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("users", sa.Column("last_login_ip", sa.String(64), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("users") as batch_op:
        batch_op.drop_column("last_login_ip")
