"""push devices (fcm)

Revision ID: 0009_push_devices
Revises: 0008_telegram_totp_ci_username
Create Date: 2026-09-07

users.push-token регистрация мобильного LunaX-клиента (app/core/push.py,
FCM HTTP v1) — push для HIGH security-событий.

NOT VERIFIED: не прогонялась в этой sandbox (нет сети/пакета alembic).
"""
from alembic import op
import sqlalchemy as sa

revision = "0009_push_devices"
down_revision = "0008_telegram_totp_ci_username"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "push_devices",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("platform", sa.Enum("android", "ios", name="pushplatform"), nullable=False),
        sa.Column("fcm_token", sa.String(512), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("last_seen_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_push_devices_user_id", "push_devices", ["user_id"])
    op.create_index("ix_push_devices_fcm_token", "push_devices", ["fcm_token"], unique=True)


def downgrade() -> None:
    op.drop_index("ix_push_devices_fcm_token", table_name="push_devices")
    op.drop_index("ix_push_devices_user_id", table_name="push_devices")
    op.drop_table("push_devices")
    op.execute("DROP TYPE IF EXISTS pushplatform")
