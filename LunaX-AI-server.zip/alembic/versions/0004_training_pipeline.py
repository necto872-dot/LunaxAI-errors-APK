"""add training-data consent flag + training_runs audit table

Revision ID: 0004_training_pipeline
Revises: 0003_user_age_terms
Create Date: 2026-09-05

Добавляет:
1. users.allow_training_data_use (bool, default False) — opt-in согласие
   пользователя на использование его диалогов в датасете для LoRA-
   дообучения Lunox AI. По умолчанию False для ВСЕХ строк, включая уже
   существующих пользователей: молчание — не согласие, соответствие
   выставляется явно через PATCH /auth/me/training-consent.
2. training_runs — аудируемая история прогонов training/auto_pipeline.py
   и решений Primary Developer об одобрении/отклонении/выкладке
   конкретного обученного адаптера.

NOT VERIFIED: написана вручную по образцу 0003_user_age_terms, не
прогонялась в этой sandbox-среде (нет сети/пакета alembic). Прогнать и
проверить локально:
    alembic upgrade head
    alembic downgrade -1
    alembic upgrade head
"""
from alembic import op
import sqlalchemy as sa

revision = "0004_training_pipeline"
down_revision = "0003_user_age_terms"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "users",
        sa.Column(
            "allow_training_data_use",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )

    op.create_table(
        "training_runs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "status",
            sa.Enum(
                "collecting",
                "training",
                "eval_passed",
                "eval_needs_review",
                "failed",
                "approved",
                "rejected",
                "deployed",
                "queued",
                name="trainingrunstatus",
            ),
            nullable=False,
            server_default="collecting",
        ),
        sa.Column("dataset_size", sa.BigInteger(), nullable=False, server_default="0"),
        sa.Column("adapter_path", sa.String(512), nullable=True),
        sa.Column("eval_summary", sa.JSON(), nullable=True),
        sa.Column("failure_reason", sa.String(2000), nullable=True),
        sa.Column("log", sa.String(), nullable=False, server_default=""),
        sa.Column("tier", sa.String(32), nullable=False, server_default="pro"),
        sa.Column("max_conversations", sa.BigInteger(), nullable=False, server_default="500"),
        sa.Column("epochs", sa.BigInteger(), nullable=False, server_default="3"),
        sa.Column("triggered_by_id", sa.String(36), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("submitted_examples", sa.JSON(), nullable=True),
        sa.Column("queue_job_id", sa.String(64), nullable=True),
        sa.Column("reviewed_by_id", sa.String(36), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("reviewed_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.text("CURRENT_TIMESTAMP")),
        sa.Column("updated_at", sa.DateTime(), nullable=False, server_default=sa.text("CURRENT_TIMESTAMP")),
    )
    op.create_index("ix_training_runs_status", "training_runs", ["status"])
    op.create_index("ix_training_runs_created_at", "training_runs", ["created_at"])


def downgrade() -> None:
    op.drop_index("ix_training_runs_created_at", table_name="training_runs")
    op.drop_index("ix_training_runs_status", table_name="training_runs")
    op.drop_table("training_runs")
    with op.batch_alter_table("users") as batch_op:
        batch_op.drop_column("allow_training_data_use")
