"""threat response: temp ban, session revoke, ip blocklist

Revision ID: 0007_threat_response
Revises: 0006_last_login_ip
Create Date: 2026-09-07

Добавляет:
- users.banned_until / banned_reason — временный бан (ручной или авто по
  N HIGH security-событиям, app/core/security_events.py:_check_auto_actions);
- users.session_revoked_before — отзыв всех выданных JWT
  (/revoke-sessions, app/core/console_commands.py);
- таблица blocked_ips — чёрный список IP (app/core/ip_blocklist.py).

NOT VERIFIED: не прогонялась в этой sandbox (нет сети/пакета alembic).
Прогнать локально:
    alembic upgrade head
    alembic downgrade -1
    alembic upgrade head
"""
from alembic import op
import sqlalchemy as sa

revision = "0007_threat_response"
down_revision = "0006_last_login_ip"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("users", sa.Column("banned_until", sa.DateTime(), nullable=True))
    op.create_index("ix_users_banned_until", "users", ["banned_until"])
    op.add_column("users", sa.Column("banned_reason", sa.String(255), nullable=True))
    op.add_column("users", sa.Column("session_revoked_before", sa.DateTime(), nullable=True))

    op.create_table(
        "blocked_ips",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("ip_address", sa.String(64), nullable=False),
        sa.Column("reason", sa.String(255), nullable=True),
        sa.Column("blocked_by_id", sa.String(36), nullable=True),
        sa.Column("expires_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_blocked_ips_ip_address", "blocked_ips", ["ip_address"], unique=True)


def downgrade() -> None:
    op.drop_index("ix_blocked_ips_ip_address", table_name="blocked_ips")
    op.drop_table("blocked_ips")
    with op.batch_alter_table("users") as batch_op:
        batch_op.drop_column("session_revoked_before")
        batch_op.drop_column("banned_reason")
        batch_op.drop_index("ix_users_banned_until")
        batch_op.drop_column("banned_until")
