"""add queue_job_id to build_jobs and apk_build_jobs

Revision ID: 0002_queue_job_id
Revises: 0001_initial
Create Date: 2026-09-03

Часть перевода сборки APK и генерации проектов на приоритетную очередь
(app/core/queue.py) вместо блокирующего выполнения внутри HTTP-запроса —
см. app/core/build/apk.py и app/core/projects/generator.py
(enqueue_apk_build / enqueue_project_generation). queue_job_id хранит id
задачи в RQ, чтобы можно было сопоставить строку БД с состоянием в очереди
(и, при необходимости, отменить/повторно проверить задачу через
app/core/queue.py:get_job_status/cancel_job).

NOT VERIFIED: написана вручную по образцу 0001_initial, не прогонялась
в этой sandbox-среде (нет сети/пакета alembic). Прогнать и проверить
локально:
    alembic upgrade head
    alembic downgrade -1
    alembic upgrade head
"""
from alembic import op
import sqlalchemy as sa

revision = "0002_queue_job_id"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("build_jobs", sa.Column("queue_job_id", sa.String(64), nullable=True))
    op.add_column("apk_build_jobs", sa.Column("queue_job_id", sa.String(64), nullable=True))


def downgrade() -> None:
    op.drop_column("apk_build_jobs", "queue_job_id")
    op.drop_column("build_jobs", "queue_job_id")
