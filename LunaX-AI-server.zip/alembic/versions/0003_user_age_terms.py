"""add date_of_birth + terms acceptance to users (16+ age gate)

Revision ID: 0003_user_age_terms
Revises: 0002_queue_job_id
Create Date: 2026-09-03

Добавляет обязательную дату рождения и факт принятия пользовательского
соглашения (владелец: минимальный возраст регистрации 16 лет, не меньше —
см. settings.min_registration_age_years и валидацию в
app/modules/auth/schemas.py:UserRegister).

СУЩЕСТВУЮЩИЕ СТРОКИ: у пользователей, зарегистрированных до этой миграции,
данных о дате рождения физически нет — взять их неоткуда, платформа их не
запрашивала. Поэтому колонка добавляется как nullable, заполняется
плейсхолдером для уже существующих строк (не проходившим новую проверку
возраста — это осознанный компромисс, не подтверждение их возраста), и
только после бэкфилла переводится в NOT NULL. Для чистой новой базы (нет
существующих пользователей) шаги 2-3 — no-op.

NOT VERIFIED: написана вручную по образцу 0001_initial/0002_queue_job_id,
не прогонялась в этой sandbox-среде (нет сети/пакета alembic). Прогнать
и проверить локально:
    alembic upgrade head
    alembic downgrade -1
    alembic upgrade head
"""
from alembic import op
import sqlalchemy as sa

revision = "0003_user_age_terms"
down_revision = "0002_queue_job_id"
branch_labels = None
depends_on = None

# Плейсхолдер для строк, созданных до этой миграции — НЕ означает, что
# пользователю реально 2000-01-01 года рождения; это лишь техническая
# заглушка, чтобы избежать NULL в новой обязательной колонке у старых
# аккаунтов. Реальная проверка возраста применяется только к новым
# регистрациям через UserRegister.
_PLACEHOLDER_DOB = "2000-01-01"
_DEFAULT_TERMS_VERSION = "1.0"


def upgrade() -> None:
    # Шаг 1: добавляем колонки как nullable — иначе ALTER TABLE упадёт на
    # существующих строках (SQLite/Postgres оба требуют default или
    # nullable при добавлении NOT NULL колонки в непустую таблицу).
    op.add_column("users", sa.Column("date_of_birth", sa.Date(), nullable=True))
    op.add_column(
        "users",
        sa.Column(
            "terms_accepted_at",
            sa.DateTime(),
            nullable=True,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
    )
    op.add_column(
        "users",
        sa.Column(
            "terms_version",
            sa.String(16),
            nullable=True,
            server_default=_DEFAULT_TERMS_VERSION,
        ),
    )

    # Шаг 2: бэкфилл для строк, существовавших до миграции.
    users_table = sa.table(
        "users",
        sa.column("date_of_birth", sa.Date()),
        sa.column("terms_version", sa.String()),
    )
    op.execute(
        users_table.update()
        .where(users_table.c.date_of_birth.is_(None))
        .values(date_of_birth=_PLACEHOLDER_DOB)
    )
    op.execute(
        users_table.update()
        .where(users_table.c.terms_version.is_(None))
        .values(terms_version=_DEFAULT_TERMS_VERSION)
    )

    # Шаг 3: теперь, когда NULL-значений не осталось, переводим в NOT NULL.
    with op.batch_alter_table("users") as batch_op:
        batch_op.alter_column("date_of_birth", existing_type=sa.Date(), nullable=False)
        batch_op.alter_column("terms_accepted_at", existing_type=sa.DateTime(), nullable=False)
        batch_op.alter_column("terms_version", existing_type=sa.String(16), nullable=False)


def downgrade() -> None:
    with op.batch_alter_table("users") as batch_op:
        batch_op.drop_column("terms_version")
        batch_op.drop_column("terms_accepted_at")
        batch_op.drop_column("date_of_birth")
