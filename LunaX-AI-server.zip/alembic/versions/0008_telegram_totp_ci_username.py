"""telegram, totp 2fa, case-insensitive username

Revision ID: 0008_telegram_totp_ci_username
Revises: 0007_threat_response
Create Date: 2026-09-07

- users.telegram_chat_id — Telegram-уведомления (app/core/telegram.py)
- users.totp_secret/totp_enabled — 2FA консоли (app/core/totp.py)
- уникальный индекс по lower(username) — "Nick"/"nick" больше не два
  разных ника (app/modules/auth/services.py:get_user_by_username теперь
  тоже сравнивает регистронезависимо)

NOT VERIFIED: не прогонялась в этой sandbox (нет сети/пакета alembic).
Перед upgrade убедись, что в БД ещё нет двух юзеров с одинаковым
username в разном регистре — иначе создание индекса упадёт; если есть,
сначала вручную переименуй дубликаты.
"""
from alembic import op
import sqlalchemy as sa

revision = "0008_telegram_totp_ci_username"
down_revision = "0007_threat_response"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("users", sa.Column("telegram_chat_id", sa.String(64), nullable=True))
    op.add_column("users", sa.Column("totp_secret", sa.String(64), nullable=True))
    op.add_column("users", sa.Column("totp_enabled", sa.Boolean(), nullable=False, server_default=sa.false()))
    op.execute("CREATE UNIQUE INDEX ix_users_username_lower ON users (lower(username))")


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS ix_users_username_lower")
    with op.batch_alter_table("users") as batch_op:
        batch_op.drop_column("totp_enabled")
        batch_op.drop_column("totp_secret")
        batch_op.drop_column("telegram_chat_id")
