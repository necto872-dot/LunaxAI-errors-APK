"""initial schema: users, roles incl. PRIMARY_DEVELOPER, tokens, audit log

Revision ID: 0001_initial
Revises:
Create Date: 2026-08-23

NOT VERIFIED: written by hand to match app/database/models.py; has not
been executed against a real database in this environment (no network /
no alembic package available in this sandbox). Run and verify locally:
    alembic upgrade head
    alembic downgrade -1
    alembic upgrade head
    alembic heads
"""
from alembic import op
import sqlalchemy as sa

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None

user_role_enum = sa.Enum(
    "user", "premium", "developer", "primary_developer", "admin", name="userrole"
)
subscription_tier_enum = sa.Enum(
    "free", "pro", "pro_plus", "ultra", "ultra_plus", name="subscriptiontier"
)
payment_status_enum = sa.Enum("pending", "succeeded", "failed", "refunded", name="paymentstatus")
message_role_enum = sa.Enum("user", "assistant", name="messagerole")
project_status_enum = sa.Enum("draft", "generating", "ready", "failed", name="projectstatus")
build_job_status_enum = sa.Enum("queued", "running", "succeeded", "failed", name="buildjobstatus")
apk_build_job_status_enum = sa.Enum("queued", "running", "succeeded", "failed", name="apkbuildjobstatus")
song_stage_enum = sa.Enum(
    "awaiting_lyrics_or_recording_choice", "awaiting_voice_choice", "awaiting_consent",
    "awaiting_samples", "ready", name="songsessionstage",
)


def upgrade() -> None:
    bind = op.get_bind()
    user_role_enum.create(bind, checkfirst=True)
    subscription_tier_enum.create(bind, checkfirst=True)
    payment_status_enum.create(bind, checkfirst=True)
    message_role_enum.create(bind, checkfirst=True)
    project_status_enum.create(bind, checkfirst=True)
    build_job_status_enum.create(bind, checkfirst=True)
    apk_build_job_status_enum.create(bind, checkfirst=True)
    song_stage_enum.create(bind, checkfirst=True)

    op.create_table(
        "users",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("email", sa.String(255), nullable=False, unique=True),
        sa.Column("username", sa.String(64), nullable=False, unique=True),
        sa.Column("hashed_password", sa.String(255), nullable=False),
        sa.Column("role", user_role_enum, nullable=False, server_default="user"),
        sa.Column("subscription_tier", subscription_tier_enum, nullable=False, server_default="free"),
        sa.Column("token_balance", sa.BigInteger(), nullable=False, server_default="5000000"),
        sa.Column("token_limit", sa.BigInteger(), nullable=False, server_default="5000000"),
        sa.Column("unlimited_usage", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("last_daily_reset_date", sa.Date(), nullable=True),
        sa.Column("critical_recovery_started_at", sa.DateTime(), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("email_verified", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("is_biometric_verified", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("biometry_failed_attempts", sa.BigInteger(), nullable=False, server_default="0"),
        sa.Column("biometry_locked_until", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("last_login_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_users_email", "users", ["email"])
    op.create_index("ix_users_username", "users", ["username"])

    op.create_table(
        "email_verification_tokens",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("token_hash", sa.String(255), nullable=False, unique=True),
        sa.Column("expires_at", sa.DateTime(), nullable=False),
        sa.Column("used_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_evt_user_id", "email_verification_tokens", ["user_id"])
    op.create_index("ix_evt_token_hash", "email_verification_tokens", ["token_hash"])

    op.create_table(
        "password_reset_tokens",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("token_hash", sa.String(255), nullable=False, unique=True),
        sa.Column("expires_at", sa.DateTime(), nullable=False),
        sa.Column("used_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_prt_user_id", "password_reset_tokens", ["user_id"])
    op.create_index("ix_prt_token_hash", "password_reset_tokens", ["token_hash"])

    op.create_table(
        "email_change_tokens",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("new_email", sa.String(255), nullable=False),
        sa.Column("token_hash", sa.String(255), nullable=False, unique=True),
        sa.Column("expires_at", sa.DateTime(), nullable=False),
        sa.Column("used_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_ect_user_id", "email_change_tokens", ["user_id"])
    op.create_index("ix_ect_token_hash", "email_change_tokens", ["token_hash"])

    op.create_table(
        "audit_logs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("event", sa.String(128), nullable=False),
        sa.Column("actor_id", sa.String(36), nullable=True),
        sa.Column("target_id", sa.String(36), nullable=True),
        sa.Column("details", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_audit_logs_event", "audit_logs", ["event"])
    op.create_index("ix_audit_logs_actor_id", "audit_logs", ["actor_id"])
    op.create_index("ix_audit_logs_target_id", "audit_logs", ["target_id"])
    op.create_index("ix_audit_logs_created_at", "audit_logs", ["created_at"])

    op.create_table(
        "uploaded_files",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("owner_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("original_filename", sa.String(255), nullable=False),
        sa.Column("stored_filename", sa.String(64), nullable=False, unique=True),
        sa.Column("content_type", sa.String(128), nullable=False),
        sa.Column("size_bytes", sa.BigInteger(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_uploaded_files_owner_id", "uploaded_files", ["owner_id"])

    op.create_table(
        "payments",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("provider", sa.String(32), nullable=False),
        sa.Column("external_payment_id", sa.String(128), nullable=True, unique=True),
        sa.Column("tariff", subscription_tier_enum, nullable=False),
        sa.Column("amount_kzt", sa.BigInteger(), nullable=False),
        sa.Column("status", payment_status_enum, nullable=False, server_default="pending"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_payments_user_id", "payments", ["user_id"])
    op.create_index("ix_payments_external_payment_id", "payments", ["external_payment_id"])

    op.create_table(
        "payment_events",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("payment_id", sa.String(36), sa.ForeignKey("payments.id"), nullable=True),
        sa.Column("provider", sa.String(32), nullable=False),
        sa.Column("event_type", sa.String(64), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_payment_events_payment_id", "payment_events", ["payment_id"])
    op.create_index("ix_payment_events_created_at", "payment_events", ["created_at"])

    op.create_table(
        "conversations",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("owner_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("title", sa.String(255), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_conversations_owner_id", "conversations", ["owner_id"])

    op.create_table(
        "messages",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("conversation_id", sa.String(36), sa.ForeignKey("conversations.id"), nullable=False),
        sa.Column("role", message_role_enum, nullable=False),
        sa.Column("content", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_messages_conversation_id", "messages", ["conversation_id"])
    op.create_index("ix_messages_created_at", "messages", ["created_at"])

    op.create_table(
        "user_memory_facts",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("owner_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("content", sa.String(2000), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_user_memory_facts_owner_id", "user_memory_facts", ["owner_id"])

    op.create_table(
        "biometry_challenges",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("actions", sa.String(500), nullable=False),
        sa.Column("expires_at", sa.DateTime(), nullable=False),
        sa.Column("used_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_biometry_challenges_user_id", "biometry_challenges", ["user_id"])

    op.create_table(
        "update_confirmation_tokens",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("requested_by", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("target_version", sa.String(64), nullable=False),
        sa.Column("token_hash", sa.String(255), nullable=False, unique=True),
        sa.Column("expires_at", sa.DateTime(), nullable=False),
        sa.Column("used_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_update_confirmation_tokens_requested_by", "update_confirmation_tokens", ["requested_by"])
    op.create_index("ix_update_confirmation_tokens_token_hash", "update_confirmation_tokens", ["token_hash"])

    op.create_table(
        "projects",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("owner_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("prompt", sa.Text(), nullable=False),
        sa.Column("status", project_status_enum, nullable=False, server_default="draft"),
        sa.Column("current_version", sa.BigInteger(), nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_projects_owner_id", "projects", ["owner_id"])

    op.create_table(
        "project_versions",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("project_id", sa.String(36), sa.ForeignKey("projects.id"), nullable=False),
        sa.Column("version_number", sa.BigInteger(), nullable=False),
        sa.Column("file_manifest", sa.JSON(), nullable=False),
        sa.Column("validation_passed", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("artifact_path", sa.String(255), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_project_versions_project_id", "project_versions", ["project_id"])

    op.create_table(
        "build_jobs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("project_id", sa.String(36), sa.ForeignKey("projects.id"), nullable=False),
        sa.Column("project_version_id", sa.String(36), sa.ForeignKey("project_versions.id"), nullable=True),
        sa.Column("status", build_job_status_enum, nullable=False, server_default="queued"),
        sa.Column("attempt_count", sa.BigInteger(), nullable=False, server_default="0"),
        sa.Column("log", sa.Text(), nullable=False, server_default=""),
        sa.Column("started_at", sa.DateTime(), nullable=True),
        sa.Column("finished_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_build_jobs_project_id", "build_jobs", ["project_id"])

    op.create_table(
        "voice_profiles",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("owner_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("consent_given_at", sa.DateTime(), nullable=False),
        sa.Column("pitch_low_hz", sa.Float(), nullable=True),
        sa.Column("pitch_high_hz", sa.Float(), nullable=True),
        sa.Column("sample_storage_path", sa.String(255), nullable=True),
        sa.Column("expires_at", sa.DateTime(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_voice_profiles_owner_id", "voice_profiles", ["owner_id"])

    op.create_table(
        "song_sessions",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("owner_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("stage", song_stage_enum, nullable=False, server_default="awaiting_lyrics_or_recording_choice"),
        sa.Column("lyrics", sa.Text(), nullable=True),
        sa.Column("genre", sa.String(64), nullable=True),
        sa.Column("mood", sa.String(64), nullable=True),
        sa.Column("use_own_voice", sa.Boolean(), nullable=True),
        sa.Column("voice_profile_id", sa.String(36), sa.ForeignKey("voice_profiles.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_song_sessions_owner_id", "song_sessions", ["owner_id"])

    op.create_table(
        "apk_build_jobs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("project_id", sa.String(36), sa.ForeignKey("projects.id"), nullable=False),
        sa.Column("owner_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("status", apk_build_job_status_enum, nullable=False, server_default="queued"),
        sa.Column("log", sa.Text(), nullable=False, server_default=""),
        sa.Column("artifact_path", sa.String(255), nullable=True),
        sa.Column("started_at", sa.DateTime(), nullable=True),
        sa.Column("finished_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_apk_build_jobs_project_id", "apk_build_jobs", ["project_id"])
    op.create_index("ix_apk_build_jobs_owner_id", "apk_build_jobs", ["owner_id"])


def downgrade() -> None:
    op.drop_table("apk_build_jobs")
    op.drop_table("song_sessions")
    op.drop_table("voice_profiles")
    op.drop_table("build_jobs")
    op.drop_table("project_versions")
    op.drop_table("projects")
    op.drop_table("update_confirmation_tokens")
    op.drop_table("biometry_challenges")
    op.drop_table("user_memory_facts")
    op.drop_table("messages")
    op.drop_table("conversations")
    op.drop_table("payment_events")
    op.drop_table("payments")
    op.drop_table("uploaded_files")
    op.drop_table("audit_logs")
    op.drop_table("email_change_tokens")
    op.drop_table("password_reset_tokens")
    op.drop_table("email_verification_tokens")
    op.drop_index("ix_users_username", table_name="users")
    op.drop_index("ix_users_email", table_name="users")
    op.drop_table("users")

    bind = op.get_bind()
    song_stage_enum.drop(bind, checkfirst=True)
    apk_build_job_status_enum.drop(bind, checkfirst=True)
    build_job_status_enum.drop(bind, checkfirst=True)
    project_status_enum.drop(bind, checkfirst=True)
    message_role_enum.drop(bind, checkfirst=True)
    payment_status_enum.drop(bind, checkfirst=True)
    subscription_tier_enum.drop(bind, checkfirst=True)
    user_role_enum.drop(bind, checkfirst=True)
