"""add security_events table (Developer Console reports)

Revision ID: 0005_security_events
Revises: 0004_training_pipeline
Create Date: 2026-09-07

Отчёты о подозрительной активности для раздела "Отчёты" Консоли
разработчика (app/core/security_events.py). Пока один источник —
серия неудачных логинов по email за окно времени.

NOT VERIFIED: написана по образцу 0004, не прогонялась в этой sandbox
(нет сети/пакета alembic). Прогнать локально:
    alembic upgrade head
    alembic downgrade -1
    alembic upgrade head
"""
from alembic import op
import sqlalchemy as sa

revision = "0005_security_events"
down_revision = "0004_training_pipeline"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "security_events",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("event_type", sa.String(64), nullable=False),
        sa.Column(
            "severity",
            sa.Enum("low", "medium", "high", name="securityeventseverity"),
            nullable=False,
            server_default="low",
        ),
        sa.Column("email", sa.String(255), nullable=True),
        sa.Column("ip_address", sa.String(64), nullable=True),
        sa.Column("details", sa.JSON(), nullable=True),
        sa.Column("resolved", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("resolved_by_id", sa.String(36), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("resolved_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.text("CURRENT_TIMESTAMP")),
    )
    op.create_index("ix_security_events_event_type", "security_events", ["event_type"])
    op.create_index("ix_security_events_email", "security_events", ["email"])
    op.create_index("ix_security_events_ip_address", "security_events", ["ip_address"])
    op.create_index("ix_security_events_resolved", "security_events", ["resolved"])
    op.create_index("ix_security_events_created_at", "security_events", ["created_at"])


def downgrade() -> None:
    op.drop_index("ix_security_events_created_at", table_name="security_events")
    op.drop_index("ix_security_events_resolved", table_name="security_events")
    op.drop_index("ix_security_events_ip_address", table_name="security_events")
    op.drop_index("ix_security_events_email", table_name="security_events")
    op.drop_index("ix_security_events_event_type", table_name="security_events")
    op.drop_table("security_events")
