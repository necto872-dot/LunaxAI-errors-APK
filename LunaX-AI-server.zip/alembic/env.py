"""
Alembic environment for LunaX AI.

Использует DATABASE_URL из app.config.settings, а не хардкод, и
конвертирует async-URL (например sqlite+aiosqlite / postgresql+asyncpg)
в синхронный эквивалент для offline/online миграций Alembic.

NOT VERIFIED: `alembic upgrade head` не был фактически выполнен в
sandbox-окружении (пакет alembic недоступен offline, сеть отключена).
Перед продакшн-использованием выполните на своей машине:
    alembic upgrade head
    alembic downgrade -1
    alembic upgrade head
    alembic heads
"""
import sys
from logging.config import fileConfig
from pathlib import Path

from alembic import context
from sqlalchemy import engine_from_config, pool

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config.settings import get_settings  # noqa: E402
from app.database import Base  # noqa: E402
from app.database import models  # noqa: E402,F401  (регистрирует все модели в Base.metadata)

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def _sync_database_url() -> str:
    url = get_settings().database_url
    return (
        url.replace("postgresql+asyncpg", "postgresql")
        .replace("sqlite+aiosqlite", "sqlite")
    )


def run_migrations_offline() -> None:
    url = _sync_database_url()
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    configuration = config.get_section(config.config_ini_section) or {}
    configuration["sqlalchemy.url"] = _sync_database_url()
    connectable = engine_from_config(configuration, prefix="sqlalchemy.", poolclass=pool.NullPool)

    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
