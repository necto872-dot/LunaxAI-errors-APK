"""
Автопайплайн дообучения Lunox AI: одна команда вместо пяти ручных шагов.

    сбор диалогов (collect_from_db.py, только opt-in пользователи)
        -> подготовка датасета (prepare_dataset.py)
        -> LoRA-обучение (train_lora.py)
        -> слияние с базовой моделью (merge_and_export.py)
        -> самопроверка (eval_candidate.py)
        -> запись TrainingRun в БД со статусом eval_passed/eval_needs_review/failed

ГДЕ ЭТОТ ПАЙПЛАЙН ОСТАНАВЛИВАЕТСЯ И ПОЧЕМУ:
Он НИКОГДА не выкатывает результат в прод сам и не трогает
settings.self_hosted_base_url / self_hosted_model_name. Это не
искусственное ограничение "на всякий случай", а связка двух реальных
причин:

1. Техническая: инференс-сервер (vLLM/Ollama) — отдельный процесс на
   отдельной GPU-машине, этот скрипт (и вообще бэкенд LunaX AI) его не
   перезапускает и не подгружает в него веса напрямую.
2. Смысловая: результат самопроверки (eval_candidate.py) — это узкая
   эвристика по ключевым словам, а не гарантия качества. Автоматически
   выкатывать в прод модель, которая отвечает за реальных пользователей,
   на основании одной эвристики — то, как модели тихо деградируют или
   съезжают по безопасности незаметно для владельца продукта.

Финальный шаг — Primary Developer смотрит training/eval_report.json,
сам разворачивает ./lunox-merged-model на инференс-сервере и жмёт
"Подтвердить" в Developer Console (POST /developer/training-runs/{id}/approve),
который отдельно записывает, кто и когда принял решение (аудит-лог).

Запуск (пример):
    python training/auto_pipeline.py \\
        --tier pro \\
        --max-conversations 500 \\
        --epochs 3

ЧЕСТНОЕ ОГРАНИЧЕНИЕ: шаги train_lora.py/merge_and_export.py/
eval_candidate.py требуют GPU и пакетов из training/requirements.txt —
этот оркестратор не запускался целиком в sandbox (нет GPU здесь),
проверена только логика склейки шагов и запись в БД.
"""
import argparse
import asyncio
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.database import async_session_maker  # noqa: E402
from app.database.models import TrainingRun, TrainingRunStatus  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent


def _run(cmd: list[str], step_name: str) -> subprocess.CompletedProcess:
    print(f"\n=== {step_name} ===")
    print("$", " ".join(cmd))
    result = subprocess.run(cmd, cwd=ROOT)
    if result.returncode != 0:
        print(f"[{step_name}] завершился с кодом {result.returncode}")
    return result


async def _create_run() -> str:
    async with async_session_maker() as db:
        run = TrainingRun(status=TrainingRunStatus.COLLECTING)
        db.add(run)
        await db.commit()
        await db.refresh(run)
        return run.id


async def _update_run(run_id: str, **fields) -> None:
    async with async_session_maker() as db:
        run = await db.get(TrainingRun, run_id)
        if run is None:
            return
        for key, value in fields.items():
            setattr(run, key, value)
        await db.commit()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tier", default="pro", help="См. training/tier_configs.py")
    parser.add_argument("--max-conversations", type=int, default=500)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--work-dir", type=Path, default=Path("training/_runs/latest"))
    args = parser.parse_args()

    args.work_dir.mkdir(parents=True, exist_ok=True)
    raw_path = args.work_dir / "raw_conversations.json"
    dataset_path = args.work_dir / "dataset.jsonl"
    adapter_dir = args.work_dir / "lora-adapter"
    merged_dir = args.work_dir / "merged-model"
    report_path = args.work_dir / "eval_report.json"

    run_id = asyncio.run(_create_run())
    print(f"TrainingRun создан: {run_id}")

    # 1. Сбор реальных диалогов (только opt-in пользователи)
    collect_result = _run(
        [sys.executable, "training/collect_from_db.py", "--output", str(raw_path),
         "--max-conversations", str(args.max_conversations)],
        "1/5 Сбор диалогов из БД",
    )
    if collect_result.returncode != 0:
        asyncio.run(_update_run(run_id, status=TrainingRunStatus.FAILED, failure_reason="collect_from_db failed"))
        sys.exit(1)

    pairs = json.loads(raw_path.read_text(encoding="utf-8"))
    if not pairs:
        print("Диалогов с согласием пользователя не найдено — обучать не на чем. Прогон остановлен.")
        asyncio.run(
            _update_run(
                run_id,
                status=TrainingRunStatus.FAILED,
                failure_reason="no opted-in conversations available",
                dataset_size=0,
            )
        )
        sys.exit(0)

    # 2. Подготовка датасета (+ инъекция persona.py)
    prepare_result = _run(
        [sys.executable, "training/prepare_dataset.py", "--input", str(raw_path),
         "--output", str(dataset_path), "--inject-persona"],
        "2/5 Подготовка датасета",
    )
    if prepare_result.returncode != 0:
        asyncio.run(_update_run(run_id, status=TrainingRunStatus.FAILED, failure_reason="prepare_dataset failed"))
        sys.exit(1)

    asyncio.run(_update_run(run_id, status=TrainingRunStatus.TRAINING, dataset_size=len(pairs)))

    # 3. LoRA-обучение
    train_result = _run(
        [sys.executable, "training/train_lora.py", "--tier", args.tier, "--dataset", str(dataset_path),
         "--output-dir", str(adapter_dir), "--epochs", str(args.epochs)],
        "3/5 LoRA-обучение",
    )
    if train_result.returncode != 0:
        asyncio.run(_update_run(run_id, status=TrainingRunStatus.FAILED, failure_reason="train_lora failed"))
        sys.exit(1)

    # 4. Слияние адаптера с базовой моделью
    from training.tier_configs import get_tier_config  # noqa: E402

    base_model = get_tier_config(args.tier)["base_model"]
    merge_result = _run(
        [sys.executable, "training/merge_and_export.py", "--base-model", base_model,
         "--adapter", str(adapter_dir), "--output", str(merged_dir)],
        "4/5 Слияние с базовой моделью",
    )
    if merge_result.returncode != 0:
        asyncio.run(_update_run(run_id, status=TrainingRunStatus.FAILED, failure_reason="merge_and_export failed"))
        sys.exit(1)

    # 5. Самопроверка (persona/safety regression probes)
    eval_result = _run(
        [sys.executable, "training/eval_candidate.py", "--model-path", str(merged_dir),
         "--report", str(report_path)],
        "5/5 Самопроверка кандидата",
    )
    eval_summary = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else None
    final_status = TrainingRunStatus.EVAL_PASSED if eval_result.returncode == 0 else TrainingRunStatus.EVAL_NEEDS_REVIEW

    asyncio.run(
        _update_run(
            run_id,
            status=final_status,
            adapter_path=str(merged_dir),
            eval_summary=eval_summary,
        )
    )

    print(f"\n=== ГОТОВО: TrainingRun {run_id} -> {final_status.value} ===")
    if final_status == TrainingRunStatus.EVAL_NEEDS_REVIEW:
        print(
            "Самопроверка нашла регрессии — посмотри training/eval_report.json перед тем, как "
            "одобрять этот прогон в Developer Console."
        )
    print(
        "Дальше — вручную: разверни модель из "
        f"{merged_dir} на инференс-сервере (vLLM/Ollama), пропиши путь в "
        "SELF_HOSTED_MODEL_NAME и подтверди прогон в Developer Console "
        f"(POST /developer/training-runs/{run_id}/approve)."
    )


if __name__ == "__main__":
    main()
