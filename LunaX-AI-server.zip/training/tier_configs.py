"""
Конфиги обучения по тарифам: каждый тариф — свой чекпоинт, качество
растёт вместе с тарифом (больше база / выше LoRA rank). Владелец сам
выбирает базовые модели — ниже разумные дефолты, не финальное решение.
"""

TIER_TRAINING_CONFIGS = {
    "free": {"base_model": "Qwen/Qwen2.5-3B-Instruct", "lora_r": 8, "lora_alpha": 16},
    "pro": {"base_model": "Qwen/Qwen2.5-7B-Instruct", "lora_r": 16, "lora_alpha": 32},
    "pro_plus": {"base_model": "Qwen/Qwen2.5-7B-Instruct", "lora_r": 32, "lora_alpha": 64},
    "ultra": {"base_model": "Qwen/Qwen2.5-14B-Instruct", "lora_r": 32, "lora_alpha": 64},
    "ultra_plus": {"base_model": "Qwen/Qwen2.5-14B-Instruct", "lora_r": 64, "lora_alpha": 128},
    "developer": {"base_model": "Qwen/Qwen2.5-32B-Instruct", "lora_r": 64, "lora_alpha": 128},
}


def get_tier_config(tier: str) -> dict:
    if tier not in TIER_TRAINING_CONFIGS:
        raise ValueError(f"Неизвестный тариф: {tier}. Доступны: {list(TIER_TRAINING_CONFIGS)}")
    return TIER_TRAINING_CONFIGS[tier]
