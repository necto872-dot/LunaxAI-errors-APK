"""
Сбор реальных диалогов пользователей из БД LunaX AI (Conversation/Message)
в формат raw_conversations.json, который понимает prepare_dataset.py.

ГЛАВНОЕ ПРАВИЛО (не обсуждается флагами командной строки):
Экспортируются диалоги ТОЛЬКО тех пользователей, у которых
User.allow_training_data_use == True на момент запуска — то есть которые
сами включили это в настройках через PATCH /auth/me/training-consent
(миграция 0004_training_pipeline, по умолчанию False для всех). Молчание
пользователя — это отказ, а не согласие. Без этого условия скрипт вообще
ничего не экспортирует.

Дополнительно:
- Пропускаются диалоги, где ассистентская реплика пуста/является служебной
  заглушкой (например ошибка провайдера) — такое не должно попасть в
  обучающую выборку как "образцовый" ответ.
- Простая (НЕ надёжная) эвристическая маскировка PII: email-адреса и
  похожие на телефон последовательности цифр заменяются плейсхолдерами.
  Это подстраховка, а не замена ручной проверки — перед реальным обучением
  просмотри итоговый raw_conversations.json глазами, особенно если
  включишь --min-length ниже, чем есть смысл.

Запуск:
    python training/collect_from_db.py \\
        --output training/raw_conversations.json \\
        --max-conversations 500
"""
import argparse
import asyncio
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import select  # noqa: E402

from app.database import async_session_maker  # noqa: E402
from app.database.models import Conversation, Message, MessageRole, User  # noqa: E402

_EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
_PHONE_RE = re.compile(r"(?<!\d)(\+?\d[\d\-\s()]{7,}\d)(?!\d)")


def _scrub(text: str) -> str:
    text = _EMAIL_RE.sub("[email]", text)
    text = _PHONE_RE.sub("[phone]", text)
    return text


async def collect(max_conversations: int, min_reply_length: int) -> list[dict]:
    pairs: list[dict] = []
    async with async_session_maker() as db:
        result = await db.execute(
            select(Conversation)
            .join(User, User.id == Conversation.owner_id)
            .where(User.allow_training_data_use.is_(True))
            .order_by(Conversation.updated_at.desc())
            .limit(max_conversations)
        )
        conversations = result.scalars().all()

        for conv in conversations:
            msgs_result = await db.execute(
                select(Message).where(Message.conversation_id == conv.id).order_by(Message.created_at.asc())
            )
            messages = msgs_result.scalars().all()

            # Разбиваем тред на последовательные пары (user, assistant) —
            # многоходовый контекст prepare_dataset.py тут не строим
            # намеренно: контекст между сообщениями решает LUNOX_SYSTEM_PROMPT
            # + история диалога на уровне inference-запроса, а не датасет.
            pending_user: str | None = None
            for msg in messages:
                if msg.role == MessageRole.USER:
                    pending_user = msg.content
                elif msg.role == MessageRole.ASSISTANT and pending_user is not None:
                    reply = msg.content or ""
                    if len(reply.strip()) >= min_reply_length:
                        pairs.append(
                            {
                                "user": _scrub(pending_user),
                                "assistant": _scrub(reply),
                            }
                        )
                    pending_user = None

    return pairs


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("training/raw_conversations.json"))
    parser.add_argument(
        "--max-conversations",
        type=int,
        default=500,
        help="Верхняя граница на число ОБРАБАТЫВАЕМЫХ тредов за один запуск (не строк в датасете).",
    )
    parser.add_argument(
        "--min-reply-length",
        type=int,
        default=5,
        help="Минимальная длина ответа ассистента (символов), чтобы пара попала в выборку.",
    )
    args = parser.parse_args()

    pairs = asyncio.run(collect(args.max_conversations, args.min_reply_length))

    if not pairs:
        print(
            "Собрано 0 пар — либо ни один пользователь не включил "
            "allow_training_data_use, либо подходящих диалогов ещё нет.",
            file=sys.stderr,
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(pairs, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Собрано {len(pairs)} пар -> {args.output}")


if __name__ == "__main__":
    main()
