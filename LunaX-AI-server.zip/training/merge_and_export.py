"""
Слияние LoRA-адаптера с базовой моделью для деплоя через vLLM/Ollama.

vLLM умеет грузить LoRA-адаптеры отдельно (без слияния, через --lora-modules),
но самый простой и совместимый со всеми инференс-серверами вариант — смёржить
адаптер в базовую модель и получить один самостоятельный набор весов.

Запуск:
    python training/merge_and_export.py \\
        --base-model Qwen/Qwen2.5-7B-Instruct \\
        --adapter ./lunox-lora-adapter \\
        --output ./lunox-merged-model

После этого ./lunox-merged-model — обычная HuggingFace-модель, которую
можно:
- скормить vLLM: `vllm serve ./lunox-merged-model --served-model-name lunox-v1`
- или сконвертировать в GGUF и запустить через Ollama (см. training/README.md,
  раздел "Деплой через Ollama" — конвертация делается llama.cpp convert-скриптом,
  отдельным инструментом, не входящим в этот репозиторий).

ЧЕСТНОЕ ОГРАНИЧЕНИЕ: не запускался в этом проходе (нет GPU/пакетов в sandbox).
"""
import argparse

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer


def main() -> None:
    parser = argparse.ArgumentParser(description="Слияние LoRA-адаптера с базовой моделью")
    parser.add_argument("--base-model", required=True, help="HuggingFace repo id или локальный путь")
    parser.add_argument("--adapter", required=True, help="Путь к LoRA-адаптеру (выход train_lora.py)")
    parser.add_argument("--output", required=True, help="Куда сохранить смёрженную модель")
    args = parser.parse_args()

    print(f"Загружаю базовую модель: {args.base_model}")
    base_model = AutoModelForCausalLM.from_pretrained(
        args.base_model, torch_dtype=torch.bfloat16, device_map="auto"
    )
    tokenizer = AutoTokenizer.from_pretrained(args.base_model)

    print(f"Накладываю адаптер: {args.adapter}")
    model = PeftModel.from_pretrained(base_model, args.adapter)

    print("Сливаю веса...")
    merged = model.merge_and_unload()

    print(f"Сохраняю в {args.output}")
    merged.save_pretrained(args.output)
    tokenizer.save_pretrained(args.output)

    print("Готово. Теперь укажите этот путь как модель в vLLM/Ollama/TGI и пропишите его "
          "в SELF_HOSTED_MODEL_NAME (.env бэкенда LunaX AI).")


if __name__ == "__main__":
    main()
