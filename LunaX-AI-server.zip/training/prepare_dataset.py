"""
Подготовка датасета для LoRA/QLoRA дообучения Lunox AI.

ФОРМАТ ДАТАСЕТА (JSONL, одна запись — один диалог):

    {"messages": [
        {"role": "system", "content": "<системный промпт, обычно из app/core/ai/persona.py>"},
        {"role": "user", "content": "текст вопроса пользователя"},
        {"role": "assistant", "content": "желаемый ответ Lunox AI"}
    ]}

Это стандартный chat-формат, который понимает TRL SFTTrainer
(trl.trainer.sft_trainer) через apply_chat_template токенизатора модели.
Многоходовые диалоги — просто больше пар user/assistant подряд в одном
messages[].

ЗАЧЕМ ЭТОТ СКРИПТ: превращает "сырые" данные (например экспорт переписки
из вашей БД LunaX — таблица логов чата, если вы её ведёте отдельно от
audit_logs, либо вручную составленные примеры) в готовый JSONL. Он НЕ
подключён к вашей БД автоматически — источник данных (raw_conversations.json)
нужно подготовить/экспортировать самостоятельно, формат raw описан ниже.

ФОРМАТ raw_conversations.json (вход для этого скрипта):

    [
        {"user": "Привет, что ты умеешь?", "assistant": "Привет! Я Lunox AI..."},
        {"user": "Сгенерируй мне функцию на Python...", "assistant": "```python\\n..."}
    ]

Запуск:
    python training/prepare_dataset.py \\
        --input raw_conversations.json \\
        --output dataset.jsonl \\
        --inject-persona
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def load_persona_prompt() -> str:
    from app.core.ai.persona import LUNOX_SYSTEM_PROMPT

    return LUNOX_SYSTEM_PROMPT


def build_dataset(raw_path: Path, inject_persona: bool) -> list[dict]:
    raw = json.loads(raw_path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise TypeError("raw_conversations.json должен быть JSON-массивом объектов {user, assistant}")

    system_prompt = load_persona_prompt() if inject_persona else None
    records = []

    for i, item in enumerate(raw):
        if "user" not in item or "assistant" not in item:
            raise ValueError(f"Запись #{i} должна содержать поля 'user' и 'assistant': {item}")

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": item["user"]})
        messages.append({"role": "assistant", "content": item["assistant"]})

        records.append({"messages": messages})

    return records


def main() -> int:
    parser = argparse.ArgumentParser(description="Подготовка JSONL-датасета для дообучения Lunox AI")
    parser.add_argument("--input", required=True, type=Path, help="raw_conversations.json")
    parser.add_argument("--output", required=True, type=Path, help="dataset.jsonl (выход)")
    parser.add_argument(
        "--inject-persona",
        action="store_true",
        help="Добавить системный промпт из app/core/ai/persona.py в каждую запись "
        "(рекомендуется: так модель учится характеру Lunox AI прямо в весах, "
        "а не только через промпт во время инференса)",
    )
    args = parser.parse_args()

    if not args.input.exists():
        print(f"Файл не найден: {args.input}", file=sys.stderr)
        return 1

    records = build_dataset(args.input, args.inject_persona)

    with open(args.output, "w", encoding="utf-8") as f:
        f.writelines(json.dumps(record, ensure_ascii=False) + "\n" for record in records)

    print(f"Готово: {len(records)} записей -> {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
