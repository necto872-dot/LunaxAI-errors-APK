"""
LoRA/QLoRA дообучение открытой модели под Lunox AI.

Использует стандартный, реально рабочий стек: transformers + peft (LoRA) +
trl (SFTTrainer) + bitsandbytes (4-bit квантование для QLoRA — обучение
на одной потребительской GPU с 16-24GB VRAM, без квантования нужна
GPU заметно больше в зависимости от размера базовой модели).

ЗАПУСК (пример, база — открытая instruct-модель среднего размера):

    pip install -r training/requirements.txt
    python training/train_lora.py \\
        --base-model Qwen/Qwen2.5-7B-Instruct \\
        --dataset dataset.jsonl \\
        --output-dir ./lunox-lora-adapter \\
        --epochs 3

ВЫБОР БАЗОВОЙ МОДЕЛИ: по умолчанию скрипт берёт --tier=pro (Qwen2.5-7B-
Instruct, 16-24GB VRAM с QLoRA) — уже готовая раскладка по тарифам лежит
в training/tier_configs.py (free/pro/pro_plus/ultra/ultra_plus/developer,
разный размер модели и LoRA-ранг под каждый). Переопределить можно
--tier <название> или явным --base-model <repo-id>.

ПОСЛЕ ОБУЧЕНИЯ: адаптер (LoRA-веса) нужно смёржить с базовой моделью
(merge_and_upload.py) и задеплоить через vLLM/Ollama — см. training/README.md.

ЧЕСТНОЕ ОГРАНИЧЕНИЕ: этот скрипт не запускался в данном проходе (нет GPU
и пакетов torch/transformers/peft/trl в этой sandbox-среде) — синтаксис
проверен (`python -m py_compile`), но фактическое обучение не проверялось.
Гиперпараметры ниже — разумные дефолты для QLoRA, не результат тюнинга
под конкретный датасет — при необходимости подберите под свои данные.
"""
import argparse

from datasets import load_dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from trl import SFTConfig, SFTTrainer


def build_quantization_config(use_4bit: bool) -> BitsAndBytesConfig | None:
    if not use_4bit:
        return None
    return BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype="bfloat16",
        bnb_4bit_use_double_quant=True,
    )


def build_lora_config(target_modules: list[str], r: int = 16, lora_alpha: int = 32) -> LoraConfig:
    return LoraConfig(
        r=r,
        lora_alpha=lora_alpha,
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=target_modules,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="LoRA/QLoRA дообучение Lunox AI")
    parser.add_argument(
        "--base-model",
        required=False,
        help="HuggingFace repo id или локальный путь (переопределяет --tier)",
    )
    parser.add_argument(
        "--tier",
        required=False,
        default="pro",
        help=(
            "Тариф из training/tier_configs.py — берёт base_model/lora_r/alpha "
            "оттуда (по умолчанию 'pro' — Qwen2.5-7B-Instruct, разумный баланс)"
        ),
    )
    parser.add_argument("--dataset", required=True, help="Путь к dataset.jsonl (см. prepare_dataset.py)")
    parser.add_argument("--output-dir", default="./lunox-lora-adapter", help="Куда сохранить LoRA-адаптер")
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--gradient-accumulation-steps", type=int, default=8)
    parser.add_argument("--learning-rate", type=float, default=2e-4)
    parser.add_argument("--max-seq-length", type=int, default=2048)
    parser.add_argument(
        "--no-4bit",
        action="store_true",
        help="Отключить 4-bit квантование (полный LoRA вместо QLoRA — нужно больше VRAM)",
    )
    parser.add_argument(
        "--target-modules",
        nargs="+",
        default=["q_proj", "k_proj", "v_proj", "o_proj"],
        help="Какие слои дообучать через LoRA — дефолт подходит для большинства "
        "Llama/Qwen/Mistral-архитектур; сверьте с архитектурой вашей конкретной модели",
    )
    args = parser.parse_args()

    if args.tier:
        from tier_configs import get_tier_config
        cfg = get_tier_config(args.tier)
        args.base_model = args.base_model or cfg["base_model"]
        lora_r, lora_alpha = cfg["lora_r"], cfg["lora_alpha"]
    elif not args.base_model:
        parser.error("укажите --base-model или --tier")
    else:
        lora_r, lora_alpha = 16, 32

    print(f"Загружаю базовую модель: {args.base_model}")
    tokenizer = AutoTokenizer.from_pretrained(args.base_model)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    quant_config = build_quantization_config(use_4bit=not args.no_4bit)
    model = AutoModelForCausalLM.from_pretrained(
        args.base_model,
        quantization_config=quant_config,
        device_map="auto",
        torch_dtype="bfloat16",
    )

    if quant_config is not None:
        model = prepare_model_for_kbit_training(model)

    lora_config = build_lora_config(args.target_modules, r=lora_r, lora_alpha=lora_alpha)
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    print(f"Загружаю датасет: {args.dataset}")
    dataset = load_dataset("json", data_files=args.dataset, split="train")

    def format_example(example: dict) -> str:
        # apply_chat_template — стандартный способ превратить messages[] в
        # промпт-строку в формате, который ожидает конкретная базовая модель
        # (у каждой модели свой chat template, зашитый в tokenizer_config.json).
        return tokenizer.apply_chat_template(example["messages"], tokenize=False, add_generation_prompt=False)

    training_args = SFTConfig(
        output_dir=args.output_dir,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        learning_rate=args.learning_rate,
        logging_steps=10,
        save_strategy="epoch",
        bf16=True,
        max_seq_length=args.max_seq_length,
        packing=False,
        report_to="none",  # TODO/CONFIG: поменяйте на "wandb"/"tensorboard", если нужен мониторинг
    )

    trainer = SFTTrainer(
        model=model,
        args=training_args,
        train_dataset=dataset,
        formatting_func=format_example,
        tokenizer=tokenizer,
    )

    print("Начинаю обучение...")
    trainer.train()

    print(f"Сохраняю LoRA-адаптер в {args.output_dir}")
    trainer.save_model(args.output_dir)
    tokenizer.save_pretrained(args.output_dir)

    print("Готово. Следующий шаг — смёржить адаптер с базовой моделью, см. training/merge_and_export.py")


if __name__ == "__main__":
    main()
