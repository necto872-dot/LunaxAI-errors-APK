#!/usr/bin/env python3
"""
Реальное применение обновления LunaX AI — только локально на сервере
(ТЗ раздел 9: не публичный HTTP endpoint, тот же принцип, что и
scripts/manage_primary.py для Primary Developer).

Предполагает, что подтверждение уже было получено через
POST /api/v1/updates/check -> POST /api/v1/updates/apply (confirmation_token).
Этот скрипт делает фактический деплой:

    python scripts/apply_update.py

Выполняет по порядку, с подтверждением перед каждым необратимым шагом:
1. git pull (обновляет исходный код);
2. pip install -r requirements.txt (обновляет зависимости);
3. alembic upgrade head (применяет новые миграции, если есть);
4. напоминание перезапустить процесс (uvicorn/systemd/docker — вне
   ответственности этого скрипта, зависит от вашего деплоя).

ЧЕСТНОЕ ОГРАНИЧЕНИЕ: не запускался в этом проходе — нет git-репозитория/
сети в sandbox-среде. Логика вызовов subprocess проверена только на
уровне синтаксиса.
"""
import subprocess
import sys


def confirm(prompt: str) -> bool:
    answer = input(f"{prompt} [yes/N]: ").strip().lower()
    return answer == "yes"


def run(cmd: list[str]) -> bool:
    print(f"$ {' '.join(cmd)}")
    result = subprocess.run(cmd)
    return result.returncode == 0


def main() -> int:
    print("=== LunaX AI — применение обновления ===")
    print("Убедитесь, что вы уже получили confirmation_token через "
          "POST /api/v1/updates/check и подтвердили его через /apply.\n")

    if not confirm("Выполнить git pull?"):
        print("Отменено на шаге git pull.")
        return 1
    if not run(["git", "pull"]):
        print("git pull завершился с ошибкой — остановлено.")
        return 1

    if not confirm("Обновить зависимости (pip install -r requirements.txt)?"):
        print("Отменено на шаге pip install.")
        return 1
    if not run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt", "--break-system-packages"]):
        print("pip install завершился с ошибкой — остановлено.")
        return 1

    if not confirm("Применить миграции БД (alembic upgrade head)?"):
        print("Отменено на шаге миграций. ВНИМАНИЕ: код обновлён, но схема БД — нет, "
              "запускать сервис в этом состоянии небезопасно.")
        return 1
    if not run(["alembic", "upgrade", "head"]):
        print("alembic upgrade head завершился с ошибкой — остановлено.")
        return 1

    print("\nГотово. Код и миграции обновлены. Перезапустите процесс backend'а "
          "(uvicorn/systemd/docker restart — в зависимости от вашего деплоя).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
