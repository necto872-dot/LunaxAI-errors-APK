#!/usr/bin/env python3
"""
Bootstrap Primary Developer (LunaX_AI_TZ.txt раздел 8, 17).

Запуск:
    python scripts/bootstrap_primary.py

Создаёт единственного PRIMARY_DEVELOPER в системе. Защищён от повторного
запуска: если Primary уже существует, скрипт завершается без изменений.

Пароль никогда не выводится в терминал и не сохраняется в открытом виде.
"""
import asyncio
import getpass
import sys
from datetime import date, datetime, UTC
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import select  # noqa: E402

from app.config.settings import get_settings  # noqa: E402
from app.database import Base, async_session_maker, engine  # noqa: E402
from app.config.settings import DEVELOPER_TOKEN_LIMIT  # noqa: E402
from app.database.models import User, UserRole  # noqa: E402
from app.modules.auth.services import hash_password  # noqa: E402

MIN_PASSWORD_LENGTH = 8


async def primary_exists(db) -> bool:
    result = await db.execute(select(User).where(User.role == UserRole.PRIMARY_DEVELOPER))
    return result.scalar_one_or_none() is not None


async def main() -> int:
    settings = get_settings()

    async with engine.begin() as conn:
        # Только для окружений, где ещё не применялись Alembic-миграции
        # (например первый локальный запуск). В production используйте
        # `alembic upgrade head` и не полагайтесь на create_all здесь.
        await conn.run_sync(Base.metadata.create_all)

    async with async_session_maker() as db:
        if await primary_exists(db):
            print("Primary Developer уже существует. Bootstrap не выполнен повторно.")
            print("Для замены Primary используйте scripts/manage_primary.py")
            return 1

        default_email = settings.primary_developer_email
        email_prompt = f"Email [{default_email}]: " if default_email else "Email: "
        email = input(email_prompt).strip() or default_email
        if not email:
            print("Email обязателен.")
            return 1

        username = input("Username: ").strip()
        if not username:
            print("Username обязателен.")
            return 1

        password = getpass.getpass("Пароль LunaX (не будет отображён): ")
        password_confirm = getpass.getpass("Подтвердите пароль: ")

        if password != password_confirm:
            print("Пароли не совпадают.")
            return 1
        if len(password) < MIN_PASSWORD_LENGTH:
            print(f"Пароль должен содержать не менее {MIN_PASSWORD_LENGTH} символов.")
            return 1

        user = User(
            email=email,
            username=username,
            hashed_password=hash_password(password),
            role=UserRole.PRIMARY_DEVELOPER,
            is_active=True,
            email_verified=True,
            unlimited_usage=True,
            token_balance=DEVELOPER_TOKEN_LIMIT,
            token_limit=DEVELOPER_TOKEN_LIMIT,
            # Primary Developer создаётся через доверенный CLI-скрипт, не
            # публичную регистрацию — возрастная проверка/согласие с
            # пользовательским соглашением здесь неприменимы; поля
            # заполняются формально, чтобы не нарушать NOT NULL в модели.
            date_of_birth=date.today(),
            terms_accepted_at=datetime.now(UTC),
            terms_version=get_settings().terms_version,
        )
        db.add(user)
        await db.commit()

        print("Primary Developer создан успешно.")
        print(f"  id:       {user.id}")
        print(f"  email:    {user.email}")
        print(f"  username: {user.username}")
        print(f"  role:     {user.role.value}")
        return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
