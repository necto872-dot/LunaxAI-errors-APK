#!/usr/bin/env python3
"""
Аварийное серверное управление Primary Developer (LunaX_AI_TZ.txt раздел 7, 18).

Требует локальный доступ к серверу/базе данных. НЕ является публичным
HTTP-эндпоинтом — сознательно реализовано только как CLI.

Команды:
    python scripts/manage_primary.py show
    python scripts/manage_primary.py set --email new@example.com --username newowner --password NEW_PASSWORD
    python scripts/manage_primary.py rotate --password NEW_PASSWORD

Каждая операция запрашивает явное подтверждение (кроме show) и пишет
запись в audit_logs. Пароль передаётся только через локальный аргумент
или интерактивный ввод — никогда не логируется.
"""
import argparse
import asyncio
import getpass
import sys
from datetime import date, datetime, UTC
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import select  # noqa: E402

from app.core.audit import record_audit_event  # noqa: E402
from app.database import async_session_maker  # noqa: E402
from app.config.settings import DEVELOPER_TOKEN_LIMIT, get_settings  # noqa: E402
from app.database.models import User, UserRole  # noqa: E402
from app.modules.auth.services import get_user_by_email, hash_password  # noqa: E402

MIN_PASSWORD_LENGTH = 8


async def get_primary(db) -> User | None:
    result = await db.execute(select(User).where(User.role == UserRole.PRIMARY_DEVELOPER))
    return result.scalar_one_or_none()


def confirm(prompt: str) -> bool:
    answer = input(f"{prompt} [yes/N]: ").strip().lower()
    return answer == "yes"


async def cmd_show(_args) -> int:
    async with async_session_maker() as db:
        primary = await get_primary(db)
        if primary is None:
            print("Primary Developer не найден. Запустите scripts/bootstrap_primary.py")
            return 1
        print(f"id:            {primary.id}")
        print(f"email:         {primary.email}")
        print(f"username:      {primary.username}")
        print(f"is_active:     {primary.is_active}")
        print(f"email_verified:{primary.email_verified}")
        return 0


async def cmd_set(args) -> int:
    if not args.email or not args.username:
        print("Требуются --email и --username")
        return 1

    password = args.password or getpass.getpass("Новый пароль LunaX: ")
    if len(password) < MIN_PASSWORD_LENGTH:
        print(f"Пароль должен содержать не менее {MIN_PASSWORD_LENGTH} символов.")
        return 1

    if not confirm(
        f"Заменить Primary Developer на email={args.email}, username={args.username}? "
        "Это необратимая серверная операция."
    ):
        print("Отменено.")
        return 1

    async with async_session_maker() as db:
        old_primary = await get_primary(db)
        conflicting = await get_user_by_email(db, args.email)
        if conflicting and (old_primary is None or conflicting.id != old_primary.id):
            print(f"Email {args.email} уже используется другим аккаунтом.")
            return 1

        if old_primary is None:
            new_primary = User(
                email=args.email,
                username=args.username,
                hashed_password=hash_password(password),
                role=UserRole.PRIMARY_DEVELOPER,
                is_active=True,
                email_verified=True,
                unlimited_usage=True,
                token_balance=DEVELOPER_TOKEN_LIMIT,
                token_limit=DEVELOPER_TOKEN_LIMIT,
                # CLI-скрипт аварийной замены Primary — не публичная
                # регистрация; поля заполняются формально (см. тот же
                # комментарий в scripts/bootstrap_primary.py).
                date_of_birth=date.today(),
                terms_accepted_at=datetime.now(UTC),
                terms_version=get_settings().terms_version,
            )
            db.add(new_primary)
            await db.commit()
            await db.refresh(new_primary)
            target_id = new_primary.id
        else:
            old_primary.role = UserRole.DEVELOPER  # понижение старого владельца, а не удаление
            db.add(old_primary)

            new_primary = User(
                email=args.email,
                username=args.username,
                hashed_password=hash_password(password),
                role=UserRole.PRIMARY_DEVELOPER,
                is_active=True,
                email_verified=True,
                unlimited_usage=True,
                token_balance=DEVELOPER_TOKEN_LIMIT,
                token_limit=DEVELOPER_TOKEN_LIMIT,
                # CLI-скрипт аварийной замены Primary — не публичная
                # регистрация; поля заполняются формально (см. тот же
                # комментарий в scripts/bootstrap_primary.py).
                date_of_birth=date.today(),
                terms_accepted_at=datetime.now(UTC),
                terms_version=get_settings().terms_version,
            )
            db.add(new_primary)
            await db.commit()
            await db.refresh(new_primary)
            target_id = new_primary.id

        await record_audit_event(
            db, "primary_developer_replaced_via_cli", actor_id=None, target_id=target_id,
            new_email=args.email,
        )
        print(f"Primary Developer установлен: {args.email} / {args.username}")
        return 0


async def cmd_rotate(args) -> int:
    password = args.password or getpass.getpass("Новый пароль LunaX: ")
    if len(password) < MIN_PASSWORD_LENGTH:
        print(f"Пароль должен содержать не менее {MIN_PASSWORD_LENGTH} символов.")
        return 1

    async with async_session_maker() as db:
        primary = await get_primary(db)
        if primary is None:
            print("Primary Developer не найден.")
            return 1

        if not confirm(f"Сменить пароль Primary Developer ({primary.email})?"):
            print("Отменено.")
            return 1

        primary.hashed_password = hash_password(password)
        await db.commit()
        await record_audit_event(db, "primary_developer_password_rotated_via_cli", target_id=primary.id)
        print("Пароль Primary Developer обновлён.")
        return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Аварийное управление Primary Developer")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("show", help="Показать текущего Primary Developer")

    set_parser = sub.add_parser("set", help="Установить/заменить Primary Developer")
    set_parser.add_argument("--email", required=True)
    set_parser.add_argument("--username", required=True)
    set_parser.add_argument("--password", required=False)

    rotate_parser = sub.add_parser("rotate", help="Сменить пароль текущего Primary Developer")
    rotate_parser.add_argument("--password", required=False)

    return parser


async def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "show":
        return await cmd_show(args)
    if args.command == "set":
        return await cmd_set(args)
    if args.command == "rotate":
        return await cmd_rotate(args)

    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
