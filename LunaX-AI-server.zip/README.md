# LunaX AI — backend (v0.1.0-demo)

Этот README отражает **фактическое** состояние кода после аудита по
`LunaX_AI_TZ.txt`, а не заявленное. Раздел "Аудит" ниже — главный.
Важно: большая часть аудит-таблицы ниже написана до этого прохода и
для APK-сборки/генерации проектов уже устарела — актуальное описание
этих двух модулей и очереди см. в разделе "Фоновые задачи" сразу
после "Запуск".

### Изменения в этом проходе (после предыдущего сообщения о нерешённых пунктах)

- **Регистрация теперь требует `date_of_birth` и `accept_terms`.**
  Минимальный возраст — 16 лет (`settings.min_registration_age_years`),
  проверяется дважды: в pydantic-схеме `UserRegister` (на входе HTTP-запроса)
  и повторно в `register_user()` (защита от обхода при прямом вызове
  функции мимо схемы). Есть Alembic-миграция `0003_user_age_terms` —
  для существующих строк (если база не пустая) ставит технический
  плейсхолдер даты рождения, это НЕ подтверждение их возраста, только
  чтобы не сломать NOT NULL. Второй слой — расширенный safety-фильтр
  (`app/core/safety.py`, 33 категории regex) + опциональная AI-модерация
  (`app/core/ai_moderation.py`, флаг `AI_MODERATION_ENABLED`) поверх него.

- **APK-сборка и генерация проектов теперь идут через приоритетную
  очередь (RQ)**, а не блокируют HTTP-запрос — см. "Фоновые задачи"
  ниже. Раньше `/apk/build` и `/projects/generate` выполняли всю
  тяжёлую работу (Gradle/AI-цикл) синхронно внутри запроса; сама
  очередь при этом существовала (`app/core/queue.py`), но ни одна
  подсистема её не использовала. Добавлены `enqueue_apk_build()` и
  `enqueue_project_generation()` + новая колонка `queue_job_id`
  (миграция `0002_queue_job_id`).
- Kaspi/Freedom Pay намеренно НЕ трогались (по прямому указанию
  владельца) — по-прежнему `NotImplementedError`/501, см. п.23 ниже.
- `pytest -v` / `alembic upgrade head` по-прежнему **не выполнялись**
  в этой сборке — в текущей sandbox-среде нет сети, поэтому
  `pip install -r requirements.txt` не проходит (см. "Что реально
  проверено" ниже, статус не изменился: NOT VERIFIED, не PASS).
  Выполните их локально после `pip install -r requirements.txt`.
- GPU-обучение модели, self-hosted AI/voice/image/video сервер,
  SearXNG-инстанс, реальная сборка APK через Android SDK — не
  затрагивались, требуют инфраструктуры, которой нет в этой среде.

## Установка

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # заполнить реальными значениями, .env в .gitignore
```

## База данных / миграции

```bash
alembic upgrade head
```

Для разработки на SQLite можно также положиться на `create_all` при
`ENV=development` (см. `app/main.py`), но в production используйте
**только** Alembic.

## Bootstrap Primary Developer

```bash
python scripts/bootstrap_primary.py
```

Создаёт единственного `PRIMARY_DEVELOPER`. Повторный запуск при
существующем Primary ничего не делает (проверено кодом, см. скрипт).

## Аварийная замена Primary (только локально, не через HTTP)

```bash
python scripts/manage_primary.py show
python scripts/manage_primary.py set --email new@example.com --username newowner
python scripts/manage_primary.py rotate --password NEW_PASSWORD
```

## Запуск

```bash
uvicorn app.main:app --reload
```

Docs: `/docs`, `/openapi.json`.

## Фоновые задачи (очередь RQ) — APK-сборка и генерация проектов

Требуется Redis (`redis_url` в `.env`, по умолчанию `redis://localhost:6379/0`).
`POST /apk/build` и `POST /projects/generate` теперь только ставят
задачу в приоритетную очередь пользователя (ТЗ п.9: Developer > Ultra
Plus > Ultra > Pro Plus > Pro > Free) и сразу возвращают её со статусом
`queued`/`generating` (HTTP 202) — саму задачу выполняет отдельный
процесс-воркер:

```bash
rq worker developer ultra_plus ultra pro_plus pro free
```

Воркер полностью опустошает более приоритетную очередь, прежде чем
взять задачу из следующей — реальный server-side приоритет, не
визуальный. Прогресс отслеживается опросом:
`GET /apk/build/{job_id}` (поля `status`: queued/running/succeeded/failed)
и `GET /projects/{project_id}` (поля `status`: generating/ready/failed).

Без запущенного воркера задачи будут копиться в статусе `queued` и
никогда не продвинутся — это ожидаемо, не баг: сама постановка в
очередь не требует воркера, только его выполнение.

## Тесты

```bash
pytest -v
```

Тесты используют mock SMTP (не отправляют реальные письма) и in-memory
SQLite — см. `tests/conftest.py`.

## Роли

`user`, `premium`, `developer`, `primary_developer`, `admin`.
Primary Developer защищён от изменения/удаления через обычный API —
любая попытка (в т.ч. от самого Primary) возвращает
`403 Cannot modify primary developer`. Замена возможна только через
`scripts/manage_primary.py`.

## Токен-экономика — окончательная схема (обновлено, согласовано в чате)

**Это ФИНАЛЬНАЯ версия схемы, заменившая предыдущий cooldown-per-spend
вариант.** Если где-то в старых записках/памяти встретится "cooldown на
каждое списание" или "сброс только если ≤100k при полуночи" — это
устаревшая версия, актуальна только схема ниже.

| Тариф | Токены | Цена | Таймер критического восстановления |
|---|---|---|---|
| FREE | 5 000 000 | 0 ₸ (не покупается, выдаётся сразу и навсегда) | 4 часа |
| PRO | 10 000 000 | 10 000 ₸ | 3 часа |
| PRO_PLUS | 15 000 000 | 15 000 ₸ | 3 часа |
| ULTRA | 20 000 000 | 20 000 ₸ | 2 часа |
| ULTRA_PLUS | 25 000 000 | 25 000 ₸ | 2 часа |
| DEVELOPER / PRIMARY_DEVELOPER | 50 000 000 000 | не тариф | не применяется (роль unlimited) |

Правило цены: цена (₸) = токены (млн) × 1000, кроме FREE (сознательное исключение).

**Отдельных лимитов на изображения/видео/демонстрацию экрана/сайт
больше нет.** Всё расходуется из единого `token_balance` через
`app.core.quota.spend_tokens()`.

**Механизм восстановления — два независимых пути:**

1. **Обычный остаток** (достаточно для нормальной работы) — пользователь
   просто продолжает пользоваться. Полный лимит возвращается
   **безусловно в 00:00 каждый календарный день**, независимо от того,
   сколько токенов осталось (даже если осталось 2.5М из 5М — всё равно
   будет полный сброс в полночь).
2. **Критический остаток** (недостаточно для одного полноценного
   действия) — запускается индивидуальный таймер **с момента именно
   этого критического списания** (а не с момента последнего обычного
   запроса): 4ч/3ч/3ч/2ч/2ч по тарифу. По истечении — полный сброс,
   раньше полуночи, если критический момент наступил не в конце дня.

**Допущение, которое стоит явно проговорить (не придумано мной — просто
неизбежный технический выбор):** в постановке не задано точное число
токенов "недостаточно для одного полноценного действия" — стоимость
одного AI-запроса в токенах ещё не определена (AI-цепочка не
реализована). Использовано `CRITICAL_BALANCE_THRESHOLD_TOKENS = 100_000`
как дефолт. Замените в `app/config/settings.py`, когда появится реальная
стоимость действия.

**Предупреждение о низком балансе**: при остатке ≤ 5% от лимита тарифа
API отдаёт `low_balance_warning` — см. `GET /api/v1/tokens/status`.

Реализация: `app/core/quota.py` (движок), `app/modules/tokens/routers.py`
(`GET /tokens/status`, `POST /tokens/spend`), `tests/test_tokens.py`.
Developer/Primary Developer трактуются как безусловно unlimited (баланс
не списывается вообще), несмотря на формальный пул 50 млрд — сознательный
выбор в духе ТЗ («unlimited usage» ≠ физический бесконечный ресурс, но и
не серверные права). `POST /tokens/spend` — рабочий механизм, но пока
никуда продуктово не подключён: реальной AI-цепочки, которая тратила бы
токены автоматически при генерации текста/изображений/видео/файлов/
проектов, в этом проходе нет — это следующий шаг (`app.core.quota.spend_tokens`
готов к вызову оттуда).

**Ограничение реализации (честно):** в проекте нет фонового
cron/scheduler. И суточный сброс, и критическое восстановление
считаются **лениво** — при первом обращении пользователя после
наступления момента, а не строго по системным часам (например, если
никто не делает запрос в 00:00:01, сброс произойдёт при следующем
запросе, а не мгновенно). Для точного тайминга нужен реальный
планировщик (RQ/Celery beat) — не сделано в этом проходе.

`pytest -v` для `tests/test_tokens.py` — **NOT VERIFIED** в этой
sandbox-среде (см. общий раздел аудита выше).

## Gmail SMTP

`.env` → `SMTP_HOST=smtp.gmail.com`, `SMTP_PORT=587`, `SMTP_USE_TLS=true`,
`SMTP_USE_SSL=false`, `SMTP_USERNAME`/`SMTP_FROM_EMAIL` = ваш адрес,
`SMTP_PASSWORD` = **App Password** (не основной пароль Google). Никогда
не коммитьте `.env` или App Password.

---

## АУДИТ: сопоставление с LunaX_AI_TZ.txt

### Чек-лист из последнего сообщения владельца (19 пунктов) — статус по каждому

Ничего не додумываю сверх того, что реально в репозитории.

| # | Пункт | Статус |
|---|---|---|
| 1 | Лимиты токенов 5/10/15/20/25М + 50 млрд Developer, окончательная схема восстановления | **IMPLEMENTED** — `app/core/quota.py`, см. раздел "Токен-экономика" выше |
| 2 | Backend: register/verify/login/JWT/refresh/reset/change-email/роли/Developer/Primary/защита/Console/guest/rate limiting/audit/ownership | **PARTIAL** — всё **IMPLEMENTED**, кроме: **ownership проектов — MISSING** (модуль projects не существует; ownership файлов теперь IMPLEMENTED, см. п.9). Rate limiting и расширенный audit log — **IMPLEMENTED** (см. ниже) |
| 3 | Серверная логика USER→SUBSCRIPTION→TOKEN BALANCE→REQUEST→CONSUMPTION→CHECK→RESET, нельзя обойти/подделать | **PARTIAL** — движок квоты (`spend_tokens`/`sync_quota_state`) реализован и не доверяет клиенту; **но не подключён ни к одному реальному AI/media эндпоинту** (они заглушки), поэтому "нельзя обойти лимит через API" не проверено на реальном сценарии. Смена тарифа вручную (через БД/скрипт) меняет лимит корректно; **эндпоинта для "нельзя переключить себе тариф" (реальный подтверждённый платёж) нет** — платежи не реализованы (см. п.5) |
| 4 | Индивидуальная схема восстановления (00:00 безусловно / критический таймер) | **IMPLEMENTED** — код + тесты в `tests/test_tokens.py` (не выполнялись, см. NOT VERIFIED ниже) |
| 5 | Платежи: checkout/оплата/отмена/возврат/webhook/подпись/смена тарифа/синхронизация с балансом | **MISSING** — `app/modules/payments/routers.py` остаётся заглушкой `not_implemented` под старое ТЗ, Stripe не подключён, подписи webhook не проверяются |
| 6 | AI Core цепочка Auth→Subscription→Permissions→Quota→AI service→Provider→Response→Accounting | **MISSING** — самого AI-сервиса/провайдера нет, `search`/`media` — заглушки. Квота (шаг Quota→Accounting) готова и может быть подключена, когда появится сама AI-цепочка |
| 7 | Генерация проектов: Prompt→Spec→Architecture→FileTree→Code→Validation→Tests→Build→Artifact | **УСТАРЕЛО, см. "Фоновые задачи" выше** — реализовано в позднейшем проходе: `app/core/projects/generator.py`, `/projects/generate` ставит цикл в приоритетную очередь (RQ), не блокирует запрос |
| 8 | Автоисправление кода (generate→test→error→patch→test, с лимитом попыток) | **УСТАРЕЛО** — реализовано, см. `_run_generation_job()` в `app/core/projects/generator.py` (лимит `project_gen_max_fix_attempts`) |
| 9 | Файлы: upload/MIME/размер/ownership/приватность/удаление/доступ/без path traversal | **IMPLEMENTED** — `app/modules/files/` (модель `UploadedFile`, реальный upload/list/download/delete, случайное имя на диске, allowlist расширений, лимит размера, доступ только владельцу — чужой file_id даёт 404, не 403, чтобы не подтверждать факт существования). **Ограничение (честно):** нет magic-byte валидации содержимого (нужна `python-magic`, не подключена), проверяется только расширение + заявленный Content-Type |
| 10 | Изображения/видео без отдельных лимитов, через общий баланс | **IMPLEMENTED (частично)** — отдельные лимиты (`VIDEO_HOUR_LIMITS` и т.п.) удалены из кода; но сама генерация media — заглушка, реального списания токенов при генерации нет (некуда списывать, пока нет самой функции) |
| 11 | Marketplace/Addons: создание/редактирование/публикация/версии/поиск/установка/permissions/безопасность | **MISSING** — подтверждено ранее в чате, не реализовано |
| 12 | Project Versioning (id/owner/version/snapshot/история/build status) | **УСТАРЕЛО** — реализовано: `ProjectVersion`/`BuildJob` модели, `GET /projects/{id}/versions`, `GET /projects/{id}/versions/{vid}/download` |
| 13 | APK pipeline | **УСТАРЕЛО, см. "Фоновые задачи" выше** — интерфейс+очередь реализованы (`app/core/build/apk.py`, `/apk/build` через RQ); честное ограничение не изменилось: реальный Gradle-запуск требует Android SDK на сервере (`apk_build_enabled=False` по умолчанию) |
| 14 | Primary Developer: necto872@gmail.com/Gaiji/bootstrap/защита/невозможность удаления и смены роли/управление Developer/revoke/CLI | **IMPLEMENTED** — код есть (`scripts/bootstrap_primary.py`, `scripts/manage_primary.py`, защита 403 в `developer_panel`); **но bootstrap НЕ запускался** — Primary Developer физически не создан ни в одной базе. Email по умолчанию берётся из `PRIMARY_DEVELOPER_EMAIL` в `.env`, не хардкожен |
| 15 | Developer: 50 млрд токенов ≠ доступ к серверу | **IMPLEMENTED** — `DEVELOPER_TOKEN_LIMIT=50_000_000_000` в коде; отсутствие серверных прав обеспечивается тем, что таких прав в API вообще не существует (нет endpoint'ов для .env/SMTP/DB credentials/shell) |
| 16 | Реальный Gmail SMTP (register→письмо→verify→login; forgot→письмо→reset→login) | **NOT VERIFIED** — нет сетевого доступа из sandbox, не выполнялось ни разу |
| 17 | Alembic: upgrade/downgrade/upgrade/heads на чистой БД | **NOT VERIFIED** — миграция `0001_initial.py` обновлена под новые поля (`last_daily_reset_date`, `critical_recovery_started_at`, `token_spends` удалена), но ни разу не выполнялась (нет alembic в sandbox) |
| 18 | Тесты (полный список из сообщения) | **PARTIAL** — auth/developer/guest/tokens тесты написаны (`tests/`), покрывают почти всё из списка кроме "платежи" и "подписки" (их нет в коде, тестировать нечего). **`pytest -v` ни разу не выполнялся** в этой sandbox-среде |
| 19 | Удалить старую логику (лимиты фото/видео/демо экрана/сайт/старые числа восстановления) | **IMPLEMENTED** — `VIDEO_HOUR_LIMITS`, `TOKEN_COOLDOWN_MINUTES` (пер-транзакционный cooldown), `MIDNIGHT_RESET_THRESHOLD`-условность, модель `TokenSpend` — удалены из кода полностью |
| 20 | Rate limiting на login/register/forgot-password/verify-email/reset-password, значения конфигурируемы | **IMPLEMENTED** — `app/core/rate_limit.py`, in-memory sliding-window по IP, подключён ко всем 5 auth-эндпоинтам. Числа (`settings.rate_limit_*`) — технические дефолты-заглушки, НЕ согласованное бизнес-решение (явно указано в коде/README). **Ограничение (честно):** in-memory — работает только для одного uvicorn worker'а, для нескольких воркеров/реплик нужен Redis (поле `redis_url` в конфиге есть, интеграция не подключена) |
| 21 | Audit log: login/failed login/password reset/email change/developer/primary/... | **IMPLEMENTED** — login/failed login/user_registered/email_verified/password_reset_requested+completed/email_change_requested+confirmed/developer created-updated-revoked/primary CLI-операции/**payment_succeeded** — пишутся в таблицу `audit_logs`. Project creation/addon publication — MISSING, этих модулей ещё нет |
| 22 | Токенные коэффициенты C1-C5 (текст/изображение/видео/код/файл), утверждённые в чате | **IMPLEMENTED** — `app/config/settings.py` (`TOKEN_COST_*`), `app/core/token_cost.py` (расчёт + `reserve_and_spend`, списание ДО старта операции, округление вверх). Подключено к реальной продуктовой операции — **upload файлов** (C5, с местом под множитель архивов). Image/video/code-коэффициенты определены и протестированы как функции, но **не подключены к реальным генераторам** — этих генераторов ещё не существует (см. п.6) |
| 23 | PaymentProvider abstraction (не привязываться к одному эквайрингу), Kaspi + Freedom Pay | **IMPLEMENTED (архитектурно)** — `app/core/payments/base.py` (интерфейс), `kaspi_provider.py`/`freedompay_provider.py` (заглушки с каркасом HMAC-подписи), `registry.py` (выбор по `PAYMENT_PROVIDER`). Полный флоу `checkout → webhook → идемпотентность (external_payment_id) → активация тарифа → token_balance` реализован и покрыт тестами через мок provider. **Честно:** реальные HTTP-вызовы к Kaspi/Freedom Pay API и точный формат подписи/payload НЕ реализованы и не сверены с официальной документацией (нет сети в этой среде) — `create_checkout`/`verify_and_parse_webhook` намеренно бросают `NotImplementedError` (501), а не подделывают ответ |
| 24 | AI Router (Lunox AI как единственный видимый слой, внутренняя маршрутизация скрыта) | **IMPLEMENTED (архитектурно)** — `app/core/ai/provider.py` (интерфейс `AIProvider`: generate/stream/analyze_image/analyze_file), `providers.py` (OpenAI/Anthropic/DeepSeek/Mistral — классы есть, реальных HTTP-вызовов нет), `lunox_router.py` (единая точка входа, provider_used никогда не уходит пользователю). `/api/v1/search/query` подключён к токен-квоте (C1, списание + возврат при неудаче). **Честно:** `settings.lunox_ai_provider` пуст по умолчанию (provider не утверждён владельцем) — эндпоинт отвечает 503, реальной генерации текста нет ни от одного provider |

### Финальный аудит-скрипт из сообщения — реально выполнено

| CHECK | RESULT |
|---|---|
| `python -m compileall app scripts alembic tests` | **PASS** (реально выполнено сейчас, без ошибок) |
| `pytest -v` | **NOT VERIFIED** — нет сети/пакетов в sandbox |
| `alembic upgrade head` / `downgrade -1` / `upgrade head` / `heads` | **NOT VERIFIED** — та же причина |
| Реальный Gmail SMTP e2e (register/verify, forgot/reset) | **NOT VERIFIED** — нет сети |

### Общий блок (старое ТЗ, не менялся с прошлой версии)

Аудит выполнен на присланном архиве `LunaX_AI.zip`. **Исходный код в
архиве соответствовал другому, более раннему ТЗ** (роли user/premium/
developer/admin без Primary Developer, без email-верификации, без
bootstrap-скриптов, без Alembic, без тестов — README архива описывал
другой продукт: AI-чат с Mistral/ChatGPT-цепочкой, биометрией,
маркетплейсом в тенге). Заявления вида «модуль Аккаунты полностью
реализован» в исходном README **не подтверждались кодом** относительно
текущего мастер-ТЗ (PRIMARY_DEVELOPER, email verification, bootstrap,
Gmail SMTP end-to-end) — именно такие случаи ТЗ явно требует не
принимать на веру (раздел 0, 63, 78).

| Требование ТЗ | Было в присланном архиве | Стало в этой версии |
|---|---|---|
| Роль PRIMARY_DEVELOPER | MISSING | IMPLEMENTED |
| Защита Primary от 403 на обычном API | MISSING | IMPLEMENTED (код + тест) |
| Bootstrap Primary (`scripts/bootstrap_primary.py`) | MISSING | IMPLEMENTED |
| Аварийный CLI (`scripts/manage_primary.py`) | MISSING | IMPLEMENTED |
| Управление вторичными Developer (CRUD) | MISSING | IMPLEMENTED (код + тест) |
| Лимит числа Developer не ограничен искусственно | MISSING (модели не было) | IMPLEMENTED (нет лимита в коде) |
| Email verification (register → token → verify) | MISSING | IMPLEMENTED (код + тест) |
| Login блокирует неподтверждённый email (403) | MISSING | IMPLEMENTED (код + тест) |
| Forgot/reset password, одноразовый токен | MISSING | IMPLEMENTED (код + тест) |
| Change/confirm email, проверка пароля | MISSING | IMPLEMENTED (код + тест) |
| SMTP-сервис STARTTLS/SSL, Gmail | MISSING | IMPLEMENTED **(код есть, реальный Gmail НЕ отправлен — см. ниже)** |
| Alembic миграции | MISSING (папки не было) | PARTIAL — миграция написана вручную, **не выполнялась** (нет alembic offline) |
| Тесты (auth/developer/guest) | MISSING (папки tests не было) | PARTIAL — написаны, **не выполнялись** (см. ниже) |
| Guest → 401 на защищённых endpoint | Было частично (get_current_user) | IMPLEMENTED, добавлен тест |
| Audit log критических операций | MISSING | IMPLEMENTED (таблица + запись при create/update/revoke developer, замене Primary) |
| .env.example / .gitignore корректны | Частично (.gitignore был пустой файл) | IMPLEMENTED |
| Marketplace / Payments / Files / Media / Voice / Updates / Search / Biometry | Заглушки (`not_implemented`) под другое ТЗ | Оставлены как заглушки, совместимы с новой моделью User; **не переписывались под текущее ТЗ** (Marketplace-аддоны, Stripe, APK-сборка, mobile client, voice STT/TTS реального провайдера). **Marketplace подтверждённо НЕ реализован** — ждёт отдельного ТЗ. |
| Токен-квота по тарифам (FREE/PRO/PRO_PLUS/ULTRA/ULTRA_PLUS/Developer) | MISSING | **IMPLEMENTED** (`app/core/quota.py`, `app/modules/tokens/`) — см. раздел ниже |
| Mobile client, APK generation, project generation/versioning | — | **УСТАРЕЛО** — APK generation и project generation/versioning реализованы позднее (см. "Фоновые задачи" выше); mobile client (PWA) — см. `client/` |

### Что реально проверено в этом окружении, а что нет

| CHECK | RESULT |
|---|---|
| `python -m compileall app scripts alembic tests` | **PASS** (реально выполнено, без ошибок синтаксиса) |
| Статическая сверка `settings.X` со списком полей `Settings` | **PASS** (реально выполнено, расхождений не найдено) |
| `pytest -v` | **NOT VERIFIED** — в этой sandbox-среде нет сети и не установлены fastapi/sqlalchemy/pytest и т.д.; тесты написаны (`tests/`), но не запускались. Выполните `pip install -r requirements.txt && pytest -v` самостоятельно. |
| `alembic upgrade head` / `downgrade -1` / `upgrade head` / `heads` | **NOT VERIFIED** — тот же ограничение окружения. Миграция `0001_initial` написана вручную по актуальным моделям, но не исполнялась ни против SQLite, ни против PostgreSQL. |
| Real Gmail SMTP (register → письмо → verify → login; forgot → письмо → reset → login) | **NOT VERIFIED** — нет сетевого доступа из этого окружения. Код STARTTLS/SSL реализован в `app/core/email.py` по спецификации, но фактическая отправка через `smtp.gmail.com` с App Password не проверялась. Проверьте вручную по инструкции в README выше. |
| Git secret scan | **NOT VERIFIED** — проект не является git-репозиторием в этой сборке. Перед публикацией выполните `git status && git ls-files` и поиск секретов самостоятельно. |
| Docker / CI | **NOT PRESENT** — Dockerfile/docker-compose/CI-конфигурация не создавались в этом проходе. |

### Итоговый статус

```
NOT READY FOR ZIP + GITHUB
```

Готово: Auth + Developer/Primary Developer система + токен-квота
(окончательная схема 5/10/15/20/25М + 50 млрд, суточный сброс +
критический таймер восстановления, без отдельных лимитов на медиа) +
rate limiting + расширенный audit log + реальные файлы (ownership,
MIME/размер, без path traversal, теперь со списанием токенов по C5) +
токенные коэффициенты C1-C5 + архитектура PaymentProvider (Kaspi/Freedom
Pay каркас, checkout→webhook→идемпотентность→активация тарифа, покрыто
тестами через мок) + self-hosted AI Router (Lunox AI, никаких платных
внешних API — только собственный инференс-сервер, см. training/README.md
для дообучения) + цикл само-проверки (второй provider только указывает
на ошибки, основной сам переделывает, лимит попыток) + **память**
(кратковременная история диалога — Conversation/Message, и долговременная
— явный remember/forget, оба уровня без embeddings/векторного поиска) +
**квота хранения памяти по тарифам, в единицах "Война и мир"** (Free=3/
Pro=6/Pro Plus=9/Ultra=12/Ultra Plus=15 полных текстов романа ≈19-96 МБ,
Developer=10ГБ отдельно — при исчерпании новые записи блокируются с 507,
старые данные никогда не удаляются автоматически; `GET /memory/status`
для проверки остатка) + **Marketplace** (реальный CRUD, покупки с
идемпотентностью и комиссией, теперь с тестами) + **Media/Voice**
(генерация изображений и STT/TTS через self-hosted сервер, вместо
`not_implemented`) + **система обновлений** (проверка версии +
confirmation token + `scripts/apply_update.py` для реального локального
деплоя — HTTP API никогда сам не переписывает код процесса, тот же
принцип, что у Primary Developer).

Не готово (аудит от 24.08 нашёл 28 пунктов, актуальный статус по
крупным блокам): реальные HTTP-вызовы к Kaspi/Freedom Pay — **важное
уточнение**: официального публичного API Kaspi Pay не существует, доступ
даётся только после заявки на партнёрство (`kaspi.kz/webpay/partnership`),
проверки бизнеса и договора; альтернатива — сторонний реселлер
(например apipay.kz с публичным OpenAPI) — это отдельное бизнес-решение,
ждёт выбора владельца. Веб-поиск для self-hosted моделей
(нет подтверждённого формата tool-calling без сети для проверки),
генерация изображений/видео (заглушки not_implemented, коэффициенты C2/C3
готовы принять списание, но списывать не с чего — генераторов нет), Voice
STT/TTS (заглушки), полноценная биометрия/liveness (только challenge,
без replay-защиты и попыток), Marketplace/addons (каркас без реальной БД
аддонов и покупок), addon build pipeline (не путать с APK pipeline —
addon-сборка отдельно не реализована), реальный inference-сервер и обученная
модель (training pipeline написан, но обучение не проводилось — нет GPU
в этой среде). Primary Developer не забутстрапен физически ни в одной
базе. Real Gmail SMTP, `pytest -v` и `alembic upgrade head` не
выполнялись ни разу в этой
sandbox-среде (нет сети/установленных зависимостей) — статус по ним NOT
VERIFIED, а не PASS.

Согласно самому ТЗ (раздел 0, 63, 78): пока эти пункты не подтверждены
фактическим запуском, статус **READY** ставить нельзя.
